﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicDataAccess
{
    public class clsPersonDataAccess
    {

        public static bool GetPersonInfoByID(int ID, ref string Name, ref char Gender,
            ref string Email, ref string Phone, ref string Address, ref string age)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT * FROM Persons WHERE PersonID = @PersonID";

            using (SqlCommand command = new SqlCommand(query, connection))
            {

                command.Parameters.AddWithValue("@PersonID", ID);

                try
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {

                        if (reader.Read())
                        {


                            isFound = true;

                            Name = (string)reader["Name"];
                            Email = (string)reader["Email"];
                            Phone = (string)reader["PhoneNumber"];
                            age = (string)reader["Age"];
                            Gender = reader.GetString(reader.GetOrdinal("Gender"))[0];
                            if (reader["Address"] == DBNull.Value)
                            { Address = "??????"; }

                            else { Address = (string)reader["Address"]; }
                        }
                        else { isFound = false; }


                        reader.Close();

                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine("Error: " + ex.ToString());
                    isFound = false;
                }
                finally
                {

                    connection.Close();
                }
            }
            return isFound;
        
        }


        public static  bool GetPersonInfoByName(ref int ID,  string Name, ref char Gender,
          ref string Email, ref string Phone, ref string Address, ref string age)
        {
            lock (new object())
            {

                bool isFound = false;

                SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

                string query = "SELECT * FROM Persons WHERE Name = @Name";

                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@Name", Name);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {


                        isFound = true;

                        ID = (int)reader["PersonID"];
                        Email = (string)reader["Email"];
                        Phone = (string)reader["PhoneNumber"];
                        age = (string)reader["Age"];
                        Gender = reader.GetString(reader.GetOrdinal("Gender"))[0];
                        if (reader["Address"] == DBNull.Value)
                        { Address = null; }

                        else { Address = (string)reader["Address"]; }
                    }
                    else { isFound = false; }


                    reader.Close();

                }
                catch (Exception ex)
                {

                    Console.WriteLine("Error: " + ex.ToString());
                    isFound = false;
                }
                finally
                {

                    connection.Close();
                }

                return isFound;
            }
        }

        public static int AddNewPerson(string Name, char Gender,
             string Email, string Phone, string Address, string age)
        {
            int PersonID = -1;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Persons (Name,Age,Gender, PhoneNumber, Email,Address)
                             VALUES (@Name,@Age, @Gender, @PhoneNumber,@Email, @Address);
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Name", Name);
            command.Parameters.AddWithValue("@Gender", Gender);
            command.Parameters.AddWithValue("@Email", Email);
            command.Parameters.AddWithValue("@PhoneNumber", Phone);
            command.Parameters.AddWithValue("@Address", Address);
            command.Parameters.AddWithValue("@Age", age);

            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    PersonID = insertedID;
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally { connection.Close(); }

            return PersonID;
        }

        public static bool UpdatePerson(int ID, string Name, char Gender,
            string Email, string PhoneNumber, string Address, string Age)
        {

            int rowsAffected=0 ;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
         
                string query = @" UPDATE[dbo].[Persons]
              SET[Name] = @Name, 
                 [Age] = @Age,
                 [Gender] = @Gender,
                 [PhoneNumber] = @PhoneNumber, 
                 [Email] = @Email, 
                 [Address] = @Address
            WHERE[PersonID] = @PersonID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonID", ID);
            command.Parameters.AddWithValue("@Name", Name);
            command.Parameters.AddWithValue("@Gender", Gender);
            command.Parameters.AddWithValue("@Email", Email);
            command.Parameters.AddWithValue("@PhoneNumber", PhoneNumber);
            command.Parameters.AddWithValue("@Address", Address);
            command.Parameters.AddWithValue("@Age", Age);


            try
            {
                connection.Open();
                rowsAffected =command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }

        public static DataTable GetAllPersons()
        {

            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT * FROM Persons";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)

                {
                    dt.Load(reader);
                }

                reader.Close();
                connection.Close();

            }

            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return dt;

        }

        public static bool DeletePerson(int PersonID)
        {

            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete Persons 
                                where PersonID = @PersonID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return (rowsAffected > 0);

        }

        public static bool IsPersonExist(int PersonID)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from Persons  where PersonID = @PersonID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }
    }

}
