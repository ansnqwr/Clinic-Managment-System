﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicDataAccess
{
    public class clsDoctorDataAccess
    {
        public static bool FindDoctorByID(int ID, ref int EmployeeId, ref string specialization)
        {
            bool isFound = false;

            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = "SELECT * FROM Doctors WHERE DoctorID = @DoctorID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@DoctorID", ID);

                    try
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read())
                        {

                            // The record was found
                            isFound = true;
                            EmployeeId = (int)reader["EmployeeID"];
                            specialization = (string)reader["Specialization"];

                        }

                        reader.Close();


                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: clsDoctorDataAccess " + ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
            return isFound;

        }

        public static bool FindDoctorByEmployeeID(ref int DoctorID,  int EmployeeId, ref string specialization)
        {
            bool isFound = false;

            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = "SELECT * FROM Doctors WHERE EmployeeID = @EmployeeID";

                using (SqlCommand command = new SqlCommand(query, connection)) { 

                command.Parameters.AddWithValue("@EmployeeID", EmployeeId);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {

                        // The record was found
                        isFound = true;
                        DoctorID = (int)reader["DoctorID"];
                        specialization = (string)reader["Specialization"];

                    }

                    reader.Close();


                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
            }
            return isFound;

        }

        
             public static bool FindDoctorByName(string DoctorName,ref int DoctorID,ref int EmployeeId, ref string specialization)
               {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "EXEC	 [Sp_FindDoctorByName] @DoctorName = @Doctorname";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Doctorname",DoctorName );

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {

                   
                    isFound = true;
                    DoctorID = (int)reader["DoctorID"];
                    specialization = (string)reader["Specialization"];
                    EmployeeId = (int)reader["EmployeeID"];

                }

                reader.Close();


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }
        public static int AddNewDoctor(int EmployeeId, string specialization)
        {
            int DoctorID = -1;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Doctors
           ([EmployeeID]
           ,[Specialization])
     VALUES(
           @EmployeeID
           ,@Specialization);
            SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@EmployeeID", EmployeeId);
            command.Parameters.AddWithValue("@Specialization", specialization);


            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    DoctorID = insertedID;
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally { connection.Close(); }

            return DoctorID;
        }

        public static bool UpdateDoctor(int ID, string Specialization)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Doctors  
                                SET  
                                    Specialization = @Specialization 
                                    WHERE DoctorID = @DoctorID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DoctorID", ID);
            command.Parameters.AddWithValue("@Specialization ", Specialization);


            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }
        public static bool DeleteDoctor(int ID)
        {

            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete Doctors 
                                    where DoctorID = @DoctorID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DoctorID", ID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return (rowsAffected > 0);

        }

        public static bool IsDoctorExist(int ID)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from Doctors  where DoctorID = @DoctorID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DoctorID", ID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }

        public static int GetEmployeeIDByDoctorID(int DoctorID)
        {
            int employeeId = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT EmployeeID FROM Doctors WHERE DoctorID = @DoctorID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DoctorID", DoctorID);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    employeeId = insertedID;

                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return employeeId;
        }



       
  
        public static DataTable GetAllDoctorsName()
        {

            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "Exec Sp_GetAllDoctorsName";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)

                {
                    dt.Load(reader);
                }

                reader.Close();
                connection.Close();

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return dt;

        }


    }

}
