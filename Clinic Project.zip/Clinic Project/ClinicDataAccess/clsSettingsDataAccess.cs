﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicDataAccess
{
    public static class clsSettingsDataAccess
    {


        public static bool GetClinicInfo(ref string ClinicName, ref string ClinicPhone, ref string ClinicTitle)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT * FROM Settings";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {

                    // The record was found
                    isFound = true;

                    ClinicName = (string)reader["ClinicName"];
                    ClinicPhone = (string)reader["ClinicPhone"];
                    ClinicTitle = (string)reader["ClinicTitle"];


                }

                reader.Close();


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }


        public static bool UpdateClinicInfo(string ClinicName,  string ClinicPhone,  string ClinicTitle)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Settings  
                            SET  ClinicName= @ClinicName,                       
                                  ClinicPhone=@ClinicPhone,
                                   ClinicTitle=@ClinicTitle  ";  

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@ClinicTitle", ClinicTitle);
            command.Parameters.AddWithValue("@ClinicPhone", ClinicPhone);
            command.Parameters.AddWithValue("@ClinicName", ClinicName);



            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }

    }
}
