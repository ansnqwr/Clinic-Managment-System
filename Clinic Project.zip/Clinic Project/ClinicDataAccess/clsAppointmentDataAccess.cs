﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClinicDataAccess
{
    public class clsAppointmentDataAccess
    {
        public static bool IsAppointmentInfoExist(int ID)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from Appointments  where AppointmentID = @AppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", ID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }

        public static int AddNewAppointment(int DoctorID, int PatientID, int StatusID, DateTime date,string time,int PaymentID,int MedicalRecordID)
        {
            int AppointmentID = -1;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO [dbo].[Appointments]
           ([PatientID]
           ,[DoctorID]
           ,[AppointmentDateTime]
           ,[AppointmentTime]
           ,[AppointmentStatus]
           ,[MedicalRecordID]
           ,[PaymentID])
     VALUES
           (@PatientID,
           @DoctorID,
           @AppointmentDateTime, 
           @AppointmentTime,
          @AppointmentStatus, 
           @MedicalRecordID, 
           @PaymentID)
     
            SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentDateTime", date);
            command.Parameters.AddWithValue("@AppointmentTime", time);
            command.Parameters.AddWithValue("@AppointmentStatus", StatusID);
            command.Parameters.AddWithValue("@DoctorID", DoctorID);
            command.Parameters.AddWithValue("@PatientID", PatientID);
            command.Parameters.AddWithValue("@PaymentID", PaymentID);
            command.Parameters.AddWithValue("@MedicalRecordID", MedicalRecordID);


            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    AppointmentID = insertedID;
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally { connection.Close(); }

            return AppointmentID;
        }

        public static bool UpdateAppointment(int ID, int AppointmentStatus, DateTime AppointmentDateTime, int DoctorID,string time)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Appointments  
                                SET  
                                     AppointmentDateTime=@AppointmentDateTime,
                                      DoctorID = @DoctorID,
                                     AppointmentStatus=@AppointmentStatus,
                                      AppointmentTime = @time

                                    WHERE AppointmentID = @AppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", ID);
            command.Parameters.AddWithValue("@AppointmentDateTime", AppointmentDateTime);
            command.Parameters.AddWithValue("@AppointmentStatus ", AppointmentStatus);
            command.Parameters.AddWithValue("@DoctorID", DoctorID);
            command.Parameters.AddWithValue("@time", time);



            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }


        public static bool FindAppointmentByPatientID_Date(ref int ID, ref int statusID, DateTime date, ref int DoctorID, int PatientID,
            ref int PaymentID, ref int MedicalRecord, ref string time)
        {
            bool isFound = false;
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {


                string query = " SELECT * FROM Appointments WHERE PatientID = @PatientID and  cast( AppointmentDateTime as date) =cast( @AppointmentDateTime as date) ";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@PatientID", PatientID);
                    command.Parameters.AddWithValue("@AppointmentDateTime", date);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.Read())
                            {
                                isFound = true;
                                ID = (int)reader["AppointmentID"];
                                statusID = (int)reader["AppointmentStatus"];
                                DoctorID = (int)reader["DoctorID"];
                                time = (string)reader["AppointmentTime"];
                                PaymentID = (int)reader["PaymentID"];


                                if (reader["MedicalRecordID"] == DBNull.Value) { MedicalRecord = -1; }
                                else
                                {
                                    MedicalRecord = (int)reader["MedicalRecordID"];
                                }
                            }

                  

                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error:FindAppointmentByPatientID_Date" + ex.ToString());
                  
                        return false;   

                    }


                    return isFound;
                } 
            }
        }

        public static bool FindAppointmentByID( int AppointmentID, ref int statusID,ref DateTime date, ref int DoctorID,ref int PatientID,
         ref int PaymentID, ref int MedicalRecord, ref string time)
        {
            bool isFound = false;
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {


                string query = " SELECT * FROM Appointments WHERE AppointmentID = @AppointmentID  ";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@AppointmentID", AppointmentID);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.Read())
                            {
                                isFound = true;
                                PatientID = (int)reader["PatientID"];
                                statusID = (int)reader["AppointmentStatus"];
                                DoctorID = (int)reader["DoctorID"];
                                time = (string)reader["AppointmentTime"];
                                PaymentID = (int)reader["PaymentID"];
                                date = (DateTime)reader["AppointmentDateTime"];


                                if (reader["MedicalRecordID"] == DBNull.Value) { MedicalRecord = -1; }
                                else
                                {
                                    MedicalRecord = (int)reader["MedicalRecordID"];
                                }
                            }



                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error:FindAppointmentByID " + ex.ToString());
                     
                        return false;

                    }


                    return isFound;
                }
            }
        }



        public static bool DeleteAppointment(int AppointmentID)
        {

            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete Appointments 
                                where AppointmentID = @AppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return (rowsAffected > 0);

        }

        public static DataTable GetAllAppointmentsByDate()
        {

            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString)) { 

                string query = " exec Sp_GetAppointmentsByDate ";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)

                {
                    dt.Load(reader);
                }

                reader.Close();
                connection.Close();

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                connection.Close();

            }
            finally
            {
                connection.Close();

            }

            return dt;
        }
        }


        public static DataTable GetAllAppointmentsByDoctor(int EmployeeID)

        {

            DataTable dt = new DataTable();
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = " exec Sp_GetAllAppointmentsForDoctor @EmployeeID ";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@EmployeeID", EmployeeID);

                try
                {
                    connection.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)

                    {
                        dt.Load(reader);
                    }

                    reader.Close();
                    connection.Close();

                }

                catch (Exception ex)
                {
                    Console.WriteLine("Error: GetAllAppointmentsByDoctor" + ex.Message);
                    connection.Close();

                }
                finally
                {
                    connection.Close();

                }

                return dt;
            }
        }



             public static int GetCountAppontmentsDayByEmployeeID(int EmployeeID)

        {

            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                int count = 0;
                string query = " exec Sp_GetCountAppointmentsDayForDoctor @EmployeeID ";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@EmployeeID", EmployeeID);

                try
                {
                    connection.Open();



                    object result = command.ExecuteScalar();

                    if (result != null && int.TryParse(result.ToString(), out int insertedID))
                    {
                        count = insertedID;
                    }




                }

                catch (Exception ex)
                {
                    Console.WriteLine("Error: GetAllAppointmentsByDoctor" + ex.Message);
                    connection.Close();

                }
                finally
                {
                    connection.Close();

                }
                return count;
            }
        }
        public static bool UpdateStatus(int AppointmentID, int NewStatus)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Appointments  
                            set 
                                AppointmentStatus = @NewStatus
                                
                            where AppointmentID=@AppointmentID;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);
            command.Parameters.AddWithValue("@NewStatus", NewStatus);


            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error:  UpdateStatus " + ex.Message);
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }

        public static bool UpdateMedicalRecordID(int AppointmentID, int MedicalRecordID)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Appointments  
                            set 
                                MedicalRecordID = @MedicalRecordID
                                
                            where AppointmentID=@AppointmentID;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicalRecordID", MedicalRecordID);
            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);


            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error:  UpdateMedicalRecordID " + ex.Message);
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }

    }

}
