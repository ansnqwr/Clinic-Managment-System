﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicDataAccess
{
    public class clsPaymentDataAccess
    {
        public static bool IsPaymentInfoExist(int ID)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from Payments  where PaymentID = @PaymentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PaymentID", ID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }

        public static int AddNewPayment(int AmountPaid, string PaymentMethod, string Notes, DateTime Paymentdate)
        {
            int PaymentID = -1;
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = @"INSERT INTO Payments
           ([PaymentDate]
           ,[PaymentMethod]
           ,[AmountPaid]
           ,[AdditionalNotes])
     VALUES
           (
           @PaymentDate 
           ,@PaymentMethod
           ,@AmountPaid
           ,@AdditionalNotes);
       
            SELECT SCOPE_IDENTITY();";

                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddWithValue("@PaymentDate", Paymentdate);
                command.Parameters.AddWithValue("@PaymentMethod", PaymentMethod);
                command.Parameters.AddWithValue("@AmountPaid", AmountPaid);
                command.Parameters.AddWithValue("@AdditionalNotes", Notes);


                try
                {
                    connection.Open();

                    object result = command.ExecuteScalar();

                    if (result != null && int.TryParse(result.ToString(), out int insertedID))
                    {
                        PaymentID = insertedID;
                    }

                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(" AddNewPayment // // //  ");

                }
                finally { connection.Close(); }
            }
            return PaymentID;
        }

        public static bool UpdatePaid(int ID, string PaymentMethod, string NotesAdditional, decimal AmountPaid, DateTime PaymentDate)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Payments  
                                SET  
                                    PaymentMethod = @PaymentMethod,
                                     AdditionalNotes=@NotesAdditional,
                                    AmountPaid=@AmountPaid,
                                     PaymentDate = @PaymentDate

                                    WHERE PaymentID = @PaymentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PaymentID", ID);
            command.Parameters.AddWithValue("@PaymentMethod ", PaymentMethod);
            command.Parameters.AddWithValue("@PaymentDate ", PaymentDate);
            command.Parameters.AddWithValue("@NotesAdditional ", NotesAdditional);
            command.Parameters.AddWithValue("@AmountPaid", AmountPaid);


            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }


        public static bool FindPaymentByID(int ID, ref int AmountPaid, ref string PaymentMethod, ref string Notes, ref DateTime date)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT * FROM Payments WHERE PaymentID = @PaymentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PaymentID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {

                    // The record was found
                    isFound = true;
                    AmountPaid = (int)reader["AmountPaid"];
                    PaymentMethod = (string)reader["PaymentMethod"];
                    Notes = (string)reader["AdditionalNotes"];
                    date = (DateTime)reader["PaymentDate"];
                }

                reader.Close();


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }

        public static bool DeletePayment(Nullable<int> PaymentID)
        {
            if (PaymentID == null) return true;

            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete Payments 
                                where PaymentID = @PaymentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PaymentID", PaymentID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return (rowsAffected > 0);

        }

        public static Nullable<int> GetPaymentIDByAppointmentID(int AppointmentID)
        {
            Nullable<int> paymentId = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT PaymentID FROM Appointments WHERE AppointmentID = @AppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    paymentId = insertedID;

                }
                else { paymentId = null; }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return paymentId;
        }


     
 public static int GetSumPaymentsDay()
        {
            int? SumPayments = null;
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = @" exec Sp_GetSumPaymentsDay";

                SqlCommand command = new SqlCommand(query, connection);


                try
                {
                    connection.Open();

                    object result = command.ExecuteScalar();

                    if (result != null && int.TryParse(result.ToString(), out int insertedID))
                    {
                        SumPayments = insertedID;
                    }

                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(" SumPayment // // //  ");

                }
                finally { connection.Close(); }
            }

            return SumPayments??0;
        }
    }

}
