﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicDataAccess
{
    public class clsMedicalRecordDataAccess
    {
        public static bool IsMedicalRecordExist(int ID)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from MedicalRecords  where MedicalRecordID = @MedicalRecordID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicalRecordID", ID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }

        public static int AddNewMedicalRecord(string VisitDesc, string diagnosis, string Notes,int PrescriptionID)
        {
            int PrescriptionId = -1;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO [MedicalRecords]
              
              ([VisitDescription]
              ,[Diagnosis]
              ,[AdditionalNotes],[PrescriptionID])
        VALUES
              (
              @VisitDesc
              ,@Diagnosis
              ,@Notes,@PrescriptionID)

               SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@VisitDesc", VisitDesc);
            command.Parameters.AddWithValue("@Diagnosis", diagnosis);
            command.Parameters.AddWithValue("@Notes", Notes);
            if (PrescriptionID > -1)
            command.Parameters.AddWithValue("@PrescriptionID", PrescriptionID);
            else command.Parameters.AddWithValue("@PrescriptionID", DBNull.Value);


            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    PrescriptionId = insertedID;
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally { connection.Close(); }

            return PrescriptionId;
        }

        public static bool UpdateMedicalRecord(int ID, string VisitDesc, string Diagnosis, string NotesAdditional)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  MedicalRecords  
                                   SET  
                                        AdditionalNotes=@NotesAdditional,
                                       VisitDescription=@VisitDesc,
                                        Diagnosis= @Diagnosis
                                       WHERE MedicalRecordID = @MedicalRecordID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicalRecordID", ID);
            command.Parameters.AddWithValue("@VisitDesc", VisitDesc);
            command.Parameters.AddWithValue("@Diagnosis", Diagnosis);
            command.Parameters.AddWithValue("@NotesAdditional ", NotesAdditional);


            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }


        public static bool FindMedicalRecordByID(int ID, ref string VisitDesc, ref string Diagnosis, ref string Notes ,ref int PrescriptionID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT * FROM MedicalRecords WHERE MedicalRecordID = @MedicalRecordID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicalRecordID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {

                    // The record was found
                    isFound = true;
                    VisitDesc = (string)reader["VisitDescription"];
                    Diagnosis = (string)reader["Diagnosis"];
                    Notes = (string)reader["AdditionalNotes"];
                    PrescriptionID = (int)reader["PrescriptionID"];
                }

                reader.Close();


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return isFound;

        }

        public static bool DeleteMedicalRecord(Nullable<int> MedicalRecordID)
        {
            if (MedicalRecordID == null) return true;
            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete MedicalRecords 
                                where MedicalRecordID = @MedicalRecordID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicalRecordID", MedicalRecordID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return (rowsAffected > 0);

        }


        public static Nullable<int> GetMedicalRecordIDByAppointmentID(int AppointmentID)
        {
            Nullable<int> AppointmentId = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT MedicalRecordID FROM Appointments WHERE AppointmentID = @AppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);

            try
            {
                connection.Open();
                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    AppointmentId = insertedID;

                }
                else { AppointmentId = null; }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return AppointmentId;
        }


    }

}
