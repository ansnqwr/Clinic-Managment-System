﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicDataAccess
{
    public class clsUserDataAccess
    {
        public static bool GetUserInfoByUserNameAndPassword(ref int UserID, String UserName, string Password, ref int Permission, ref byte AccountStatus, ref int EmployeeID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = "SELECT * FROM Users WHERE  UserName= @UserName and Password=@Password";

            using (SqlCommand command = new SqlCommand(query, connection))
            {

                command.Parameters.AddWithValue("@UserName", UserName);
                command.Parameters.AddWithValue("@Password", Password);

                try
                {
                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {

                        if (reader.Read())
                        {
                            isFound = true;
                            AccountStatus = (byte)reader["AccountStatus"];
                            UserID = (int)reader["UserID"];
                            Permission = (int)reader["Permission"];
                            EmployeeID = (int)reader["EmployeeID"];

                        }


                        reader.Close();
                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine("Error: " + ex.ToString());
                }
                finally
                {

                    connection.Close();
                }
            }
            return isFound;
        }

        public static bool GetUserInfoByUserName(ref int UserID, String UserName, ref string Password, ref int Permission, ref byte AccountStatus,ref int EmployeeID)
        {
            bool isFound = false;

            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = "SELECT * FROM Users WHERE  UserName= @UserName ";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@UserName", UserName);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.Read())
                            {
                                isFound = true;
                                AccountStatus = (byte)reader["AccountStatus"];
                                UserID = (int)reader["UserID"];
                                Password = (string)reader["Password"];
                                Permission = (int)reader["Permission"];
                                EmployeeID = (int)reader["EmployeeID"];

                            }


                            reader.Close();

                        }
                    }
                    catch (Exception ex)
                    {

                        Console.WriteLine("Error: " + ex.ToString());
                    }
                    finally
                    {

                        connection.Close();
                    }
                }
            }
            return isFound;
        }

        public static bool GetUserInfoByEmployeeID(int EmployeeID,ref int UserID,ref String UserName, ref string Password, ref int Permission, ref byte AccountStatus)
        {
            bool isFound = false;

            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {

                string query = "SELECT * FROM Users WHERE  EmployeeID= @EmployeeID";

                using (SqlCommand command = new SqlCommand(query, connection))
                {

                    command.Parameters.AddWithValue("@EmployeeID", EmployeeID);

                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.Read())
                            {
                                isFound = true;
                                AccountStatus = (byte)reader["AccountStatus"];
                                UserID = (int)reader["UserID"];
                                Password = (string)reader["Password"];
                                Permission = (int)reader["Permission"];
                                UserName = (string)reader["UserName"];
                            }


                            reader.Close();

                        }   }
                    catch (Exception ex)
                    {

                        Console.WriteLine("Error: " + ex.ToString());
                    }
                    finally
                    {

                        connection.Close();
                    }
                } 
            }
            return isFound;
        }


        public static int AddNewUser(string UserName, string Password,int EmployeeID, int Permission, byte AccountStatus)
        {
            int UserID = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Users (UserName,Password,EmployeeID,Permission,AccountStatus)
                             VALUES (@UserName,@Password,@EmployeeID,@Permission ,@AccountStatus );
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@UserName", UserName);
            command.Parameters.AddWithValue("@Password", Password);
            command.Parameters.AddWithValue("@AccountStatus", AccountStatus);
            command.Parameters.AddWithValue("@Permission", Permission);
            command.Parameters.AddWithValue("@EmployeeID", EmployeeID);


            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    UserID = insertedID;
                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally { connection.Close(); }

            return UserID;
        }

        public static bool UpdateUser(int UserID, string UserName, string Password, int Permission, byte AccountStatus)
        {

            int rowsAffected = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update  Users  
                            SET UserName = @UserName, 
                                Password = @Password, 
                                AccountStatus = @AccountStatus,                               
                                 Permission=@Permission
                                WHERE UserID = @UserID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@UserID", UserID);
            command.Parameters.AddWithValue("@UserName", UserName);
            command.Parameters.AddWithValue("@AccountStatus", AccountStatus);
            command.Parameters.AddWithValue("@Password", Password);
            command.Parameters.AddWithValue("@Permission", Permission);



            try
            {
                connection.Open();
                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return false;
            }

            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }

        public static DataTable GetAllUsers()
        {

            DataTable dt = new DataTable();
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = " exec Sp_GetAllUsers";

            SqlCommand command = new SqlCommand(query, connection);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)

                {
                    dt.Load(reader);
                }

                reader.Close();
                connection.Close();

            }

            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return dt;

        }

        public static bool DeleteUser(int UserID)
        {

            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete Users 
                                where UserID = @UserID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@UserID", UserID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return (rowsAffected > 0);

        }

        public static bool IsUserExist(int UserID)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from Users  where UserID = @UserID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@UserID", UserID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }

        public static bool IsUserExist(string UserName)
        {

            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"select Found=1 from Users  where UserName = @UserName";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@UserName", UserName);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                isFound = reader.HasRows;
                reader.Close();
            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {

                connection.Close();

            }

            return isFound;

        }
    }

}
