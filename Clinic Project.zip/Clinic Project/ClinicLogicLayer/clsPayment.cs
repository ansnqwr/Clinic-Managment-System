﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public class clsPayment
    {

        public enum enMode { AddNew, Update }

        public enMode ModePaid = enMode.AddNew;
        public int PaymentID { get; set; }
        public int AmountPayment { get; set; }
        public string PaymentMethod { get; set; }
        public string Notes { get; set; }
        public DateTime date { get; set; }

        public clsPayment()
        {
            PaymentID = -1;
            AmountPayment = -1;
            PaymentMethod = null;
            Notes = null;
            date = default;
            ModePaid = enMode.AddNew;
        }


        private clsPayment(int paymentID, int amountPayment, string paymentMethod, string notes, DateTime Date)
        {
            PaymentID = paymentID;
            AmountPayment = amountPayment;
            PaymentMethod = paymentMethod;
            Notes = notes;
            date = Date;
            ModePaid = enMode.Update;
        }


        public static clsPayment FindPaid(int ID)
        {
            int amount = 0;
            string paymentMethod = "", NotesAdditional = "";
            DateTime date = DateTime.Now;
            if (clsPaymentDataAccess.FindPaymentByID(ID, ref amount, ref paymentMethod, ref NotesAdditional, ref date))
            {

                return new clsPayment(ID, amount, paymentMethod, NotesAdditional, date);
            }

            return null;

        }

        private bool _AddNewPayment()
        {

            this.PaymentID = clsPaymentDataAccess.AddNewPayment(this.AmountPayment, this.PaymentMethod, this.Notes, this.date);

            return (this.PaymentID != -1);
        }


        private bool _UpdatePayment()
        {

            return (clsPaymentDataAccess.UpdatePaid(this.PaymentID, this.PaymentMethod, this.Notes, this.AmountPayment, this.date));

        }

        public bool SavePaid()
        {


            switch (ModePaid)
            {
                case enMode.AddNew:
                    if (_AddNewPayment())
                    {

                        ModePaid = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:
                    return _UpdatePayment();

            }

            return false;
        }

        public static bool IsPaymentInfoExist(int ID)
        {

            return clsPaymentDataAccess.IsPaymentInfoExist(ID);


        }

        public static bool DeletePayment(int ID)
        {

            return clsPaymentDataAccess.DeletePayment(ID);


        }

        public static int GetSumPaymentsDay()
        {

            return clsPaymentDataAccess.GetSumPaymentsDay();


        }

    }

}
