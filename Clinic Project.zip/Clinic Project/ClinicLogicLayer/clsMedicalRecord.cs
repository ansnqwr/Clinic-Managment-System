﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public class clsMedicalRecord
    {
        public enum enMode { AddNew, Update }


        enMode mode;
        public int MedicalRecordID { get; set; }
        public string VisitDescription { get; set; }

        public string Diagnosis { get; set; }
        public string AdditionalNotes { get; set; }
        
        public int PrescriptionID=-1;
        public Prescription prescription { get; set; }  
        public clsMedicalRecord()
        {
            MedicalRecordID = -1;
            VisitDescription = "";
            Diagnosis = "";
            AdditionalNotes = "";
            mode = enMode.AddNew;
        }

        private clsMedicalRecord(int MedicalRecordId, string VisitDesc, string diagnosis, string Notes,int PrescriptionID)
        {

            MedicalRecordID = MedicalRecordId;
            VisitDescription = VisitDesc;
            Diagnosis = diagnosis;
            AdditionalNotes = Notes;
            prescription=Prescription.FindPrescription(PrescriptionID);
            mode = enMode.Update;

        }


        public static clsMedicalRecord FindMedicalRecord(int ID)
        {
            string VisitDesc = "", diagnosis = "", Notes = "";
            int PrescriptionID = 0;
            if (clsMedicalRecordDataAccess.FindMedicalRecordByID(ID, ref VisitDesc, ref diagnosis, ref Notes,ref PrescriptionID))
            {
                return new clsMedicalRecord(ID, VisitDesc, diagnosis, Notes,PrescriptionID);
            }

            return null;

        }


        private bool _AddNewMedicalRecord()
        {

            this.MedicalRecordID = clsMedicalRecordDataAccess.AddNewMedicalRecord(this.VisitDescription, this.Diagnosis, this.AdditionalNotes,this.PrescriptionID);

            return (this.MedicalRecordID != -1);
        }


        private bool _UpdateMedicalRecord()
        {

            return (clsMedicalRecordDataAccess.UpdateMedicalRecord(this.MedicalRecordID, this.VisitDescription, this.Diagnosis, this.AdditionalNotes));

        }

        public bool SaveMedicalRecord()
        {


            switch (mode)
            {
                case enMode.AddNew:
                    if (_AddNewMedicalRecord())
                    {

                        mode = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:
                    return _UpdateMedicalRecord();

            }

            return false;
        }


        public static bool DeleteMedicalRecord(int ID)
        {

            return clsMedicalRecordDataAccess.DeleteMedicalRecord(ID);


        }

        public static bool IsMedicalRecordExist(int ID)
        {

            return clsMedicalRecordDataAccess.IsMedicalRecordExist(ID);


        }


    }

}
