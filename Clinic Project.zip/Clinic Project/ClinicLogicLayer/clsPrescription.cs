﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{

    public enum enMode { AddNew, Update }
    public class Prescription
    {
        public enMode ModePrescription = enMode.AddNew;

        public int PrescriptionID { get; set; }

   

        public string MedicationName { get; set; }

        public string Dosage { get; set; }
        public string Frequency { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public string SpecialInstruction { get; set; }

        public Prescription()
        {
            PrescriptionID = -1;
            ModePrescription = enMode.AddNew;
            MedicationName = "";
            Dosage = "";
            Frequency = "";
            StartDate = DateTime.MinValue;
            EndDate = DateTime.MinValue;
        }

        private Prescription(int ID, string MedicationName, string SpecialInstruction, string Dosage, string Frequency, DateTime startDate, DateTime EndDate)
        {
            PrescriptionID = ID;
            this.MedicationName = MedicationName;
            this.Dosage = Dosage;
            this.Frequency = Frequency;
            this.StartDate = startDate;
            this.EndDate = EndDate;
            this.SpecialInstruction = SpecialInstruction;
            ModePrescription = enMode.Update;
        }

        public static Prescription FindPrescription(int ID)
        {
            string MedicationName = "", dosage = "", frequency = "", Specialization = "";
            DateTime StartDate = default, EndDate = default;

            if (clsPrescriptionDataAccess.FindPerscriptionByID(ID, ref MedicationName, ref Specialization, ref dosage, ref frequency, ref StartDate, ref EndDate))
            {
                return new Prescription(ID, MedicationName, Specialization, dosage, frequency, StartDate, EndDate);
            }

            return null;

        }


        private bool _AddNewPrescription()
        {
            this.PrescriptionID = clsPrescriptionDataAccess.AddNewPerscription( this.MedicationName, this.SpecialInstruction, this.Dosage,
                this.Frequency, this.StartDate, this.EndDate);

            return (this.PrescriptionID != -1);
            
        }


        private bool _UpdatePrescription()
        {
            return (clsPrescriptionDataAccess.UpdatePrescription(this.PrescriptionID, this.MedicationName, this.SpecialInstruction, this.Frequency,
                this.Dosage, this.StartDate, this.EndDate));

        }

        public bool SavePrescription()
        {


            switch (ModePrescription)
            {
                case enMode.AddNew:
                    if (_AddNewPrescription())
                    {
                        ModePrescription = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:
                    return _UpdatePrescription();

            }

            return false;
        }


        public static bool DeletePrescription(int ID)
        {

            return clsPrescriptionDataAccess.DeletePrescription(ID);


        }

        public static bool IsPerscriptionExist(int ID)
        {

            return clsPrescriptionDataAccess.IsPrescriptionExist(ID);


        }





    }




}
