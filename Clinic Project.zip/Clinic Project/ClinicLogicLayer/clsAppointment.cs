﻿using ClinicDataAccess;
using System;
using System.Data;

namespace ClinicLogicLayer
{
    public class clsAppointment
    {
        public enum enMode { AddNew, Update }
        public enum enAppointmentState { Canceled = 4, Completed = 3, Confirmed = 2, Pending = 1 };


        public enMode ModeAppointment;
        public enAppointmentState StateAppointment;

        public int AppointmentID { get; set; }
        public clsDoctor doctor { get; set; }
        public int DoctorID { get; set; }
        public clsPatient patient { get; set; }

        public  int PatientID ;
        public clsPayment Payment { get; set; }

        public int PaymentID ;
        public clsMedicalRecord MedicalRecord { get; set; }

        public int MedicalRecordID ;

        public string Time { get; set; }    
        public DateTime dateTime { get; set; }
        public int StatusID { get; set; }

        public clsAppointment()
        {
            AppointmentID = -1;
            Payment = new clsPayment();
            MedicalRecord = new clsMedicalRecord();     
            dateTime = default;
            StatusID = 0;
            DoctorID = -1;
            PatientID=-1;
            MedicalRecordID=-1; 
            PaymentID = -1;
            ModeAppointment = enMode.AddNew;
        }

        private clsAppointment(int appointmentID, DateTime dateTime, int DoctorID, int PaymentID, int PatientID, int medicalRecord,string time,int StateID)
        {

            AppointmentID = appointmentID;
            this.doctor = clsDoctor.FindDoctor(DoctorID);
            this.patient = clsPatient.FindPatient(PatientID);

            Time = time;    
            if (PaymentID != -1)
            {this.Payment = clsPayment.FindPaid(PaymentID); }

              if (medicalRecord != -1)
              { this.MedicalRecord = clsMedicalRecord.FindMedicalRecord(medicalRecord); }
            StatusID = StateID;
            this.dateTime = dateTime;
            ModeAppointment = enMode.Update;
            StateAppointment =(enAppointmentState)StatusID;

        }


        public static clsAppointment FindAppointment(int PatientID,DateTime date)
        {
            int statusID = 0; int DoctorID = 0, PaymentID = 0, MedicalRecordID = 0, AppointmentID = 0;
            string time = "";
            if (clsAppointmentDataAccess.FindAppointmentByPatientID_Date(ref AppointmentID, ref statusID, date, ref DoctorID,  PatientID, ref PaymentID, ref MedicalRecordID,ref time))
            {
                return new clsAppointment(AppointmentID, date, DoctorID, PaymentID, PatientID, MedicalRecordID,time,statusID);
            }

            return null;

        }

        public static clsAppointment FindAppointment(int AppointmentID)
        {
            int statusID = 0; int DoctorID = 0, PaymentID = 0, MedicalRecordID = 0, PatientID = 0;
            string time = "";
            DateTime date = DateTime.Now;
            if (clsAppointmentDataAccess.FindAppointmentByID( AppointmentID, ref statusID,ref date, ref DoctorID,ref PatientID, ref PaymentID, ref MedicalRecordID, ref time))
            {
                return new clsAppointment(AppointmentID, date, DoctorID, PaymentID, PatientID, MedicalRecordID, time, statusID);
            }

            return null;

        }
        private bool _AddNewAppointment()
        {
            this.AppointmentID = clsAppointmentDataAccess.AddNewAppointment(this.DoctorID, this.PatientID, this.StatusID, this.dateTime,this.Time,this.Payment.PaymentID,this.MedicalRecordID);

            return (this.AppointmentID != -1);
        }


        private bool _UpdateAppointment()
        {
            return (clsAppointmentDataAccess.UpdateAppointment(this.AppointmentID, this.StatusID, this.dateTime, this.DoctorID,
              this.Time));
           
        }

        public bool Cancel()

        {
            return clsAppointmentDataAccess.UpdateStatus(AppointmentID, 4);
        }

        public bool SetComplete()

        {
            return clsAppointmentDataAccess.UpdateStatus(AppointmentID, 3);
        }

        public bool SetConfirmed()

        {
            return clsAppointmentDataAccess.UpdateStatus(AppointmentID, 2);
        }
        public bool SetPending()

        {
            return clsAppointmentDataAccess.UpdateStatus(AppointmentID, 1);
        }

        public bool SetMedicalRecordID()

        {
            return clsAppointmentDataAccess.UpdateMedicalRecordID(AppointmentID,this.MedicalRecordID);
        }
        public bool SaveAppointment()
        {


            switch (ModeAppointment)
            {
                case enMode.AddNew:
                    if (_AddNewAppointment())
                    {

                        ModeAppointment = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:
                    return _UpdateAppointment();

            }

            return false;
        }

        public static bool IsAppointmentInfoExist(int ID)
        {

            return clsAppointmentDataAccess.IsAppointmentInfoExist(ID);


        }


        public static DataTable GetAllAppontmentsBySecretary()
        {
            return clsAppointmentDataAccess.GetAllAppointmentsByDate();

        }

        public static DataTable GetAllAppontmentsByDoctor(int EmployeeID)
        {
            return clsAppointmentDataAccess.GetAllAppointmentsByDoctor(EmployeeID);

        }

        public static int GetCountAppontmentsDayByEmployeeID(int EmployeeID)
        {
            return clsAppointmentDataAccess.GetCountAppontmentsDayByEmployeeID(EmployeeID);

        }

    }

}
