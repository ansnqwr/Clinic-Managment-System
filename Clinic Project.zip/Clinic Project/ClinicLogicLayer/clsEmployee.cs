﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public class clsEmployee : clsPerson
    {
        public enum enMode { AddNew, Update }

        public enMode ModeEmp = enMode.AddNew;

        public int EmployeeID { get; set; }
        public int Salary { get; set; }
        public string Position { get; set; }
        public DateTime Hire_Date { get; set; }
        public clsUser user { get; set; }   


        public clsEmployee()
        {
            EmployeeID = -1;
            Salary = 0;
            Position = "";
            Hire_Date = DateTime.Now;
            ModeEmp = enMode.AddNew;
        }

        private clsEmployee(int iD, int salary, string position, DateTime hire_Date, int PersonID, string name, string address, string phoneNumber, char gender, string email, string age)
        {
            EmployeeID = iD;
            Salary = salary;
            Position = position;
            Hire_Date = hire_Date;
            this.ID = PersonID;
            this.Name = name;
            this.Address = address; 
            this.PhoneNumber = phoneNumber;
            Gender = gender;
            Email = email;
            Age = age;
    //   user= clsUser.FindUserByEmployeeID(EmployeeID);  
            ModeEmp = enMode.Update;

        }


        public static clsEmployee FindEmployee(int ID)
        {
            int salary = 0, personId = 0; string position = ""; DateTime hire_Date = default;
            bool IsFound = clsEmployeeDataAccess.FindEmployeeByID(ID, ref personId,ref salary, ref position, ref hire_Date);
    
            if (IsFound)
            {
                clsPerson person = clsPerson.Find(personId);
                return new clsEmployee(ID,salary,position,hire_Date, person.ID, person.Name, person.Address, person.PhoneNumber, person.Gender, person.Email, person.Age);
            }
            return null;

        }
        private bool _AddNewEmployee()
        {
           
                this.EmployeeID = clsEmployeeDataAccess.AddNewEmployee(this.ID, this.Salary, this.Position, this.Hire_Date);
            
            return (this.EmployeeID != -1);
        }


        private bool _UpdateEmployee()
        {         
                return clsEmployeeDataAccess.UpdateEmployee(this.EmployeeID, this.Salary, this.Position, this.Hire_Date);
      
        }

        public bool SaveEmployee()
        {
            this.mode = (clsPerson.enMode)ModeEmp;

            if (!this.Save())
            {
                return false;
            }


            switch (ModeEmp)
            {
                case enMode.AddNew:
                    if (_AddNewEmployee())
                    {

                        ModeEmp = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:
                    return _UpdateEmployee();

            }

            return false;
        }


        public static bool DeleteEmployee(int ID, int PersonID)
        {
            if (!clsPerson.DeletePerson(PersonID))
                return false;

            return  clsEmployeeDataAccess.DeleteEmployee(ID);
            
        }


        public static bool IsEmployeeExist(int ID)
        {
            

            return clsEmployeeDataAccess.IsEmployeeExist(ID);


        }


        public static DataTable GetAllEmployees()
        {
            return clsEmployeeDataAccess.GetAllEmployees();

        }

        public static int GetPersonIDByEmployeeID(int employeeId)
        {
            return clsEmployeeDataAccess.GetPersonIDByEmployeeID(employeeId);
        }


    }
}
