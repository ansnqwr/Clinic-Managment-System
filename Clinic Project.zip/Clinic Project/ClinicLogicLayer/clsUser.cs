﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public class clsUser
    {
        public enum enMode { AddNew, Update }

        enMode ModeUser = enMode.AddNew;
        public int UserID { get; set; }

        public int EmployeeID { get; set; }

        public clsEmployee Employee { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public byte AccountStatus { get; set; }

        public int Permission { get; set; }


        public clsUser()
        {
            UserID = -1;
            UserName = "";
            Password = "";
            AccountStatus = 0;
            Permission = -1;
            EmployeeID = -1;    
            Employee = null;
            ModeUser = enMode.AddNew;
        }

        private clsUser(int userID, string userName, string password, int permission, byte accountStatus, int EmployeeID)
        {
            ModeUser = enMode.Update;
            UserID = userID;
            UserName = userName;
            Password = password;
            Permission = permission;
            AccountStatus = accountStatus;
            this.EmployeeID = EmployeeID;
            Employee = clsEmployee.FindEmployee(EmployeeID);
        }

        //public static string EncryptString(string plainText, string key)
        //{
        //    if (string.IsNullOrEmpty(plainText)) return plainText;

        //    using (Aes aes = Aes.Create())
        //    {
        //        aes.Key = Encoding.UTF8.GetBytes(key);
        //        aes.IV = new byte[16]; // IV صفري للتبسيط

        //        ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

        //        using (MemoryStream ms = new MemoryStream())
        //        using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
        //        {
        //            using (StreamWriter sw = new StreamWriter(cs))
        //                sw.Write(plainText);
        //            return Convert.ToBase64String(ms.ToArray());
        //        }
        //    }
        //}

        //public static string DecryptString(string cipherText, string key)
        //{
        //    if (string.IsNullOrEmpty(cipherText)) return cipherText;

        //    try
        //    {
        //        using (Aes aes = Aes.Create())
        //        {
        //            aes.Key = Encoding.UTF8.GetBytes(key);
        //            aes.IV = new byte[16]; // IV صفري للتبسيط

        //            ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

        //            using (MemoryStream ms = new MemoryStream(Convert.FromBase64String(cipherText)))
        //            using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
        //            using (StreamReader sr = new StreamReader(cs))
        //                return sr.ReadToEnd();
        //        }
        //    }
        //    catch
        //    {
        //        return string.Empty; // في حالة فشل فك التشفير
        //    }
        //}

        private bool _AddNewUser()
        {

           // this.UserID = clsUserDataAccess.AddNewUser(this.UserName, EncryptString(this.Password, "3333333333333333"), this.Permission, this.AccountStatus);
            this.UserID = clsUserDataAccess.AddNewUser(this.UserName, this.Password,this.EmployeeID ,this.Permission, this.AccountStatus);


            return (this.UserID != -1);
        }


        private bool _UpdateUser()
        {

            return clsUserDataAccess.UpdateUser(this.UserID, this.UserName, this.Password, this.Permission, this.AccountStatus);

        }

        public static clsUser FindUserByUserNameAndPassword(string UserName, string Password)
        {
            byte AccountStatus = 0;
            int UserID = 0, Permission = -1, EmployeeID = -1;

            if (clsUserDataAccess.GetUserInfoByUserNameAndPassword(ref UserID, UserName, Password, ref Permission, ref AccountStatus,ref EmployeeID))
                return new clsUser(UserID, UserName, Password, Permission, AccountStatus,EmployeeID);
            else
                return null;

        }

        public static clsUser FindUserByUserName(string UserName)
        {
            byte AccountStatus = 0;
            int UserID = 0, Permission = -1, EmployeeID = -1;
            string Password = "";
            if (clsUserDataAccess.GetUserInfoByUserName(ref UserID, UserName, ref Password, ref Permission, ref AccountStatus, ref EmployeeID))
            return new clsUser(UserID, UserName, Password, Permission, AccountStatus, EmployeeID);
            // return new clsUser(UserID, UserName, DecryptString(Password, "3333333333333333"), Permission, AccountStatus,EmployeeID);

            else
                return null;

        }

        public static clsUser FindUserByEmployeeID(int EmployeeID)
        {
          
                byte AccountStatus = 0;
                int UserID = 0, Permission = -1;
                string Password = "", UserName = "";
                if (clsUserDataAccess.GetUserInfoByEmployeeID(EmployeeID, ref UserID, ref UserName, ref Password, ref Permission, ref AccountStatus))
                    return new clsUser(UserID, UserName, Password, Permission, AccountStatus, EmployeeID);
                //   return new clsUser(UserID, UserName, DecryptString(Password, "3333333333333333"), Permission, AccountStatus,EmployeeID);

                else
                    return null;
            
        }

        public bool SaveUser()
        {

            switch (ModeUser)
            {
                case enMode.AddNew:
                    if (_AddNewUser())
                    {
                        ModeUser = enMode.Update;
                        return true;
                    }
                    else { return false; }


                case enMode.Update:
                    return _UpdateUser();

            }

            return false;
        }

        public static DataTable GetAllUsers()
        {
            return clsUserDataAccess.GetAllUsers();

        }

        public static bool DeleteUser(int ID)
        {

            return clsUserDataAccess.DeleteUser(ID);


        }

        public static bool IsUserExist(int ID)
        {

            return clsUserDataAccess.IsUserExist(ID);


        }

        public static bool IsUserExist(string UserName)
        {

            return clsUserDataAccess.IsUserExist(UserName);


        }
    }

}
