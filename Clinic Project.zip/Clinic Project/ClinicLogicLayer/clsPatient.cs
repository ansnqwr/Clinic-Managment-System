﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public class clsPatient : clsPerson
    {
        public enum enMode { AddNew, Update }

        public enMode Mode = enMode.AddNew;
        public int PatientID { get; set; }
        public int PersonID { get; set; }

        public clsPatient()
        {
            PatientID = -1;
            Mode = enMode.AddNew;
        }

        public clsPatient(int patientID,int PersonID, string name, string address, string phoneNumber, char gender, string email, string age)
        {
            PatientID = patientID;
            this.PersonID = PersonID;
            this.ID = PersonID;
            base.Name= name;
            this.Address= address;
            this.PhoneNumber= phoneNumber;
            this.Gender=gender;
            this.Email= email;
            this.Age= age;
            Mode = enMode.Update;
        }

        public static clsPatient FindPatient(int PatientID)
        {
            int personId = 0;
            bool IsFound = clsPatientDataAccess.FindPatientByID(PatientID, ref personId);
            if (IsFound)
            {
               clsPerson  person =clsPerson.Find(personId);
                return new clsPatient(PatientID,person.ID,person.Name,person.Address,person.PhoneNumber,person.Gender,person.Email,person.Age);
            }

            return null;

        }

        private bool _AddNewPatient()
        {


            this.PatientID = clsPatientDataAccess.AddNewPatient(this.ID);

            return (this.PatientID != -1);
        }
        private bool _UpdatePatient()
        {
            return clsPatientDataAccess.UpdatePatient(this.PatientID,this.PersonID);
        }
        public bool SavePatient()
        {
           
            this.mode = (clsPerson.enMode) Mode;

            if (!this.Save())
            {
                Console.WriteLine("eeeeeeeeeeeee");

                return false;
            }

            switch (Mode)
            {
                case enMode.AddNew:
                    if (_AddNewPatient())
                    {

                        Mode = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:

                    return _UpdatePatient();
                default:
                    break;
            }

            return false;
        }

        public static bool DeletePatient(int ID)
        {
            return (clsPatientDataAccess.DeletePatient(ID));

        }


        public static bool IsPatientExist(int ID)
        {

            return clsPatientDataAccess.IsPatientExist(ID);


        }


        public static DataTable GetAllPatients()
        {
            return clsPatientDataAccess.GetAllPatients();

        }


        public static int GetCountPatientsPendingToDoctor(int EmployeeID)
        {
            return clsPatientDataAccess.GetCountPatientsPendingDayToDoctor(EmployeeID);

        }

        public static int GetCountPatientsToDoctor(int EmployeeID)
        {
            return clsPatientDataAccess.GetCountPatientsToDoctor(EmployeeID);

        }
    }

}
