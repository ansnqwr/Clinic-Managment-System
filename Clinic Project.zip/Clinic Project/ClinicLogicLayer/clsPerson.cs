﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public class clsPerson

    {
        public enum enMode { AddNew, Update }

        public enMode mode = enMode.AddNew;
        public int ID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public char Gender { get; set; }
        public string Email { get; set; }
        public string Age { get; set; }

        public clsPerson()
        {
            ID = -1;
            Name = "";
            Address = "";
            PhoneNumber = "";
            Gender = ' ';
            Email = "";
            Age = "";
            mode = enMode.AddNew;
        }

    

        private clsPerson(int id, string name, string address, string phoneNumber, char gender, string email, string age)
        {
            ID = id;
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
            Gender = gender;
            Email = email;
            Age = age;
            mode = enMode.Update;
        }


        private bool _AddNewPerson()
        {

            this.ID = clsPersonDataAccess.AddNewPerson(this.Name, this.Gender, this.Email, this.PhoneNumber, this.Address, this.Age);

            return (this.ID != -1);
        }


        private bool _UpdatePerson()
        {
            return clsPersonDataAccess.UpdatePerson(this.ID, this.Name, this.Gender, this.Email, this.PhoneNumber, this.Address, this.Age);

        }

        public  static  clsPerson Find(int ID)
        {      

                string Name = "", Email = "", PhoneNumber = "", Address = "";
                char Gender = default;
                string age = "";

                if (clsPersonDataAccess.GetPersonInfoByID(ID, ref Name, ref Gender, ref Email, ref PhoneNumber, ref Address, ref age))
                    return new clsPerson(ID, Name, Address, PhoneNumber, Gender, Email, age);
                
                    return null;
            
        }

        public static clsPerson Find(string Name)
        {

            string  Email = "", PhoneNumber = "", Address = "", age = "";
            char Gender = default;
            int ID = -1;

            if (clsPersonDataAccess.GetPersonInfoByName(ref ID, Name, ref Gender, ref Email, ref PhoneNumber, ref Address, ref age))
                return new clsPerson( ID, Name, Address, PhoneNumber, Gender, Email, age);
            else
                return null;

        }

        public bool Save()
        {

            switch (mode)
            {
                case enMode.AddNew:
                    if (_AddNewPerson())
                    {
                        mode = enMode.Update;
                        return true;
                    }
                    else { return false; }


                case enMode.Update:
                    return _UpdatePerson();

            }

            return true;
        }

        public static DataTable GetAllPeople()
        {
            return clsPersonDataAccess.GetAllPersons();

        }

        public static bool DeletePerson(int ID)
        {

            return clsPersonDataAccess.DeletePerson(ID);


        }

        public static bool IsPersonExist(int ID)
        {

            return clsPersonDataAccess.IsPersonExist(ID);


        }
    }

}
