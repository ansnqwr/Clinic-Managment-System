﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{
    public  class clsSettings
    {

   public string ClinicName { get; set; }
        public string ClinicPhone { get; set; }
        public string ClinicTitle { get; set; }

        public clsSettings()
        {
            ClinicName = "";
            ClinicPhone = "";
            ClinicTitle = "";
        }
        private clsSettings(string clinicName, string clinicPhone, string clinicTitle)
        {
            ClinicName = clinicName;
            ClinicPhone = clinicPhone;
            ClinicTitle = clinicTitle;
        }   
        public static clsSettings GetClinicInfo()
        {

            string clinicName = "";
            string clinicPhone = "";
            string clinicTitle = "";

            clsSettingsDataAccess.GetClinicInfo(ref clinicName,ref clinicPhone,ref clinicTitle);
            return new clsSettings(clinicName, clinicPhone, clinicTitle);
        }

          public  bool UpdateClinicInfo()
        {
            return clsSettingsDataAccess.UpdateClinicInfo( ClinicName,ClinicPhone,ClinicTitle);
        }
    
    
    
    
    
    }
}
