﻿using ClinicDataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClinicLogicLayer
{        	

    public class clsDoctor
    {
        public enum enMode { AddNew, Update }

        public enMode ModeDoctor = enMode.AddNew;
        public int DoctorID { get; set; }
        public static int EmployeeID { get; set; } // the type is static for Delete Function...
        public string Specialization { get; set; }

        public clsEmployee employee { get; set; }

        public clsDoctor()
        {
            employee = new clsEmployee();
            DoctorID = -1;
            EmployeeID = employee.ID;
            Specialization = "";
            ModeDoctor = enMode.AddNew;
        }

        private clsDoctor(int doctorID, int employeeID, string specialization)
        {
            DoctorID = doctorID;
            EmployeeID = employeeID;
            Specialization = specialization;
            this.employee = clsEmployee.FindEmployee(employeeID);

            ModeDoctor = enMode.Update;
        }


        public static clsDoctor FindDoctor(int ID)
        {
            int EmployeeId = 0; string specialization = "";
            if (clsDoctorDataAccess.FindDoctorByID(ID, ref EmployeeId, ref specialization))
            {

                return new clsDoctor(ID, EmployeeId, specialization);
            }

            return null;

        }

        public static clsDoctor FindDoctorByEmployeeID(int EmployeeID)
        {
            int DoctorId = 0; string specialization = "";
            if (clsDoctorDataAccess.FindDoctorByEmployeeID( ref DoctorId, EmployeeID, ref specialization))
            {
                return new clsDoctor(DoctorId, EmployeeID, specialization);
            }

            return null;

        }

        public static clsDoctor FindDoctorByName(string DoctorName)
        {
            int EmployeeId = 0, ID = 0;
            string specialization = "";
            if (clsDoctorDataAccess.FindDoctorByName( DoctorName,ref ID, ref EmployeeId, ref specialization))
            {
                return new clsDoctor(ID, EmployeeId, specialization);
            }

            return null;

        }
        private bool _AddNewDoctor()
        {
            
                this.DoctorID = clsDoctorDataAccess.AddNewDoctor(this.employee.EmployeeID, this.Specialization);
            
            return (this.DoctorID != -1);
        }

        private bool _UpdateDoctor()
        {
            if (employee.SaveEmployee())
            {
                return (clsDoctorDataAccess.UpdateDoctor(this.DoctorID, this.Specialization));

            }
            return false;
        }

        public bool SaveDoctor()
        {


            switch (ModeDoctor)
            {
                case enMode.AddNew:
                    if (_AddNewDoctor())
                    {

                        ModeDoctor = enMode.Update;
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                case enMode.Update:
                    return _UpdateDoctor();

            }

            return false;
        }

        //public static bool DeleteDoctor(int ID)
        //{
        //    EmployeeID = GetEmployeeIDByDoctorID(ID);
        //    if (clsDoctorDataAccess.DeleteDoctor(ID))
        //    {

        //        return clsEmployee.DeleteEmployee(EmployeeID);
        //    }
        //    return false;

        //}

        public static bool IsDoctorExist(int ID)
        {

            return clsDoctorDataAccess.IsDoctorExist(ID);


        }

        public static int GetEmployeeIDByDoctorID(int doctorId)
        {
            return clsDoctorDataAccess.GetEmployeeIDByDoctorID(doctorId);
        }

    
        public static DataTable GetAllDoctorsName()
        {
            return clsDoctorDataAccess.GetAllDoctorsName();

        }
    }

}
