﻿namespace ClinicAppWindowsForms
{
    partial class MainDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.titlePanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.sidePanel = new System.Windows.Forms.Panel();
            this.pb_LogoApp = new System.Windows.Forms.PictureBox();
            this.lb_UserName = new System.Windows.Forms.Label();
            this.btn_Employees = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.navButton = new System.Windows.Forms.Button();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.btn_Tasks = new System.Windows.Forms.Button();
            this.statusPanel = new System.Windows.Forms.Panel();
            this.timeLabel = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lb_CountAllPatients = new System.Windows.Forms.Label();
            this.lb = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb_AppointmentsDayCount = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lb_SumPaymentsDay = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.card = new System.Windows.Forms.Panel();
            this.lb_PatientsCountValue = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.titlePanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.sidePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_LogoApp)).BeginInit();
            this.mainPanel.SuspendLayout();
            this.statusPanel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.card.SuspendLayout();
            this.SuspendLayout();
            // 
            // titlePanel
            // 
            this.titlePanel.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.titlePanel.Controls.Add(this.panel1);
            this.titlePanel.Controls.Add(this.titleLabel);
            this.titlePanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.titlePanel.Location = new System.Drawing.Point(0, 0);
            this.titlePanel.Name = "titlePanel";
            this.titlePanel.Size = new System.Drawing.Size(1627, 50);
            this.titlePanel.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1627, 50);
            this.panel1.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panel5.Controls.Add(this.label9);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1627, 50);
            this.panel5.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(769, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(340, 29);
            this.label9.TabIndex = 0;
            this.label9.Text = "🏥Clinic Management System";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(769, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "🏥Clinic Management System";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.BackColor = System.Drawing.Color.Transparent;
            this.titleLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.titleLabel.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.titleLabel.Location = new System.Drawing.Point(754, 9);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(313, 29);
            this.titleLabel.TabIndex = 0;
            this.titleLabel.Text = "Clinic Management System";
            this.titleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // sidePanel
            // 
            this.sidePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.sidePanel.Controls.Add(this.pb_LogoApp);
            this.sidePanel.Controls.Add(this.lb_UserName);
            this.sidePanel.Controls.Add(this.btn_Employees);
            this.sidePanel.Controls.Add(this.button7);
            this.sidePanel.Controls.Add(this.button6);
            this.sidePanel.Controls.Add(this.button5);
            this.sidePanel.Controls.Add(this.button4);
            this.sidePanel.Controls.Add(this.button3);
            this.sidePanel.Controls.Add(this.button1);
            this.sidePanel.Controls.Add(this.navButton);
            this.sidePanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidePanel.Location = new System.Drawing.Point(0, 50);
            this.sidePanel.Name = "sidePanel";
            this.sidePanel.Size = new System.Drawing.Size(236, 698);
            this.sidePanel.TabIndex = 1;
            // 
            // pb_LogoApp
            // 
            this.pb_LogoApp.Image = global::ClinicAppWindowsForms.Properties.Resources.photo_2025_11_25_19_48_05;
            this.pb_LogoApp.Location = new System.Drawing.Point(46, 740);
            this.pb_LogoApp.Name = "pb_LogoApp";
            this.pb_LogoApp.Size = new System.Drawing.Size(122, 117);
            this.pb_LogoApp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_LogoApp.TabIndex = 13;
            this.pb_LogoApp.TabStop = false;
            // 
            // lb_UserName
            // 
            this.lb_UserName.AutoSize = true;
            this.lb_UserName.Font = new System.Drawing.Font("Segoe Marker", 16.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UserName.ForeColor = System.Drawing.Color.White;
            this.lb_UserName.Location = new System.Drawing.Point(54, 14);
            this.lb_UserName.Name = "lb_UserName";
            this.lb_UserName.Size = new System.Drawing.Size(129, 33);
            this.lb_UserName.TabIndex = 11;
            this.lb_UserName.Text = "UserName";
            // 
            // btn_Employees
            // 
            this.btn_Employees.BackColor = System.Drawing.Color.Transparent;
            this.btn_Employees.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Employees.FlatAppearance.BorderSize = 0;
            this.btn_Employees.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Employees.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Employees.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Employees.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Employees.Location = new System.Drawing.Point(1, 376);
            this.btn_Employees.Name = "btn_Employees";
            this.btn_Employees.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.btn_Employees.Size = new System.Drawing.Size(232, 50);
            this.btn_Employees.TabIndex = 10;
            this.btn_Employees.Tag = "6";
            this.btn_Employees.Text = "👨‍💼 Employees";
            this.btn_Employees.UseVisualStyleBackColor = false;
            this.btn_Employees.Click += new System.EventHandler(this.btn_Employees_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(3, 432);
            this.button7.Name = "button7";
            this.button7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button7.Size = new System.Drawing.Size(232, 50);
            this.button7.TabIndex = 9;
            this.button7.Tag = "7";
            this.button7.Text = "⚙️ Settings";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Image = global::ClinicAppWindowsForms.Properties.Resources.sign_out_32__2;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(-2, 488);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(232, 50);
            this.button6.TabIndex = 8;
            this.button6.Tag = "8";
            this.button6.Text = "Log Out";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(0, 320);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(232, 50);
            this.button5.TabIndex = 7;
            this.button5.Tag = "6";
            this.button5.Text = "👨‍💼 Users";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(1, 264);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button4.Size = new System.Drawing.Size(232, 50);
            this.button4.TabIndex = 6;
            this.button4.Tag = "5";
            this.button4.Text = "📋 Medical Records";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(3, 208);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(230, 50);
            this.button3.TabIndex = 5;
            this.button3.Tag = "3";
            this.button3.Text = "📅  Appointments";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(0, 152);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(233, 50);
            this.button1.TabIndex = 3;
            this.button1.Tag = "2";
            this.button1.Text = "👥 Patients";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // navButton
            // 
            this.navButton.BackColor = System.Drawing.Color.Transparent;
            this.navButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.navButton.FlatAppearance.BorderSize = 0;
            this.navButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.navButton.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.navButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.navButton.Location = new System.Drawing.Point(0, 96);
            this.navButton.Name = "navButton";
            this.navButton.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.navButton.Size = new System.Drawing.Size(233, 50);
            this.navButton.TabIndex = 2;
            this.navButton.Tag = "1";
            this.navButton.Text = "🏠 Home";
            this.navButton.UseVisualStyleBackColor = false;
            this.navButton.Click += new System.EventHandler(this.NavButton_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.btn_Tasks);
            this.mainPanel.Controls.Add(this.statusPanel);
            this.mainPanel.Controls.Add(this.panel4);
            this.mainPanel.Controls.Add(this.panel3);
            this.mainPanel.Controls.Add(this.panel2);
            this.mainPanel.Controls.Add(this.card);
            this.mainPanel.Controls.Add(this.welcomeLabel);
            this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPanel.Location = new System.Drawing.Point(236, 50);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(1391, 698);
            this.mainPanel.TabIndex = 2;
            // 
            // btn_Tasks
            // 
            this.btn_Tasks.Image = global::ClinicAppWindowsForms.Properties.Resources.Tasks_435531;
            this.btn_Tasks.Location = new System.Drawing.Point(1720, -1);
            this.btn_Tasks.Name = "btn_Tasks";
            this.btn_Tasks.Size = new System.Drawing.Size(88, 72);
            this.btn_Tasks.TabIndex = 7;
            this.btn_Tasks.UseVisualStyleBackColor = true;
            this.btn_Tasks.Click += new System.EventHandler(this.button2_Click);
            // 
            // statusPanel
            // 
            this.statusPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.statusPanel.Controls.Add(this.timeLabel);
            this.statusPanel.Controls.Add(this.statusLabel);
            this.statusPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.statusPanel.Location = new System.Drawing.Point(0, 673);
            this.statusPanel.Name = "statusPanel";
            this.statusPanel.Size = new System.Drawing.Size(1391, 25);
            this.statusPanel.TabIndex = 6;
            // 
            // timeLabel
            // 
            this.timeLabel.AutoSize = true;
            this.timeLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timeLabel.Location = new System.Drawing.Point(1318, 0);
            this.timeLabel.Name = "timeLabel";
            this.timeLabel.Padding = new System.Windows.Forms.Padding(0, 0, 10, 0);
            this.timeLabel.Size = new System.Drawing.Size(61, 16);
            this.timeLabel.TabIndex = 8;
            this.timeLabel.Text = "label10";
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.statusLabel.Location = new System.Drawing.Point(6, 0);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.statusLabel.Size = new System.Drawing.Size(61, 16);
            this.statusLabel.TabIndex = 7;
            this.statusLabel.Text = "label10";
            // 
            // panel4
            // 
            this.panel4.AutoSize = true;
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            this.panel4.Controls.Add(this.lb_CountAllPatients);
            this.panel4.Controls.Add(this.lb);
            this.panel4.Location = new System.Drawing.Point(962, 96);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(10);
            this.panel4.Size = new System.Drawing.Size(250, 120);
            this.panel4.TabIndex = 5;
            // 
            // lb_CountAllPatients
            // 
            this.lb_CountAllPatients.AutoSize = true;
            this.lb_CountAllPatients.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_CountAllPatients.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_CountAllPatients.Location = new System.Drawing.Point(54, 56);
            this.lb_CountAllPatients.Name = "lb_CountAllPatients";
            this.lb_CountAllPatients.Size = new System.Drawing.Size(142, 46);
            this.lb_CountAllPatients.TabIndex = 10;
            this.lb_CountAllPatients.Text = "[????]";
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb.Location = new System.Drawing.Point(46, 0);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(150, 24);
            this.lb.TabIndex = 9;
            this.lb.Text = "Patients Count";
            // 
            // panel3
            // 
            this.panel3.AutoSize = true;
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.panel3.Controls.Add(this.lb_AppointmentsDayCount);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(633, 96);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(10);
            this.panel3.Size = new System.Drawing.Size(281, 120);
            this.panel3.TabIndex = 4;
            // 
            // lb_AppointmentsDayCount
            // 
            this.lb_AppointmentsDayCount.AutoSize = true;
            this.lb_AppointmentsDayCount.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AppointmentsDayCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_AppointmentsDayCount.Location = new System.Drawing.Point(50, 56);
            this.lb_AppointmentsDayCount.Name = "lb_AppointmentsDayCount";
            this.lb_AppointmentsDayCount.Size = new System.Drawing.Size(142, 46);
            this.lb_AppointmentsDayCount.TabIndex = 9;
            this.lb_AppointmentsDayCount.Text = "[????]";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(22, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(246, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Appointments Day Count";
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel2.Controls.Add(this.lb_SumPaymentsDay);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(343, 96);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(10);
            this.panel2.Size = new System.Drawing.Size(250, 120);
            this.panel2.TabIndex = 3;
            // 
            // lb_SumPaymentsDay
            // 
            this.lb_SumPaymentsDay.AutoSize = true;
            this.lb_SumPaymentsDay.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SumPaymentsDay.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_SumPaymentsDay.Location = new System.Drawing.Point(36, 56);
            this.lb_SumPaymentsDay.Name = "lb_SumPaymentsDay";
            this.lb_SumPaymentsDay.Size = new System.Drawing.Size(142, 46);
            this.lb_SumPaymentsDay.TabIndex = 8;
            this.lb_SumPaymentsDay.Text = "[????]";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(13, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(193, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "Sum Payments Day";
            // 
            // card
            // 
            this.card.AutoSize = true;
            this.card.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.card.Controls.Add(this.lb_PatientsCountValue);
            this.card.Controls.Add(this.label2);
            this.card.Location = new System.Drawing.Point(50, 96);
            this.card.Name = "card";
            this.card.Padding = new System.Windows.Forms.Padding(10);
            this.card.Size = new System.Drawing.Size(250, 120);
            this.card.TabIndex = 2;
            // 
            // lb_PatientsCountValue
            // 
            this.lb_PatientsCountValue.AutoSize = true;
            this.lb_PatientsCountValue.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PatientsCountValue.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_PatientsCountValue.Location = new System.Drawing.Point(42, 56);
            this.lb_PatientsCountValue.Name = "lb_PatientsCountValue";
            this.lb_PatientsCountValue.Size = new System.Drawing.Size(142, 46);
            this.lb_PatientsCountValue.TabIndex = 7;
            this.lb_PatientsCountValue.Text = "[????]";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(24, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(182, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = " Patients Pending ";
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.BackColor = System.Drawing.Color.White;
            this.welcomeLabel.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLabel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.welcomeLabel.Location = new System.Drawing.Point(50, 30);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(559, 35);
            this.welcomeLabel.TabIndex = 1;
            this.welcomeLabel.Text = "Welcom to Clinic Management System";
            this.welcomeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MainDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1627, 748);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.sidePanel);
            this.Controls.Add(this.titlePanel);
            this.Name = "MainDashboard";
            this.ShowIcon = false;
            this.Text = "Clinic Managment System";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainDashboard_FormClosing);
            this.Load += new System.EventHandler(this.MainDashboard_Load);
            this.titlePanel.ResumeLayout(false);
            this.titlePanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.sidePanel.ResumeLayout(false);
            this.sidePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_LogoApp)).EndInit();
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.statusPanel.ResumeLayout(false);
            this.statusPanel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.card.ResumeLayout(false);
            this.card.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel titlePanel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Panel sidePanel;
        private System.Windows.Forms.Button navButton;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Panel card;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_PatientsCountValue;
        private System.Windows.Forms.Label lb_CountAllPatients;
        private System.Windows.Forms.Label lb_AppointmentsDayCount;
        private System.Windows.Forms.Label lb_SumPaymentsDay;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel statusPanel;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Label timeLabel;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btn_Employees;
        private System.Windows.Forms.Label lb_UserName;
        private System.Windows.Forms.Button btn_Tasks;
        private System.Windows.Forms.PictureBox pb_LogoApp;
    }
}