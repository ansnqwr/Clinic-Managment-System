﻿using ClinicAppWindowsForms.Patients_Forms;
using ClinicLogicLayer;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Appointments_Forms
{
    public partial class AddEditAppointment : Form
    {
        enum enMode { AddNew, Update }

        enMode mode = enMode.AddNew;
        clsAppointment.enAppointmentState appointmentState;
        clsAppointment appointment = null;
        clsPayment payment = null;

        public AddEditAppointment()
        {
            InitializeComponent();
            mode = enMode.AddNew;   
        }

        public AddEditAppointment(clsAppointment appointment)
        {
            InitializeComponent();
            this.appointment = appointment; 
            mode = enMode.Update;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tpLoginInfo_Click(object sender, EventArgs e)
        {

        }

        private void _LoadAppointmentData()
        {
            if (mode == enMode.AddNew)
            {

                appointment = new clsAppointment();
                lb_Title.Text = "Add New Employee";
                linkLabel_AddPatient.Enabled = true;  
                return;
            }

            linkLabel_AddPatient.Enabled = false;
            lb_Title.Text = "Update Employee Info";
          cb_Time.SelectedIndex=cb_Time.FindString(appointment.Time.Trim());
            dtp_DateAppointment.Value = appointment.dateTime;
            cb_State.SelectedIndex = cb_State.FindString(appointment.StateAppointment.ToString());
            cb_DoctorName.SelectedIndex = cb_DoctorName.FindString(appointment.doctor.employee.Name.Trim());
            tb_PatientName.Text = appointment.patient.Name;
            personInfoWithFilterCtrl1.LoadInfo(appointment.patient.PatientID);
            personInfoWithFilterCtrl1.FilterEnabled = false;
            dtp_PaymentDate.Value = appointment.Payment.date;
            cb_PaymentMethod.SelectedIndex = cb_PaymentMethod.FindString(appointment.Payment.PaymentMethod);
            tb_Amount.Text= appointment.Payment.AmountPayment.ToString();
            tb_AdditionalNotes.Text = appointment.Payment.Notes;


        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            AddEditPersonForm addPerson = new AddEditPersonForm();
            addPerson.DataBack += DataBackFromAddPatient;
            addPerson.ShowDialog();
        }

        private void DataBackFromAddPatient(clsPerson person,int PersonID)
        {
            tb_PatientName.Text=person.Name;
            personInfoWithFilterCtrl1.LoadInfo(person.ID);
            personInfoWithFilterCtrl1.FilterValue= person.ID;   

        }

        private void _FillDoctorsNameInComoboBox()
        {
            DataTable dtDoctorsName = clsDoctor.GetAllDoctorsName();

            foreach (DataRow row in dtDoctorsName.Rows)
            {
                cb_DoctorName.Items.Add(row["Name"].ToString().Trim());
            }
        }

        private void AddEditAppointment_Load(object sender, EventArgs e)
        {


            _FillDoctorsNameInComoboBox();

            cb_DoctorName.SelectedIndex = 0;
            cb_PaymentMethod.SelectedIndex = 0;
            cb_State.SelectedIndex = 0;
            cb_Time.SelectedIndex = 0;
            _LoadAppointmentData();


        }

    

        private void _EditPayment()
        {
            appointment.Payment.date = dtp_PaymentDate.Value;
            appointment.Payment.Notes = tb_AdditionalNotes.Text;
            appointment.Payment.AmountPayment = Convert.ToInt32(tb_Amount.Text.Trim());
            appointment.Payment.PaymentMethod = cb_PaymentMethod.SelectedIndex == 0 ? "Cach" : "Installments";
            if (!appointment.Payment.SavePaid())
            {
                MessageBox.Show($"Dont Save Payment for PatientID : {appointment.PatientID}", "Error Saved Payment", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }


        }
        private void _AddPayment()
        {
            payment = new clsPayment();
            payment.date = dtp_PaymentDate.Value;
            payment.Notes = tb_AdditionalNotes.Text;
            payment.AmountPayment =string.IsNullOrEmpty(tb_Amount.Text) ? 0 : Convert.ToInt32(tb_Amount.Text.Trim());
            payment.PaymentMethod = cb_PaymentMethod.SelectedIndex == 0 ? "Cach" : "Installments";
            if (!payment.SavePaid())
            {
                MessageBox.Show($"Dont Save Payment for PatientID : {appointment.PatientID}", "Error Saved Payment", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            appointment.PaymentID = payment.PaymentID;
            appointment.Payment.PaymentID = payment.PaymentID;


        }
        private void tb_PatientName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tb_PatientName.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tb_PatientName, "Please Add New Patient..");
                return;
            }
            else
            {
                errorProvider1.SetError(tb_PatientName, null);
            };
        }

        private void cb_DoctorName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(cb_DoctorName.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(cb_DoctorName, "Please Choose Doctor Name..");
                return;
            }
            else
            {
                errorProvider1.SetError(cb_DoctorName, null);
            };
        }

        private void cb_Time_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(cb_Time.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(cb_Time, "Please Choose Appointment Time.");
                return;
            }
            else
            {
                errorProvider1.SetError(cb_Time, null);
            };
        }

        private void tb_Amount_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);

        }

        private void btnNextToAppointment_Click(object sender, EventArgs e)
        {
            if (personInfoWithFilterCtrl1.PersonID == -1)
            {
                MessageBox.Show("Please Select a Person", "Select a Person", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            tb_PatientName.Text = personInfoWithFilterCtrl1.SelectedPatient.Name;
            if (mode == enMode.Update)
            {
                tpServeAppointment.Enabled = true;
                tc_AddEditAppointment.SelectedTab = tc_AddEditAppointment.TabPages["tpServeAppointment"];
                return;
            }
          
          
            tpServeAppointment.Enabled = true;
            tc_AddEditAppointment.SelectedTab = tc_AddEditAppointment.TabPages["tpServeAppointment"];
        }

        private void btnPersonInfoNext_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            tpg_Payment.Enabled = true;
            tc_AddEditAppointment.SelectedTab = tc_AddEditAppointment.TabPages["tpg_Payment"];
        }

        private void btn_Back_Click(object sender, EventArgs e)
        {
            tpServeAppointment.Enabled = true;
            tc_AddEditAppointment.SelectedTab = tc_AddEditAppointment.TabPages["tpServeAppointment"];
        }

        private void personInfoWithFilterCtrl1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           this.Hide();
           
        }

        private void btn_Save_Click_1(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            //  appointment.DoctorID=
            appointment.PatientID = personInfoWithFilterCtrl1.SelectedPatient.PatientID;
            appointment.StatusID = cb_State.SelectedIndex + 1;
            appointment.dateTime = dtp_DateAppointment.Value;
            appointment.Time = cb_Time.Text;
            appointment.DoctorID = clsDoctor.FindDoctorByName(cb_DoctorName.Text.Trim()).DoctorID;


            if (this.mode == enMode.AddNew)
            {
                _AddPayment();
            }
            else
            {
                _EditPayment();
            }

            if (appointment.SaveAppointment())
            {

                MessageBox.Show($"{mode} Appointment Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btn_Save.Enabled = false;
            }
            else
            {
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            PatientsForm patientsForm = new PatientsForm(); 
            patientsForm.ShowDialog();
        }
    }
}
