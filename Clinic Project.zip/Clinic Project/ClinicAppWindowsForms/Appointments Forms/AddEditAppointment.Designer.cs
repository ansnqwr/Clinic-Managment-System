﻿namespace ClinicAppWindowsForms.Appointments_Forms
{
    partial class AddEditAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEditAppointment));
            this.tc_AddEditAppointment = new System.Windows.Forms.TabControl();
            this.tpPatientInfo = new System.Windows.Forms.TabPage();
            this.linkLabel_AddPatient = new System.Windows.Forms.LinkLabel();
            this.btnNextToAppointment = new System.Windows.Forms.Button();
            this.personInfoWithFilterCtrl1 = new ClinicAppWindowsForms.Patients_Forms.Controlls.PersonInfoWithFilterCtrl();
            this.tpServeAppointment = new System.Windows.Forms.TabPage();
            this.tb_PatientName = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.lb_Title = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_State = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_DoctorName = new System.Windows.Forms.ComboBox();
            this.cb_Time = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.dtp_DateAppointment = new System.Windows.Forms.DateTimePicker();
            this.btnPersonInfoNext = new System.Windows.Forms.Button();
            this.tpg_Payment = new System.Windows.Forms.TabPage();
            this.btn_Back = new System.Windows.Forms.Button();
            this.cb_PaymentMethod = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dtp_PaymentDate = new System.Windows.Forms.DateTimePicker();
            this.tb_AdditionalNotes = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_Amount = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.tc_AddEditAppointment.SuspendLayout();
            this.tpPatientInfo.SuspendLayout();
            this.tpServeAppointment.SuspendLayout();
            this.tpg_Payment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tc_AddEditAppointment
            // 
            resources.ApplyResources(this.tc_AddEditAppointment, "tc_AddEditAppointment");
            this.tc_AddEditAppointment.Controls.Add(this.tpPatientInfo);
            this.tc_AddEditAppointment.Controls.Add(this.tpServeAppointment);
            this.tc_AddEditAppointment.Controls.Add(this.tpg_Payment);
            this.tc_AddEditAppointment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tc_AddEditAppointment.Name = "tc_AddEditAppointment";
            this.tc_AddEditAppointment.SelectedIndex = 0;
            // 
            // tpPatientInfo
            // 
            this.tpPatientInfo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tpPatientInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tpPatientInfo.Controls.Add(this.linkLabel1);
            this.tpPatientInfo.Controls.Add(this.linkLabel_AddPatient);
            this.tpPatientInfo.Controls.Add(this.btnNextToAppointment);
            this.tpPatientInfo.Controls.Add(this.personInfoWithFilterCtrl1);
            resources.ApplyResources(this.tpPatientInfo, "tpPatientInfo");
            this.tpPatientInfo.Name = "tpPatientInfo";
            // 
            // linkLabel_AddPatient
            // 
            resources.ApplyResources(this.linkLabel_AddPatient, "linkLabel_AddPatient");
            this.linkLabel_AddPatient.Name = "linkLabel_AddPatient";
            this.linkLabel_AddPatient.TabStop = true;
            this.linkLabel_AddPatient.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btnNextToAppointment
            // 
            this.btnNextToAppointment.BackColor = System.Drawing.Color.Cornsilk;
            resources.ApplyResources(this.btnNextToAppointment, "btnNextToAppointment");
            this.btnNextToAppointment.Image = global::ClinicAppWindowsForms.Properties.Resources.Next_32;
            this.btnNextToAppointment.Name = "btnNextToAppointment";
            this.btnNextToAppointment.UseVisualStyleBackColor = false;
            this.btnNextToAppointment.Click += new System.EventHandler(this.btnNextToAppointment_Click);
            // 
            // personInfoWithFilterCtrl1
            // 
            this.personInfoWithFilterCtrl1.FilterEnabled = true;
            resources.ApplyResources(this.personInfoWithFilterCtrl1, "personInfoWithFilterCtrl1");
            this.personInfoWithFilterCtrl1.Name = "personInfoWithFilterCtrl1";
            this.personInfoWithFilterCtrl1.PersonID = -1;
            this.personInfoWithFilterCtrl1.SelectedPatient = null;
            this.personInfoWithFilterCtrl1.Load += new System.EventHandler(this.personInfoWithFilterCtrl1_Load);
            // 
            // tpServeAppointment
            // 
            this.tpServeAppointment.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tpServeAppointment.Controls.Add(this.tb_PatientName);
            this.tpServeAppointment.Controls.Add(this.button1);
            this.tpServeAppointment.Controls.Add(this.btn_Save);
            this.tpServeAppointment.Controls.Add(this.lb_Title);
            this.tpServeAppointment.Controls.Add(this.label8);
            this.tpServeAppointment.Controls.Add(this.label2);
            this.tpServeAppointment.Controls.Add(this.cb_State);
            this.tpServeAppointment.Controls.Add(this.label3);
            this.tpServeAppointment.Controls.Add(this.label6);
            this.tpServeAppointment.Controls.Add(this.cb_DoctorName);
            this.tpServeAppointment.Controls.Add(this.cb_Time);
            this.tpServeAppointment.Controls.Add(this.label4);
            this.tpServeAppointment.Controls.Add(this.label5);
            this.tpServeAppointment.Controls.Add(this.dtp_DateAppointment);
            this.tpServeAppointment.Controls.Add(this.btnPersonInfoNext);
            resources.ApplyResources(this.tpServeAppointment, "tpServeAppointment");
            this.tpServeAppointment.Name = "tpServeAppointment";
            this.tpServeAppointment.Click += new System.EventHandler(this.tpLoginInfo_Click);
            // 
            // tb_PatientName
            // 
            this.tb_PatientName.ForeColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.tb_PatientName, "tb_PatientName");
            this.tb_PatientName.Name = "tb_PatientName";
            this.tb_PatientName.ReadOnly = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            resources.ApplyResources(this.button1, "button1");
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            resources.ApplyResources(this.btn_Save, "btn_Save");
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click_1);
            // 
            // lb_Title
            // 
            resources.ApplyResources(this.lb_Title, "lb_Title");
            this.lb_Title.ForeColor = System.Drawing.Color.Red;
            this.lb_Title.Name = "lb_Title";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label8.Name = "label8";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label2.Name = "label2";
            // 
            // cb_State
            // 
            this.cb_State.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_State.FormattingEnabled = true;
            this.cb_State.Items.AddRange(new object[] {
            resources.GetString("cb_State.Items"),
            resources.GetString("cb_State.Items1"),
            resources.GetString("cb_State.Items2"),
            resources.GetString("cb_State.Items3")});
            resources.ApplyResources(this.cb_State, "cb_State");
            this.cb_State.Name = "cb_State";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label3.Name = "label3";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label6.Name = "label6";
            // 
            // cb_DoctorName
            // 
            this.cb_DoctorName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_DoctorName.FormattingEnabled = true;
            resources.ApplyResources(this.cb_DoctorName, "cb_DoctorName");
            this.cb_DoctorName.Name = "cb_DoctorName";
            // 
            // cb_Time
            // 
            this.cb_Time.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_Time.FormattingEnabled = true;
            this.cb_Time.Items.AddRange(new object[] {
            resources.GetString("cb_Time.Items"),
            resources.GetString("cb_Time.Items1"),
            resources.GetString("cb_Time.Items2"),
            resources.GetString("cb_Time.Items3"),
            resources.GetString("cb_Time.Items4"),
            resources.GetString("cb_Time.Items5"),
            resources.GetString("cb_Time.Items6"),
            resources.GetString("cb_Time.Items7"),
            resources.GetString("cb_Time.Items8"),
            resources.GetString("cb_Time.Items9"),
            resources.GetString("cb_Time.Items10"),
            resources.GetString("cb_Time.Items11"),
            resources.GetString("cb_Time.Items12"),
            resources.GetString("cb_Time.Items13"),
            resources.GetString("cb_Time.Items14"),
            resources.GetString("cb_Time.Items15"),
            resources.GetString("cb_Time.Items16"),
            resources.GetString("cb_Time.Items17"),
            resources.GetString("cb_Time.Items18"),
            resources.GetString("cb_Time.Items19"),
            resources.GetString("cb_Time.Items20"),
            resources.GetString("cb_Time.Items21"),
            resources.GetString("cb_Time.Items22"),
            resources.GetString("cb_Time.Items23"),
            resources.GetString("cb_Time.Items24"),
            resources.GetString("cb_Time.Items25"),
            resources.GetString("cb_Time.Items26"),
            resources.GetString("cb_Time.Items27"),
            resources.GetString("cb_Time.Items28"),
            resources.GetString("cb_Time.Items29")});
            resources.ApplyResources(this.cb_Time, "cb_Time");
            this.cb_Time.Name = "cb_Time";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label5.Name = "label5";
            // 
            // dtp_DateAppointment
            // 
            this.dtp_DateAppointment.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            resources.ApplyResources(this.dtp_DateAppointment, "dtp_DateAppointment");
            this.dtp_DateAppointment.MinDate = new System.DateTime(2025, 10, 5, 0, 0, 0, 0);
            this.dtp_DateAppointment.Name = "dtp_DateAppointment";
            // 
            // btnPersonInfoNext
            // 
            this.btnPersonInfoNext.BackColor = System.Drawing.Color.Cornsilk;
            resources.ApplyResources(this.btnPersonInfoNext, "btnPersonInfoNext");
            this.btnPersonInfoNext.Image = global::ClinicAppWindowsForms.Properties.Resources.Next_32;
            this.btnPersonInfoNext.Name = "btnPersonInfoNext";
            this.btnPersonInfoNext.UseVisualStyleBackColor = false;
            this.btnPersonInfoNext.Click += new System.EventHandler(this.btnPersonInfoNext_Click);
            // 
            // tpg_Payment
            // 
            this.tpg_Payment.BackColor = System.Drawing.Color.White;
            this.tpg_Payment.Controls.Add(this.btn_Back);
            this.tpg_Payment.Controls.Add(this.cb_PaymentMethod);
            this.tpg_Payment.Controls.Add(this.label7);
            this.tpg_Payment.Controls.Add(this.label9);
            this.tpg_Payment.Controls.Add(this.dtp_PaymentDate);
            this.tpg_Payment.Controls.Add(this.tb_AdditionalNotes);
            this.tpg_Payment.Controls.Add(this.label10);
            this.tpg_Payment.Controls.Add(this.label11);
            this.tpg_Payment.Controls.Add(this.tb_Amount);
            resources.ApplyResources(this.tpg_Payment, "tpg_Payment");
            this.tpg_Payment.Name = "tpg_Payment";
            // 
            // btn_Back
            // 
            this.btn_Back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(76)))), ((int)(((byte)(60)))));
            resources.ApplyResources(this.btn_Back, "btn_Back");
            this.btn_Back.ForeColor = System.Drawing.Color.White;
            this.btn_Back.Name = "btn_Back";
            this.btn_Back.UseVisualStyleBackColor = false;
            this.btn_Back.Click += new System.EventHandler(this.btn_Back_Click);
            // 
            // cb_PaymentMethod
            // 
            this.cb_PaymentMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_PaymentMethod.FormattingEnabled = true;
            this.cb_PaymentMethod.Items.AddRange(new object[] {
            resources.GetString("cb_PaymentMethod.Items"),
            resources.GetString("cb_PaymentMethod.Items1")});
            resources.ApplyResources(this.cb_PaymentMethod, "cb_PaymentMethod");
            this.cb_PaymentMethod.Name = "cb_PaymentMethod";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label7.Name = "label7";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label9.Name = "label9";
            // 
            // dtp_PaymentDate
            // 
            this.dtp_PaymentDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            resources.ApplyResources(this.dtp_PaymentDate, "dtp_PaymentDate");
            this.dtp_PaymentDate.MaxDate = new System.DateTime(2025, 10, 24, 0, 0, 0, 0);
            this.dtp_PaymentDate.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.dtp_PaymentDate.Name = "dtp_PaymentDate";
            this.dtp_PaymentDate.Value = new System.DateTime(2025, 10, 24, 0, 0, 0, 0);
            // 
            // tb_AdditionalNotes
            // 
            resources.ApplyResources(this.tb_AdditionalNotes, "tb_AdditionalNotes");
            this.tb_AdditionalNotes.Name = "tb_AdditionalNotes";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.label11.Name = "label11";
            // 
            // tb_Amount
            // 
            resources.ApplyResources(this.tb_Amount, "tb_Amount");
            this.tb_Amount.Name = "tb_Amount";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // linkLabel1
            // 
            resources.ApplyResources(this.linkLabel1, "linkLabel1");
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.TabStop = true;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked_1);
            // 
            // AddEditAppointment
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            resources.ApplyResources(this, "$this");
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Controls.Add(this.tc_AddEditAppointment);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddEditAppointment";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Load += new System.EventHandler(this.AddEditAppointment_Load);
            this.tc_AddEditAppointment.ResumeLayout(false);
            this.tpPatientInfo.ResumeLayout(false);
            this.tpPatientInfo.PerformLayout();
            this.tpServeAppointment.ResumeLayout(false);
            this.tpServeAppointment.PerformLayout();
            this.tpg_Payment.ResumeLayout(false);
            this.tpg_Payment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tc_AddEditAppointment;
        private System.Windows.Forms.TabPage tpPatientInfo;
        private System.Windows.Forms.TabPage tpServeAppointment;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox tb_PatientName;
        private System.Windows.Forms.Button btnPersonInfoNext;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Label lb_Title;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_State;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cb_DoctorName;
        private System.Windows.Forms.ComboBox cb_Time;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtp_DateAppointment;
        private System.Windows.Forms.TabPage tpg_Payment;
        private System.Windows.Forms.Button btn_Back;
        private System.Windows.Forms.ComboBox cb_PaymentMethod;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtp_PaymentDate;
        private System.Windows.Forms.TextBox tb_AdditionalNotes;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_Amount;
        private Patients_Forms.Controlls.PersonInfoWithFilterCtrl personInfoWithFilterCtrl1;
        private System.Windows.Forms.Button btnNextToAppointment;
        private System.Windows.Forms.LinkLabel linkLabel_AddPatient;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}