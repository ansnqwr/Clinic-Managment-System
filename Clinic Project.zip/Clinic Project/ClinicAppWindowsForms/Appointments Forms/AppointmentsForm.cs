﻿using ClinicAppWindowsForms.Appointments_Forms;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms
{
    public partial class AppointmentsForm : Form
    {
        public AppointmentsForm()
        {
            InitializeComponent();
        }
        DataTable dt = new DataTable();


        private DataGridView appointmentsGrid;
        private DateTimePicker dateFilterPicker;
        private ComboBox doctorFilterCombo, statusFilterCombo;
        private TextBox searchPatientBox;

        // بيانات تجريبية
        private DataTable appointmentsData;



        private void InitializeAppointmentsForm()
        {
            CreateActionsPanel();
        }   

        private void CreateActionsPanel()
        {


            Button refreshBtn = new Button();
            refreshBtn.Text = "🔄 تحديث البيانات";
            refreshBtn.Size = new Size(120, 40);
            refreshBtn.Location = new Point(410, 15);
            refreshBtn.BackColor = Color.FromArgb(243, 156, 18);
            refreshBtn.ForeColor = Color.White;



         

        }

        private void UpdateStatistics()
        {
            if (dt== null) return;

           ;
            int total = DGV_Appointments.Rows.Count;
            try
            {
                int confirmed = dt.Select("State = 'Confirmed'").Length;
                int pending = dt.Select("State = 'Pending'").Length;

                lb_State.Text = $" All Appointments: {total}  | Confirmed: {confirmed}  | Pending: {pending}";
            }
            catch { }
        }

        #region Event Handlers

        private void SearchPatientBox_TextChanged(object sender, EventArgs e)
        {
            if (appointmentsData != null)
            {
                string filter = $"PatientName LIKE '%{searchPatientBox.Text}%'";
                appointmentsData.DefaultView.RowFilter = filter;
            }
        }

 

    

        private void btn_AddAppointment_Click(object sender, EventArgs e)
        {
            if (!(DGV_Appointments.Rows.Count > 0)) return;

            AddEditAppointment appointment = new AddEditAppointment();
            appointment.Show();
        }

        private void AppointmentsForm_Load(object sender, EventArgs e)
        {
            cb_FilterStatus.SelectedIndex = 0;
            _LoadAppointments();
        }

        private void _FillDoctorsNameInComoboBox()
        {
            cb_FilterDoctorName.Items.Clear();  
            DataTable DoctorsName = clsDoctor.GetAllDoctorsName();

            foreach (DataRow row in DoctorsName.Rows)
            {
                cb_FilterDoctorName.Items.Add(row["Name"]);
            }
        }

        private void _LoadAppointments()
        {
            dt = clsAppointment.GetAllAppontmentsBySecretary();

            DGV_Appointments.DataSource = dt;
           if (DGV_Appointments.Rows.Count > 0)
           {
                DGV_Appointments.Columns[0].HeaderText = "Patient ID";
                DGV_Appointments.Columns[1].HeaderText = "Name";
                DGV_Appointments.Columns[2].HeaderText = "Doctor Name";
                DGV_Appointments.Columns[3].HeaderText = "Date";
                DGV_Appointments.Columns[4].HeaderText = "Time";
                DGV_Appointments.Columns[5].HeaderText = "Status";

            }
           _FillDoctorsNameInComoboBox();
           UpdateStatistics();
        }

        private void dtp_DateAppointment_ValueChanged(object sender, EventArgs e)
        {
            if (dt != null)
            {                  
                    string filter = $"Date ='{dtp_DateAppointment.Value.ToString("MM-dd-yyyy")}'";
                    dt.DefaultView.RowFilter = filter;
                
                UpdateStatistics();

            }
        }

        private void cb_FilterStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_FilterStatus.SelectedIndex == 0) return;
            if (dt != null)
            {
                    string filter = $"State = '{cb_FilterStatus.Text}'";
                   dt.DefaultView.RowFilter = filter;
                UpdateStatistics();
            }

        }

        private void tb_SearchPatient_TextChanged(object sender, EventArgs e)
        {
            if (tb_SearchPatient.Text.Trim() == "" )
            {
                dt.DefaultView.RowFilter = "";
                UpdateStatistics();

                return;
            }

            dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", "Name", tb_SearchPatient.Text.Trim());
            UpdateStatistics();
        }

        private void cb_FilterDoctorName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dt != null)
            {
                string filter = $"DoctorName = '{cb_FilterDoctorName.Text}'";
                dt.DefaultView.RowFilter = filter;

            }
            UpdateStatistics();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            _LoadAppointments();
        }

     

     

        private void btnEditAppointment_Click(object sender, EventArgs e)
        {
            if (!(DGV_Appointments.Rows.Count > 0)) return;

            int PatientID = (int)DGV_Appointments.SelectedRows[0].Cells[0].Value;
            DateTime Date = Convert.ToDateTime( DGV_Appointments.SelectedRows[0].Cells[3].Value);
            clsAppointment appointment = clsAppointment.FindAppointment(PatientID, Date);

            AddEditAppointment appointment1 = new AddEditAppointment(appointment);
            appointment1.Show();
           _LoadAppointments();
          //  dtp_DateAppointment_ValueChanged(null, null);
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddEditAppointment appointment = new AddEditAppointment();
            appointment.Show();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnEditAppointment_Click(null, null);
        }

        private void canceledToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PatientID = (int)DGV_Appointments.SelectedRows[0].Cells[0].Value;
            DateTime Date = Convert.ToDateTime(DGV_Appointments.SelectedRows[0].Cells[3].Value);
            clsAppointment appointment = clsAppointment.FindAppointment(PatientID, Date);
            appointment.Cancel();
            _LoadAppointments();
        }

        private void completedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PatientID = (int)DGV_Appointments.SelectedRows[0].Cells[0].Value;
            DateTime Date = Convert.ToDateTime(DGV_Appointments.SelectedRows[0].Cells[3].Value);
            clsAppointment appointment = clsAppointment.FindAppointment(PatientID, Date);
            appointment.SetComplete();
            _LoadAppointments();
          
        }

        private void confirmedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PatientID = (int)DGV_Appointments.SelectedRows[0].Cells[0].Value;
            DateTime Date = Convert.ToDateTime(DGV_Appointments.SelectedRows[0].Cells[3].Value);
            clsAppointment appointment = clsAppointment.FindAppointment(PatientID, Date);
            appointment.SetConfirmed();
            _LoadAppointments();
        }

        private void pendingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PatientID = (int)DGV_Appointments.SelectedRows[0].Cells[0].Value;
            DateTime Date = Convert.ToDateTime(DGV_Appointments.SelectedRows[0].Cells[3].Value);
            clsAppointment appointment = clsAppointment.FindAppointment(PatientID, Date);
            appointment.SetPending();
            _LoadAppointments();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            if (DGV_Appointments.Rows.Count > 0)
            {
                int PatientID = (int)DGV_Appointments.SelectedRows[0].Cells[0].Value;
                DateTime Date = Convert.ToDateTime(DGV_Appointments.SelectedRows[0].Cells[3].Value);
                clsAppointment appointment = clsAppointment.FindAppointment(PatientID, Date);
                appointment.Cancel();
                _LoadAppointments();
            }
        }

        private void DGV_Appointments_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            DGV_Appointments.RowPrePaint += (s,el) =>
            {
                if (e.RowIndex >= 0 && e.RowIndex < DGV_Appointments.Rows.Count)
                {
                    DataGridViewRow row = DGV_Appointments.Rows[el.RowIndex];
                    string state = row.Cells["State"].Value?.ToString() ?? "";

                    Color backColor = Color.White; // افتراضي

                    switch (state)
                    {
                  
                        case "Confirmed":
                            backColor = Color.FromArgb(220, 255, 220); // أخضر فاتح
                            break;
                        case "Canceled":
                            backColor = Color.FromArgb(255, 220, 220); // أحمر فاتح
                            break;
                        case "Pending":
                            backColor = Color.FromArgb(255, 240, 200); // برتقالي فاتح
                            break;
                    }

                    row.DefaultCellStyle.BackColor = backColor;
                }
            };
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void DGV_Appointments_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                btnEditAppointment_Click(sender, e);
            }
        }

      

    }
    #endregion

  
}

