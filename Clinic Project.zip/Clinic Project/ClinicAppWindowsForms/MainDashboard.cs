﻿using ClinicAppWindowsForms.Employees_Forms;
using ClinicAppWindowsForms.Global_Classes;
using ClinicAppWindowsForms.MedicalRecords_Forms;
using ClinicAppWindowsForms.Patients_Forms;
using ClinicAppWindowsForms.Settings_Forms;
using ClinicAppWindowsForms.Users_Forms;
using ClinicLogicLayer;
using System;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;
using ClinicAppWindowsForms.Features_Forms;
using System.Web.UI.DataVisualization.Charting;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ClinicAppWindowsForms
{

    public partial class MainDashboard : Form
    {
        enum enNamesButtons { Appointment,Employees, MedicalRecords, Patients ,Users}
     

        private Button currentButton;

        Form LogIn;
     
        public MainDashboard(Form LogIn)
        {
            InitializeComponent();
            this.LogIn = LogIn;
        }

      
        private bool _HasUserPermissionToAccess(enNamesButtons en)

        {
            if (clsGlobal.CurrentUser.Permission == 1) return true; // Admin

          else if (clsGlobal.CurrentUser.Permission==2) // Doctor
            {
                switch (en)
                {
                    case enNamesButtons.MedicalRecords:
                    case enNamesButtons.Patients:
                        return true;

                }

            }
         
            else                     // Secretary
            {
                switch (en)  
                {
                    case enNamesButtons.Appointment:
                        return true;

                }

            }

            return false;
        }
        private void MainDashboard_Load(object sender, EventArgs e)
        {
            lb_UserName.Text = clsGlobal.CurrentUser.UserName;
            ConfigureStatusBar();

              _UpdateValueLablesAll5Minutes();


        }
        private void ConfigureStatusBar()
        {

            statusLabel.Text = "Ready- Developed by Clinic System "+ ConfigurationManager.AppSettings["VersionApp"];
            statusLabel.Dock = DockStyle.Fill;
            statusLabel.TextAlign = ContentAlignment.MiddleLeft;
            timeLabel.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
            timeLabel.Dock = DockStyle.Right;
            timeLabel.TextAlign = ContentAlignment.MiddleRight;

            panel4.BorderRadius(17);
            panel2.BorderRadius(17);
            panel3.BorderRadius(17);
            card.BorderRadius(17);
            btn_Tasks.BorderRadius(55);
            pb_LogoApp.BorderRadius(50);

        }

        private void NavButton_Click(object sender, EventArgs e)
        {

            Button clickedButton = (Button)sender;
            if (currentButton != null)
            {
                currentButton.BackColor = Color.FromArgb(52, 73, 94);
            }
            clickedButton.BackColor = Color.FromArgb(41, 128, 185);
            currentButton = clickedButton;

            switch (clickedButton.Tag.ToString())
            {

                case "2":
                    OpenPatientsForm();
                    break;
                case "3":
                    OpenAppointmentsForm();
                    break;
              //  case "4":
                 //   OpenPaymentsForm();
                   // break;
                case "5":
                    OpenMedicalRecordsForm();
                    break;
                case "6":
                    OpenUsersForm();
                    break;

                case "7":
                   OpenSettingsForm();
                   break;
                case "8":
                    BackToLogIn();
                    break;

            }
        }
        private void BackToLogIn()
        {
            if (MessageBox.Show("Are you sure to you want Log Out ??","Log Out",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                this.Hide();
                clsUtil.SaveLoginData("", "");
               LogIn form = new LogIn();    
                form.ShowDialog();
              form.Close(); 
            }
        }

     
        private  void _UpdateValueLables()
        {
           

            int count = clsPatient.GetCountPatientsPendingToDoctor(clsGlobal.CurrentUser.EmployeeID);
            int SumPaymentsToday = clsPayment.GetSumPaymentsDay();
            int CountAllPatientForDotor = clsPatient.GetCountPatientsToDoctor(clsGlobal.CurrentUser.EmployeeID);
            int AppointmentsDayCount = clsAppointment.GetCountAppontmentsDayByEmployeeID(clsGlobal.CurrentUser.EmployeeID);
            lb_PatientsCountValue.Text="["+count.ToString()+"]";

               lb_SumPaymentsDay.Text= "[" + SumPaymentsToday.ToString() + "] $";

            lb_CountAllPatients.Text= "[" + CountAllPatientForDotor.ToString() + "]";

            lb_AppointmentsDayCount.Text = "[" +  AppointmentsDayCount.ToString() + "]";





        }

        private async Task _UpdateValueLablesAll5Minutes()
        {

            _UpdateValueLables();

            await Task.Delay(300000).ContinueWith(t => _UpdateValueLablesAll5Minutes());
        }
        private void OpenPatientsForm()
        {
            if (!_HasUserPermissionToAccess(enNamesButtons.Appointment))
            {
                MessageBox.Show("you have not Permission to access this feature. !!", "Permission", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            PatientsForm patientsForm = new PatientsForm();
            patientsForm.Show();
        }

        private void OpenAppointmentsForm()
        {
            if (!_HasUserPermissionToAccess(enNamesButtons.Appointment))
            {
                MessageBox.Show("you have not Permission to access this feature. !!", "Permission", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            AppointmentsForm appointmentsForm = new AppointmentsForm();
            appointmentsForm.Show();
        }

        private void OpenMedicalRecordsForm()
        {
            if (!_HasUserPermissionToAccess(enNamesButtons.MedicalRecords))
            {
                MessageBox.Show("you have not Permission to access this feature. !!", "Permission", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            MedicalRecordForm medicalRecordsForm = new MedicalRecordForm();
            medicalRecordsForm.Show();
        }


        private void OpenSettingsForm()
        {
            SettingsForm settingsForm = new SettingsForm();
            settingsForm.Show();    
        }
        private void OpenUsersForm()
        {
            if (!_HasUserPermissionToAccess(enNamesButtons.Users))
            {
                MessageBox.Show("you have not Permission to access this feature. !!", "Permission", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            UserForm usersForm = new UserForm();
            usersForm.Show();   
        }

        private void btn_Employees_Click(object sender, EventArgs e)
        {
            if (!_HasUserPermissionToAccess(enNamesButtons.Employees))
            {
                MessageBox.Show("you have not Permission to access this feature. !!", "Permission", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            ListEmployeeForm listEmployeeForm = new ListEmployeeForm();
            listEmployeeForm.Show();

        }

       

        private void MainDashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();  
     
        }

      

        private void button2_Click(object sender, EventArgs e)
        {
             
            TasksForm tasks = new TasksForm();  
            tasks.Show();   
        }

   

      
    }
    public static class ControlExtensions
    {
        [System.Runtime.InteropServices.DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]

        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        public static void BorderRadius(this Control control, int radius)
        {
            control.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, control.Width, control.Height, radius, radius));
        }
    }


}











    
    
