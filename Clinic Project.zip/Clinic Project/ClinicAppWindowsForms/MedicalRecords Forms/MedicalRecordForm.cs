﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using ClinicLogicLayer;
using ClinicAppWindowsForms.Global_Classes;

namespace ClinicAppWindowsForms.MedicalRecords_Forms
{
    public partial class MedicalRecordForm : Form
    {
        public struct stPrescriptionInfo
        {
          public  Prescription prescription;
           public  clsPerson person;
            public clsDoctor Doctor;
        }

        stPrescriptionInfo prescriptionInfo;

        enum enMode { AddNew,Edit}
        enMode mode=enMode.AddNew;
        DataTable dt = new DataTable();
        private int _EmployeeID = clsGlobal.CurrentUser.EmployeeID;

        clsMedicalRecord medicalRecord = null;
        public MedicalRecordForm()
        {
            InitializeComponent();
        }

        private void UpdateStatistics()
        {
            if (dt == null) return;

            ;
            int total = DGV_Appointments.Rows.Count;
            try
            {
                int completed = dt.Select("State = 'Completed'").Length;
                int pending = dt.Select("State = 'Pending'").Length;

                lb_State.Text = $" All Appointments: {total}  | Completed: {completed}  | Pending: {pending}";
            }
            catch { }
        }


        private void _LoadAppointments()
        {
            dt = clsAppointment.GetAllAppontmentsByDoctor(_EmployeeID);

            DGV_Appointments.DataSource = dt;
            if (DGV_Appointments.Rows.Count > 0)
            {
                DGV_Appointments.Columns[0].HeaderText = "Appointment ID";
                DGV_Appointments.Columns[1].HeaderText = "Name";
                DGV_Appointments.Columns[2].HeaderText = "Time";
                DGV_Appointments.Columns[3].HeaderText = "Date";
                DGV_Appointments.Columns[4].HeaderText = "Status";
                DGV_Appointments.Columns["MedicalRecordID"].Visible = false;
            }
            UpdateStatistics();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void DGV_Appointments_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            DGV_Appointments.RowPrePaint += (s, el) =>
            {
                if (e.RowIndex >= 0 && e.RowIndex < DGV_Appointments.Rows.Count)
                {
                    DataGridViewRow row = DGV_Appointments.Rows[el.RowIndex];
                    string state = row.Cells["State"].Value?.ToString() ?? "";

                    Color backColor = Color.White; // افتراضي

                    switch (state)
                    {

                        case "Confirmed":
                            backColor = Color.FromArgb(220, 255, 220); // أخضر فاتح
                            break;
                        case "Canceled":
                            backColor = Color.FromArgb(255, 220, 220); // أحمر فاتح
                            break;
                        case "Pending":
                            backColor = Color.FromArgb(255, 240, 200); // برتقالي فاتح
                            break;
                    }

                    row.DefaultCellStyle.BackColor = backColor;
                }
            };
        }

        private void tb_SearchPatient_TextChanged(object sender, EventArgs e)
        {
            if (tb_SearchPatient.Text.Trim() == "")
            {
                dt.DefaultView.RowFilter = "";
                UpdateStatistics();

                return;
            }

            dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", "Name", tb_SearchPatient.Text.Trim());
            UpdateStatistics();
        }

        private void MedicalRecordForm_Load(object sender, EventArgs e)
        {
      
            btn_SaveRecord.Enabled = false;
            

            _LoadAppointments();
        }

        private void BtnAppointmentsDay_Click(object sender, EventArgs e)
        {
            if (dt != null)
            {
                string filter = $"Date ='{DateTime.Now.ToString("MM-dd-yyyy")}'";
                dt.DefaultView.RowFilter = filter;

                UpdateStatistics();

            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            DataGridViewRow row = DGV_Appointments.SelectedRows[0];
            if (row.Cells["State"].Value.ToString() == "Completed")
            {
                    detailsMedicalRecordToolStripMenuItem.Enabled = true;
                    addMedicalRecordToolStripMenuItem.Enabled = false;

                } else {
                    detailsMedicalRecordToolStripMenuItem.Enabled = false;
                    addMedicalRecordToolStripMenuItem.Enabled = true;
                     }

           
       }

        private void addMedicalRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mode = enMode.AddNew;
            _ResetValues();
            btn_SaveRecord.Enabled = true;
            tabControl1.SelectedTab = tabControl1.TabPages["tabPage2"];

        }

        private void detailsMedicalRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mode = enMode.Edit;

            _ResetValues();
            if (_FillDataMedicalRecordForAppointment())
            {

               btn_SaveRecord.Enabled = true;
                tabControl1.SelectedTab = tabControl1.TabPages["tabPage2"];
            }
        }

        private bool _FillDataMedicalRecordForAppointment()
        {

            DataGridViewRow row = DGV_Appointments.SelectedRows[0];
        int MedicalRecordID=(int)row.Cells["MedicalRecordID"].Value;
             medicalRecord=clsMedicalRecord.FindMedicalRecord(MedicalRecordID); 
            if(medicalRecord == null)
            {
                MessageBox.Show("Not Exist Medical Record for this Appointment..","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                btn_SaveRecord.Enabled = false;
                return false;
            }
            rtb_visitDescription.Text = medicalRecord.VisitDescription;
            rtb_diagnosis.Text= medicalRecord.Diagnosis;
            rtb_AdditionalNotes.Text= medicalRecord.AdditionalNotes;
  
            if (medicalRecord.prescription != null)
            {
                tb_MedicalName.Text = medicalRecord.prescription.MedicationName;
                tb_Dosage.Text = medicalRecord.prescription.Dosage;
                tb_Frequency.Text = medicalRecord.prescription.Frequency;
                DTP_StartDate.Value = medicalRecord.prescription.StartDate;
                DTP_EndDate.Value = medicalRecord.prescription.EndDate;
                tb_SpecialInstruction.Text = medicalRecord.prescription.SpecialInstruction;
            }
            else
            {
                MessageBox.Show("Not Exist Prescription for this Medical Record !!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            return true;
        }


        private bool _EditDataMedicalRecordForAppointment()
        {

        
             medicalRecord.VisitDescription= rtb_visitDescription.Text;
           medicalRecord.Diagnosis = rtb_diagnosis.Text ;
            medicalRecord.AdditionalNotes = rtb_AdditionalNotes.Text ;

            if (  medicalRecord.prescription!=null)
            {
                medicalRecord.prescription.MedicationName = tb_MedicalName.Text ;
                tb_Dosage.Text = medicalRecord.prescription.Dosage;
                tb_Frequency.Text = medicalRecord.prescription.Frequency;
                DTP_StartDate.Value = medicalRecord.prescription.StartDate;
                DTP_EndDate.Value = medicalRecord.prescription.EndDate;
                tb_SpecialInstruction.Text = medicalRecord.prescription.SpecialInstruction;
                if (!medicalRecord.prescription.SavePrescription())
                {
                    MessageBox.Show("Faild Save Prescription  !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
           else if (!string.IsNullOrEmpty(tb_MedicalName.Text.Trim()))
            {
                medicalRecord.prescription = new Prescription();
                tb_Dosage.Text = medicalRecord.prescription.Dosage;
                tb_Frequency.Text = medicalRecord.prescription.Frequency;
                DTP_StartDate.Value = medicalRecord.prescription.StartDate;
                DTP_EndDate.Value = medicalRecord.prescription.EndDate;
                tb_SpecialInstruction.Text = medicalRecord.prescription.SpecialInstruction;
                if (!medicalRecord.prescription.SavePrescription())
                {
                    MessageBox.Show("Faild Save Prescription  !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

            }

            if (!medicalRecord.SaveMedicalRecord()) { MessageBox.Show("Faild Edit Medical Record  !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); return false; };

            MessageBox.Show(" Edit Medical Record is Successfully..", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_SaveRecord.Enabled = false;
            return true;
        }

        private void _ResetValues()
        {

            rtb_visitDescription.Text = "";
            rtb_diagnosis.Text = "";
            rtb_AdditionalNotes.Text = "";

            tb_MedicalName.Text = "";
            tb_Dosage.Text = "";
            tb_Frequency.Text = "";
            DTP_StartDate.Value = DateTime.Now;
            DTP_EndDate.Value = DateTime.Now;
            tb_SpecialInstruction.Text = "";
        }


    
        private void SetCompleted_MedecalRecordIDToAppointment(int medicalRecordId)
        {
            int AppointmentID =(int) DGV_Appointments.SelectedRows[0].Cells[0].Value;
            clsAppointment appointment = clsAppointment.FindAppointment(AppointmentID);
            appointment.MedicalRecordID = medicalRecordId;

            appointment.SetMedicalRecordID();
           appointment.SetComplete();
            _LoadAppointments();
        }


        private Prescription _CreateNewPrescription()
        {
            Prescription prescription = new Prescription();
            prescription.MedicationName = tb_MedicalName.Text;
            prescription.Dosage = tb_Dosage.Text;
            prescription.Frequency = tb_Frequency.Text;
            prescription.StartDate = DTP_StartDate.Value;
            prescription.EndDate = DTP_EndDate.Value;
            prescription.SpecialInstruction = tb_SpecialInstruction.Text;
            return prescription;
        }
        private void btn_SaveRecord_Click(object sender, EventArgs e)

        {

            if(mode == enMode.Edit)
            {
                _EditDataMedicalRecordForAppointment(); return;
            }


            clsMedicalRecord medicalRecord = new clsMedicalRecord();

            medicalRecord.AdditionalNotes = rtb_AdditionalNotes.Text;
            medicalRecord.Diagnosis = rtb_diagnosis.Text;
            medicalRecord.VisitDescription = rtb_visitDescription.Text;


            if (!string.IsNullOrEmpty(tb_MedicalName.Text.Trim()))
            {
                Prescription prescription = _CreateNewPrescription();
                if (!prescription.SavePrescription())
                {
                    MessageBox.Show("Faild Save Prescription  !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return ;
                }
                medicalRecord.PrescriptionID = prescription.PrescriptionID;
            }

            if (medicalRecord.SaveMedicalRecord()) {
                MessageBox.Show(" save Medical Record is Successfully !!", "Save Medical Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btn_SaveRecord.Enabled = false;
                SetCompleted_MedecalRecordIDToAppointment(medicalRecord.MedicalRecordID);
            }
            else
            {
                MessageBox.Show("Faild save Medical Record  !!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(tb_MedicalName.Text))
            {
                MessageBox.Show("some fields null or empty,Please fill text.","Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ;
            }

            DataGridViewRow row = DGV_Appointments.SelectedRows[0];
            clsDoctor doctor = clsDoctor.FindDoctorByEmployeeID(clsGlobal.CurrentUser.EmployeeID);
            clsPerson person =clsPerson.Find( (string)row.Cells["Name"].Value);
            Prescription prescription = _CreateNewPrescription();
       
            prescriptionInfo.prescription = prescription;
            prescriptionInfo.person = person;
            prescriptionInfo.Doctor = doctor;

            PrintForm t = new PrintForm(prescriptionInfo);
            t.Show();
        }
    }

   
     
    }


