﻿namespace ClinicAppWindowsForms.MedicalRecords_Forms
{
    partial class MedicalRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb_State = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_SaveRecord = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_SearchPatient = new System.Windows.Forms.TextBox();
            this.BtnAppointmentsDay = new System.Windows.Forms.Button();
            this.DGV_Appointments = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addMedicalRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detailsMedicalRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rtb_AdditionalNotes = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rtb_diagnosis = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rtb_visitDescription = new System.Windows.Forms.RichTextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tb_SpecialInstruction = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.DTP_EndDate = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.DTP_StartDate = new System.Windows.Forms.DateTimePicker();
            this.tb_Dosage = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_Frequency = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_MedicalName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Appointments)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(20);
            this.panel1.Size = new System.Drawing.Size(1085, 100);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(13, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(275, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "🏥  Medical Record";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.tabControl1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(10, 110);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1085, 655);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(244)))), ((int)(((byte)(247)))));
            this.panel3.Controls.Add(this.lb_State);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.btn_SaveRecord);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 585);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(20);
            this.panel3.Size = new System.Drawing.Size(1085, 70);
            this.panel3.TabIndex = 1;
            // 
            // lb_State
            // 
            this.lb_State.AutoSize = true;
            this.lb_State.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_State.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.lb_State.Location = new System.Drawing.Point(7, 12);
            this.lb_State.Name = "lb_State";
            this.lb_State.Size = new System.Drawing.Size(336, 19);
            this.lb_State.TabIndex = 7;
            this.lb_State.Text = "All Appointments: 0 |  Sure: 0 | Waitting: 0";
            // 
            // button3
            // 
            this.button3.AutoSize = true;
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.button3.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(722, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(159, 45);
            this.button3.TabIndex = 2;
            this.button3.Text = "🖨 Print ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.AutoSize = true;
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(165)))), ((int)(((byte)(166)))));
            this.button2.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::ClinicAppWindowsForms.Properties.Resources.Close_32;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button2.Location = new System.Drawing.Point(541, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(159, 45);
            this.button2.TabIndex = 1;
            this.button2.Text = "close";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_SaveRecord
            // 
            this.btn_SaveRecord.AutoSize = true;
            this.btn_SaveRecord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btn_SaveRecord.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SaveRecord.ForeColor = System.Drawing.Color.White;
            this.btn_SaveRecord.Location = new System.Drawing.Point(903, 12);
            this.btn_SaveRecord.Name = "btn_SaveRecord";
            this.btn_SaveRecord.Size = new System.Drawing.Size(159, 45);
            this.btn_SaveRecord.TabIndex = 7;
            this.btn_SaveRecord.Text = "💾 Save Record";
            this.btn_SaveRecord.UseVisualStyleBackColor = false;
            this.btn_SaveRecord.Click += new System.EventHandler(this.btn_SaveRecord_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(15, 8);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1085, 570);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.tb_SearchPatient);
            this.tabPage1.Controls.Add(this.BtnAppointmentsDay);
            this.tabPage1.Controls.Add(this.DGV_Appointments);
            this.tabPage1.Location = new System.Drawing.Point(4, 38);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(20);
            this.tabPage1.Size = new System.Drawing.Size(1077, 528);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "📄 Appointments";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 19);
            this.label9.TabIndex = 5;
            this.label9.Text = "🔍 Patient Name:";
            // 
            // tb_SearchPatient
            // 
            this.tb_SearchPatient.Location = new System.Drawing.Point(141, 16);
            this.tb_SearchPatient.Name = "tb_SearchPatient";
            this.tb_SearchPatient.Size = new System.Drawing.Size(247, 27);
            this.tb_SearchPatient.TabIndex = 6;
            this.tb_SearchPatient.TextChanged += new System.EventHandler(this.tb_SearchPatient_TextChanged);
            // 
            // BtnAppointmentsDay
            // 
            this.BtnAppointmentsDay.AutoSize = true;
            this.BtnAppointmentsDay.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAppointmentsDay.Location = new System.Drawing.Point(927, 14);
            this.BtnAppointmentsDay.Name = "BtnAppointmentsDay";
            this.BtnAppointmentsDay.Size = new System.Drawing.Size(140, 34);
            this.BtnAppointmentsDay.TabIndex = 3;
            this.BtnAppointmentsDay.Text = " Appointments Day";
            this.BtnAppointmentsDay.UseVisualStyleBackColor = true;
            this.BtnAppointmentsDay.Click += new System.EventHandler(this.BtnAppointmentsDay_Click);
            // 
            // DGV_Appointments
            // 
            this.DGV_Appointments.AllowUserToAddRows = false;
            this.DGV_Appointments.AllowUserToDeleteRows = false;
            this.DGV_Appointments.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_Appointments.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.DGV_Appointments.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGV_Appointments.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.DGV_Appointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Appointments.ContextMenuStrip = this.contextMenuStrip1;
            this.DGV_Appointments.EnableHeadersVisualStyles = false;
            this.DGV_Appointments.Location = new System.Drawing.Point(3, 58);
            this.DGV_Appointments.MultiSelect = false;
            this.DGV_Appointments.Name = "DGV_Appointments";
            this.DGV_Appointments.ReadOnly = true;
            this.DGV_Appointments.RowHeadersVisible = false;
            this.DGV_Appointments.RowHeadersWidth = 51;
            this.DGV_Appointments.RowTemplate.Height = 24;
            this.DGV_Appointments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGV_Appointments.Size = new System.Drawing.Size(1071, 470);
            this.DGV_Appointments.StandardTab = true;
            this.DGV_Appointments.TabIndex = 1;
            this.DGV_Appointments.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.DGV_Appointments_RowPrePaint);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addMedicalRecordToolStripMenuItem,
            this.detailsMedicalRecordToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(258, 80);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // addMedicalRecordToolStripMenuItem
            // 
            this.addMedicalRecordToolStripMenuItem.Image = global::ClinicAppWindowsForms.Properties.Resources.edit_321;
            this.addMedicalRecordToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.addMedicalRecordToolStripMenuItem.Name = "addMedicalRecordToolStripMenuItem";
            this.addMedicalRecordToolStripMenuItem.Size = new System.Drawing.Size(257, 38);
            this.addMedicalRecordToolStripMenuItem.Text = "Add Medical Record";
            this.addMedicalRecordToolStripMenuItem.Click += new System.EventHandler(this.addMedicalRecordToolStripMenuItem_Click);
            // 
            // detailsMedicalRecordToolStripMenuItem
            // 
            this.detailsMedicalRecordToolStripMenuItem.Image = global::ClinicAppWindowsForms.Properties.Resources.PersonDetails_32;
            this.detailsMedicalRecordToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.detailsMedicalRecordToolStripMenuItem.Name = "detailsMedicalRecordToolStripMenuItem";
            this.detailsMedicalRecordToolStripMenuItem.Size = new System.Drawing.Size(257, 38);
            this.detailsMedicalRecordToolStripMenuItem.Text = "Details Medical Record";
            this.detailsMedicalRecordToolStripMenuItem.Click += new System.EventHandler(this.detailsMedicalRecordToolStripMenuItem_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 38);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1077, 528);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "📄 Medical Record";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rtb_AdditionalNotes);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(3, 303);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1071, 150);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Additional Notes";
            // 
            // rtb_AdditionalNotes
            // 
            this.rtb_AdditionalNotes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.rtb_AdditionalNotes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtb_AdditionalNotes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_AdditionalNotes.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_AdditionalNotes.Location = new System.Drawing.Point(3, 24);
            this.rtb_AdditionalNotes.Name = "rtb_AdditionalNotes";
            this.rtb_AdditionalNotes.Size = new System.Drawing.Size(1065, 123);
            this.rtb_AdditionalNotes.TabIndex = 0;
            this.rtb_AdditionalNotes.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rtb_diagnosis);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(3, 153);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1071, 150);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Diagnosis";
            // 
            // rtb_diagnosis
            // 
            this.rtb_diagnosis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.rtb_diagnosis.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtb_diagnosis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_diagnosis.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_diagnosis.Location = new System.Drawing.Point(3, 24);
            this.rtb_diagnosis.Name = "rtb_diagnosis";
            this.rtb_diagnosis.Size = new System.Drawing.Size(1065, 123);
            this.rtb_diagnosis.TabIndex = 0;
            this.rtb_diagnosis.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtb_visitDescription);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1071, 150);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Visit Description";
            // 
            // rtb_visitDescription
            // 
            this.rtb_visitDescription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.rtb_visitDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtb_visitDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_visitDescription.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb_visitDescription.Location = new System.Drawing.Point(3, 24);
            this.rtb_visitDescription.Name = "rtb_visitDescription";
            this.rtb_visitDescription.Size = new System.Drawing.Size(1065, 123);
            this.rtb_visitDescription.TabIndex = 0;
            this.rtb_visitDescription.Text = "";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Location = new System.Drawing.Point(4, 38);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1077, 528);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "💊 Prescription";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tb_SpecialInstruction);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.DTP_EndDate);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.DTP_StartDate);
            this.panel4.Controls.Add(this.tb_Dosage);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.tb_Frequency);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.tb_MedicalName);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(10);
            this.panel4.Size = new System.Drawing.Size(1077, 528);
            this.panel4.TabIndex = 0;
            // 
            // tb_SpecialInstruction
            // 
            this.tb_SpecialInstruction.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_SpecialInstruction.Location = new System.Drawing.Point(366, 440);
            this.tb_SpecialInstruction.Multiline = true;
            this.tb_SpecialInstruction.Name = "tb_SpecialInstruction";
            this.tb_SpecialInstruction.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tb_SpecialInstruction.Size = new System.Drawing.Size(330, 80);
            this.tb_SpecialInstruction.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(162, 445);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(162, 19);
            this.label8.TabIndex = 11;
            this.label8.Text = "Special Instructions :";
            // 
            // DTP_EndDate
            // 
            this.DTP_EndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_EndDate.Location = new System.Drawing.Point(370, 372);
            this.DTP_EndDate.MinDate = new System.DateTime(2000, 10, 18, 0, 0, 0, 0);
            this.DTP_EndDate.Name = "DTP_EndDate";
            this.DTP_EndDate.Size = new System.Drawing.Size(346, 27);
            this.DTP_EndDate.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(162, 376);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 19);
            this.label7.TabIndex = 9;
            this.label7.Text = "End Date :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(162, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "Start Date :";
            // 
            // DTP_StartDate
            // 
            this.DTP_StartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_StartDate.Location = new System.Drawing.Point(370, 304);
            this.DTP_StartDate.MinDate = new System.DateTime(2000, 10, 18, 0, 0, 0, 0);
            this.DTP_StartDate.Name = "DTP_StartDate";
            this.DTP_StartDate.Size = new System.Drawing.Size(346, 27);
            this.DTP_StartDate.TabIndex = 4;
            // 
            // tb_Dosage
            // 
            this.tb_Dosage.Location = new System.Drawing.Point(370, 168);
            this.tb_Dosage.Name = "tb_Dosage";
            this.tb_Dosage.Size = new System.Drawing.Size(346, 27);
            this.tb_Dosage.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(162, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Dosage :";
            // 
            // tb_Frequency
            // 
            this.tb_Frequency.Location = new System.Drawing.Point(370, 236);
            this.tb_Frequency.Name = "tb_Frequency";
            this.tb_Frequency.Size = new System.Drawing.Size(346, 27);
            this.tb_Frequency.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(162, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 19);
            this.label4.TabIndex = 3;
            this.label4.Text = "Frequency :";
            // 
            // tb_MedicalName
            // 
            this.tb_MedicalName.Location = new System.Drawing.Point(370, 100);
            this.tb_MedicalName.Name = "tb_MedicalName";
            this.tb_MedicalName.Size = new System.Drawing.Size(346, 27);
            this.tb_MedicalName.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(162, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Medical Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(73)))), ((int)(((byte)(94)))));
            this.label2.Location = new System.Drawing.Point(365, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(331, 27);
            this.label2.TabIndex = 0;
            this.label2.Text = "💊 Medical Prescription Data";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // MedicalRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1105, 775);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MedicalRecordForm";
            this.Padding = new System.Windows.Forms.Padding(10);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "📋 Medical Record";
            this.Load += new System.EventHandler(this.MedicalRecordForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Appointments)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rtb_visitDescription;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox rtb_diagnosis;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RichTextBox rtb_AdditionalNotes;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_SaveRecord;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_MedicalName;
        private System.Windows.Forms.TextBox tb_Dosage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_Frequency;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker DTP_EndDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker DTP_StartDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_SpecialInstruction;
        private System.Windows.Forms.DataGridView DGV_Appointments;
        private System.Windows.Forms.Button BtnAppointmentsDay;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_SearchPatient;
        private System.Windows.Forms.Label lb_State;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addMedicalRecordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detailsMedicalRecordToolStripMenuItem;
    }
}