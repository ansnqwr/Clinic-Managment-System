﻿using ClinicAppWindowsForms.Employees_Forms;
using ClinicLogicLayer;
using System;

using System.Windows.Forms;

namespace ClinicAppWindowsForms.Users_Forms
{
    public partial class AddEditUserForm : Form
    {
        public enum enMode { AddNew = 0, Update = 1 };
        private enMode _Mode;
        private int _EmployeeID = -1;
        clsUser _User;
        public AddEditUserForm(int EmployeeID)
        {
            InitializeComponent();

            _Mode = enMode.Update;
            _EmployeeID = EmployeeID;
            _LoadData();
        }
        public AddEditUserForm()
        {
            InitializeComponent();

            _Mode = enMode.AddNew;
        }

        private void AddEditUserForm_Load(object sender, EventArgs e)
        {

            _ResetDefualtValues();

            if (_Mode == enMode.Update)
                _LoadData();

        }
        private void _LoadData()
        {

            _User = clsUser.FindUserByEmployeeID(_EmployeeID);
            ctrlEmployeeInfoWithFilter1.FilterEnabled = false;

            if (_User == null)
            {
                MessageBox.Show("No User with ID = " + _User, "User Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();

                return;
            }

            lblUserID.Text = _User.UserID.ToString();
            txtUserName.Text = _User.UserName;
            txtPassword.Text = _User.Password;
            txtConfirmPassword.Text = _User.Password;
            chkIsActive.Checked =Convert.ToBoolean( _User.AccountStatus);
            ctrlEmployeeInfoWithFilter1.LoadInfo(_EmployeeID);
        }

   
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ctrlEmployeeInfoWithFilter1_OnEmployeeSelected(int obj)
        {
            if (obj == -1)
            {
                MessageBox.Show("No Employee with ID = " + obj, " Employee Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                ctrlEmployeeInfoWithFilter1.ResetData();
                return;
            }
            clsUser user = clsUser.FindUserByEmployeeID(obj);
            if (user != null)
            {
                MessageBox.Show("Selected Employee already has a user, choose another one.", "Select another Person", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                ctrlEmployeeInfoWithFilter1.ResetData();

                return;
            }

            btn_Next.Enabled = true;

        }


        private void _ResetDefualtValues()
        {

            if (_Mode == enMode.AddNew)
            {
                lblTitle.Text = "Add New User";
                this.Text = "Add New User";
                _User = new clsUser();

                tpLoginInfo.Enabled = false;
                btn_Next.Enabled = false;

            }
            else
            {
                lblTitle.Text = "Update User";
                this.Text = "Update User";

               tpLoginInfo.Enabled = true;
                btnSave.Enabled = true;


            }

            txtUserName.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            chkIsActive.Checked = true;


        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }

            _User.EmployeeID = ctrlEmployeeInfoWithFilter1.EmployeeID;
            _User.UserName = txtUserName.Text.Trim();
            _User.Password = txtPassword.Text.Trim();
            _User.AccountStatus =Convert.ToByte(chkIsActive.Checked);
            _User.Permission=_GetPermissionNumber();



            if (_User.SaveUser())
            {
                lblUserID.Text = _User.UserID.ToString();
                _Mode = enMode.Update;
                lblTitle.Text = "Update User";
                this.Text = "Update User";
                btnSave.Enabled = false;    
                MessageBox.Show("Data Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }


        private int _GetPermissionNumber()
        {
            if (rb_Admin.Checked) return 1;

            else if (rb_Doctor.Checked) return 2;

            else return 3;
        }

        private void txtConfirmPassword_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (txtConfirmPassword.Text.Trim() != txtPassword.Text.Trim())
            {
                e.Cancel = true;
                errorProvider1.SetError(txtConfirmPassword, "Password Confirmation does not match Password!");
            }
            else
            {
                errorProvider1.SetError(txtConfirmPassword, null);
            };
        }

        private void txtPassword_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtPassword, "Password cannot be blank");
            }
            else
            {
                errorProvider1.SetError(txtPassword, null);
            };
        }

        private void txtUserName_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserName.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtUserName, "Username cannot be blank");
                return;
            }
            else
            {
                errorProvider1.SetError(txtUserName, null);
            };


            if (_Mode == enMode.AddNew)
            {

                if (clsUser.IsUserExist(txtUserName.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(txtUserName, "username is used by another user");
                }
                else
                {
                    errorProvider1.SetError(txtUserName, null);
                };
            }
            else
            {
                //incase update make sure not to use anothers user name
                if (_User.UserName != txtUserName.Text.Trim())
                {
                    if (clsUser.IsUserExist(txtUserName.Text.Trim()))
                    {
                        e.Cancel = true;
                        errorProvider1.SetError(txtUserName, "username is used by another user");
                        return;
                    }
                    else
                    {
                        errorProvider1.SetError(txtUserName, null);
                    };
                }
            }
        }

        private void chkIsActive_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkIsActive.Checked) chkIsActive.ForeColor = System.Drawing.Color.DarkRed;

            else chkIsActive.ForeColor = System.Drawing.Color.DarkGreen;
        }

        private void link_GoListEmployees_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ListEmployeeForm listEmployeeForm = new ListEmployeeForm(); 
            listEmployeeForm.ShowDialog();
        }

        private void btn_Next_Click(object sender, EventArgs e)
        {
            if (ctrlEmployeeInfoWithFilter1.EmployeeID == -1)
            {
                MessageBox.Show("Please Select a Employee", "Select a Employee", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }

            btnSave.Enabled = true;
            tpLoginInfo.Enabled = true;
            tcUserInfo.SelectedTab = tcUserInfo.TabPages["tpLoginInfo"];
        }
    }
}
