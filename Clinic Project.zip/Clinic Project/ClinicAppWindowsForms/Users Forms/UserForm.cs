﻿using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Users_Forms
{
    public partial class UserForm : Form
    {
        DataTable dt = new DataTable();

        public UserForm()
        {
            InitializeComponent();

        }
        private void UserForm_Load(object sender, EventArgs e)

        {
            cb_AccountStatus.Visible = false;
            cbFilterBy.SelectedIndex = 0;   
            cb_AccountStatus.SelectedIndex = 0; 
            InitializeUsersForm();

        }


        private void InitializeUsersForm()
        {

            dt = clsUser.GetAllUsers();

            UsersGrid.DataSource = dt;
            if (UsersGrid.Rows.Count > 0)
            {
                UsersGrid.Columns[0].HeaderText = "User ID";
                UsersGrid.Columns[0].Width = 50;

                UsersGrid.Columns[1].HeaderText = "User Name";
                UsersGrid.Columns[1].Width = 80;

                UsersGrid.Columns[2].HeaderText = "Permission";
                UsersGrid.Columns[2].Width = 80;

                UsersGrid.Columns[3].HeaderText = "Employee ID";
                UsersGrid.Columns[3].Width = 70;

                UsersGrid.Columns[4].HeaderText = "Account Status";
                UsersGrid.Columns[4].Width = 80;


            }



            lb_RecordsNumber.Text = "# Records:  " + UsersGrid.Rows.Count.ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_AddNewUser_Click(object sender, EventArgs e)
        {
            AddEditUserForm addEditUserForm = new AddEditUserForm();
            addEditUserForm.ShowDialog();
            UserForm_Load(null, null);
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            int EmployeeID = (int) UsersGrid.SelectedRows[0].Cells[3].Value;
            AddEditUserForm addEditUserForm = new AddEditUserForm(EmployeeID);
            addEditUserForm.ShowDialog();
            UserForm_Load(null, null);
        }

        private void cbFilterBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbFilterBy.Focus();
            if (cbFilterBy.SelectedIndex == 3)
            {
                txtFilterValue.Visible = false;
                cb_AccountStatus.Visible = true;
                cb_AccountStatus.SelectedIndex=0;
            }
            else
            {
                cb_AccountStatus.Visible = false;
                txtFilterValue.Visible = true;  
            }
        }

        private void txtFilterValue_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            switch (cbFilterBy.Text)
            {
                case "User ID":
                    FilterColumn = "UserID";
                    break;
                case "UserName":
                    FilterColumn = "UserName";
                    break;

                case "Is Active":
                    FilterColumn = "AccountStatus";
                    break;

          
                default:
                    FilterColumn = "None";
                    break;

            }

            if (txtFilterValue.Text.Trim() == "" || FilterColumn == "None")
            {
                dt.DefaultView.RowFilter = "";
                lb_RecordsNumber.Text = UsersGrid.Rows.Count.ToString();
                return;
            }

            if (FilterColumn == "UserID")
                dt.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, txtFilterValue.Text.Trim());
            else
                dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, txtFilterValue.Text.Trim());



            lb_RecordsNumber.Text = UsersGrid.Rows.Count.ToString();
        }

        private void cb_AccountStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FilterColumn = "AccountStatus";
            try
            {
                switch (cb_AccountStatus.SelectedIndex)
                {
                    case 1:
                        dt.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, 1);
                        break;
                    case 2:
                        dt.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, 0);
                        break;

                    default:
                        InitializeUsersForm();
                        break;
                }
            }
            catch (Exception) { Console.WriteLine(e); }
            lb_RecordsNumber.Text = UsersGrid.Rows.Count.ToString();

        }

        private void UsersGrid_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
           UsersGrid.RowPrePaint += (s, el) =>
            {
                if (e.RowIndex >= 0 && e.RowIndex < UsersGrid.Rows.Count)
                {
                    DataGridViewRow row = UsersGrid.Rows[el.RowIndex];
                    string state = row.Cells["Status"].Value?.ToString() ?? "";

                    Color backColor = Color.White; // افتراضي

                    switch (state)
                    {

                        case "Active":
                            backColor = Color.FromArgb(220, 255, 220); // أخضر فاتح
                            break;
                        case "Not Active":
                            backColor = Color.FromArgb(255, 220, 220); // أحمر فاتح
                            break;
                 
                    }

                    row.DefaultCellStyle.BackColor = backColor;
                }
            };
        }
    }

}