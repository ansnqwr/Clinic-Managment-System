﻿using ClinicLogicLayer;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Patients_Forms
{
    public partial class PatientsForm : Form
    {
        public PatientsForm()
        {
            InitializeComponent();
        }
        DataTable dt = new DataTable();
        int PersonID = -1;
        clsPatient patient;
        private void PatientsForm_Load(object sender, EventArgs e)
        {
            cbFilterBy.SelectedIndex = 0;
            cbFilterBy.Visible = true;
            _LoadData();
        }
        public void _LoadData()
        {
            dt = clsPatient.GetAllPatients();

            PatientsGrid.DataSource = dt;
            if (PatientsGrid.Rows.Count > 0)
            {
                PatientsGrid.Columns[0].HeaderText = "Patient ID";
                PatientsGrid.Columns[0].Width = 50;

                PatientsGrid.Columns[1].HeaderText = "Name";
                PatientsGrid.Columns[1].Width = 112;

                PatientsGrid.Columns[2].HeaderText = "Age";
                PatientsGrid.Columns[2].Width = 112;

                PatientsGrid.Columns[3].HeaderText = "Gender";
                PatientsGrid.Columns[3].Width = 70;

                PatientsGrid.Columns[4].HeaderText = "Phone";
                PatientsGrid.Columns[4].Width = 120;

                PatientsGrid.Columns[5].HeaderText = "Email";
                PatientsGrid.Columns[5].Width = 130;

                PatientsGrid.Columns[6].HeaderText = "Addrees";
                PatientsGrid.Columns[6].Width = 112;

            }



            lb_RecordsNumber.Text = "# Records: " + PatientsGrid.Rows.Count.ToString();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

     

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void personDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int PatientID = (int)PatientsGrid.SelectedRows[0].Cells[0].Value;

            PersonDetailsForm personDetails = new PersonDetailsForm(clsPatient.FindPatient(PatientID));
            personDetails.ShowDialog(); 
        }

        private void btn_AddNewPatient_Click(object sender, EventArgs e)
        {
            AddEditPersonForm addEditPatientForm = new AddEditPersonForm();
            addEditPatientForm.DataBack += CreateNewPatient;
            addEditPatientForm.ShowDialog();
            _LoadData();
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            int PatientID = (int)PatientsGrid.SelectedRows[0].Cells[0].Value;
            AddEditPersonForm addEditPatientForm = new AddEditPersonForm(clsPatient.FindPatient(PatientID).ID);
            addEditPatientForm.ShowDialog();
            _LoadData();

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void cbFilterBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbFilterBy.Visible = (cbFilterBy.Text != "None");

            if (cbFilterBy.Visible)
            {
                cbFilterBy.Text = "";
                cbFilterBy.Focus();
            }
        }

        private void txtFilterValue_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            switch (cbFilterBy.Text)
            {
                case "Patient ID":
                    FilterColumn = "PatientID";
                    break;
                case "Name":
                    FilterColumn = "Name";
                    break;

                case "Gender":
                    FilterColumn = "Gender";
                    break;

                case "Phone":
                    FilterColumn = "Phone";
                    break;

                case "Email":
                    FilterColumn = "Email";
                    break;
                default:
                    FilterColumn = "None";
                    break;

            }

            if (txtFilterValue.Text.Trim() == "" || FilterColumn == "None")
            {
                dt.DefaultView.RowFilter = "";
                lb_RecordsNumber.Text = PatientsGrid.Rows.Count.ToString();
                return;
            }

          if (FilterColumn == "PatientID")
                dt.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, txtFilterValue.Text.Trim());
          else
                dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, txtFilterValue.Text.Trim());



            lb_RecordsNumber.Text = PatientsGrid.Rows.Count.ToString();
        }

        private void CreateNewPatient(clsPerson Person,int personID)
        {
            PersonID= personID; 
            if (PersonID == -1)
            {
                MessageBox.Show("Add New Person is not successfully.", "Erorr", MessageBoxButtons.OK);
                return;
            }
            patient = new clsPatient();
            patient.ID = Person.ID;
            patient.Name = Person.Name;
            patient.Age=Person.Age;
            patient.Email=Person.Email;
            patient.Address=Person.Address;
            patient.PhoneNumber=Person.PhoneNumber;
              if (Person.Gender==0) patient.Gender = 'M'; else patient.Gender = 'F';

            if (patient.SavePatient())
            {             
              
                MessageBox.Show("Add New Patient Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

  
    }

        
            
        
