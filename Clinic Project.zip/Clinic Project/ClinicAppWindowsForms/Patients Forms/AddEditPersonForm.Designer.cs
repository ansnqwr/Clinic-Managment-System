﻿namespace ClinicAppWindowsForms.Patients_Forms
{
    partial class AddEditPersonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lb_ND = new System.Windows.Forms.Label();
            this.panel_PersonInfo = new System.Windows.Forms.Panel();
            this.tb_Age = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Email = new System.Windows.Forms.TextBox();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.tb_Phone = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Last = new System.Windows.Forms.Label();
            this.lb_First = new System.Windows.Forms.Label();
            this.tb_LastName = new System.Windows.Forms.TextBox();
            this.tb_FirstName = new System.Windows.Forms.TextBox();
            this.lb_Name = new System.Windows.Forms.Label();
            this.lb_Gender = new System.Windows.Forms.Label();
            this.lb_Email = new System.Windows.Forms.Label();
            this.lb_Address = new System.Windows.Forms.Label();
            this.lb_PatientID = new System.Windows.Forms.Label();
            this.lb_AddEditPerson = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel_PersonInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_ND
            // 
            this.lb_ND.AutoSize = true;
            this.lb_ND.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ND.ForeColor = System.Drawing.Color.BlueViolet;
            this.lb_ND.Location = new System.Drawing.Point(122, 64);
            this.lb_ND.Name = "lb_ND";
            this.lb_ND.Size = new System.Drawing.Size(44, 22);
            this.lb_ND.TabIndex = 7;
            this.lb_ND.Text = "N/D";
            // 
            // panel_PersonInfo
            // 
            this.panel_PersonInfo.Controls.Add(this.tb_Age);
            this.panel_PersonInfo.Controls.Add(this.btn_Save);
            this.panel_PersonInfo.Controls.Add(this.btn_Close);
            this.panel_PersonInfo.Controls.Add(this.tb_Address);
            this.panel_PersonInfo.Controls.Add(this.tb_Email);
            this.panel_PersonInfo.Controls.Add(this.rb_Female);
            this.panel_PersonInfo.Controls.Add(this.rb_Male);
            this.panel_PersonInfo.Controls.Add(this.tb_Phone);
            this.panel_PersonInfo.Controls.Add(this.label2);
            this.panel_PersonInfo.Controls.Add(this.label1);
            this.panel_PersonInfo.Controls.Add(this.lb_Last);
            this.panel_PersonInfo.Controls.Add(this.lb_First);
            this.panel_PersonInfo.Controls.Add(this.tb_LastName);
            this.panel_PersonInfo.Controls.Add(this.tb_FirstName);
            this.panel_PersonInfo.Controls.Add(this.lb_Name);
            this.panel_PersonInfo.Controls.Add(this.lb_Gender);
            this.panel_PersonInfo.Controls.Add(this.lb_Email);
            this.panel_PersonInfo.Controls.Add(this.lb_Address);
            this.panel_PersonInfo.Location = new System.Drawing.Point(16, 89);
            this.panel_PersonInfo.Name = "panel_PersonInfo";
            this.panel_PersonInfo.Size = new System.Drawing.Size(745, 449);
            this.panel_PersonInfo.TabIndex = 6;
            // 
            // tb_Age
            // 
            this.tb_Age.BackColor = System.Drawing.Color.White;
            this.tb_Age.Location = new System.Drawing.Point(169, 98);
            this.tb_Age.Multiline = true;
            this.tb_Age.Name = "tb_Age";
            this.tb_Age.Size = new System.Drawing.Size(174, 28);
            this.tb_Age.TabIndex = 3;
            this.tb_Age.Validating += new System.ComponentModel.CancelEventHandler(this.ValidateEmptyTextBox);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Save.Image = global::ClinicAppWindowsForms.Properties.Resources.Save_32;
            this.btn_Save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Save.Location = new System.Drawing.Point(569, 389);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(137, 42);
            this.btn_Save.TabIndex = 7;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Red;
            this.btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Close.Image = global::ClinicAppWindowsForms.Properties.Resources.Close_32;
            this.btn_Close.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Close.Location = new System.Drawing.Point(406, 389);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(137, 42);
            this.btn_Close.TabIndex = 29;
            this.btn_Close.Text = "Close";
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // tb_Address
            // 
            this.tb_Address.BackColor = System.Drawing.Color.White;
            this.tb_Address.Location = new System.Drawing.Point(169, 270);
            this.tb_Address.Multiline = true;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(541, 104);
            this.tb_Address.TabIndex = 6;
            // 
            // tb_Email
            // 
            this.tb_Email.BackColor = System.Drawing.Color.White;
            this.tb_Email.Location = new System.Drawing.Point(169, 152);
            this.tb_Email.Multiline = true;
            this.tb_Email.Name = "tb_Email";
            this.tb_Email.Size = new System.Drawing.Size(174, 28);
            this.tb_Email.TabIndex = 4;
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Female.Location = new System.Drawing.Point(258, 217);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(85, 24);
            this.rb_Female.TabIndex = 22;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "Female";
            this.rb_Female.UseVisualStyleBackColor = true;
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Checked = true;
            this.rb_Male.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Male.Location = new System.Drawing.Point(169, 217);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(66, 24);
            this.rb_Male.TabIndex = 21;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "Male";
            this.rb_Male.UseVisualStyleBackColor = true;
            // 
            // tb_Phone
            // 
            this.tb_Phone.BackColor = System.Drawing.Color.White;
            this.tb_Phone.Location = new System.Drawing.Point(500, 159);
            this.tb_Phone.Multiline = true;
            this.tb_Phone.Name = "tb_Phone";
            this.tb_Phone.Size = new System.Drawing.Size(174, 28);
            this.tb_Phone.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(412, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 21);
            this.label2.TabIndex = 19;
            this.label2.Text = "Phone:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 21);
            this.label1.TabIndex = 17;
            this.label1.Text = "Age:";
            // 
            // lb_Last
            // 
            this.lb_Last.AutoSize = true;
            this.lb_Last.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Last.Location = new System.Drawing.Point(412, 20);
            this.lb_Last.Name = "lb_Last";
            this.lb_Last.Size = new System.Drawing.Size(42, 20);
            this.lb_Last.TabIndex = 13;
            this.lb_Last.Text = "Last";
            // 
            // lb_First
            // 
            this.lb_First.AutoSize = true;
            this.lb_First.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_First.Location = new System.Drawing.Point(219, 18);
            this.lb_First.Name = "lb_First";
            this.lb_First.Size = new System.Drawing.Size(43, 20);
            this.lb_First.TabIndex = 12;
            this.lb_First.Text = "First";
            // 
            // tb_LastName
            // 
            this.tb_LastName.BackColor = System.Drawing.Color.White;
            this.tb_LastName.Location = new System.Drawing.Point(369, 43);
            this.tb_LastName.Multiline = true;
            this.tb_LastName.Name = "tb_LastName";
            this.tb_LastName.Size = new System.Drawing.Size(174, 28);
            this.tb_LastName.TabIndex = 2;
            this.tb_LastName.Validating += new System.ComponentModel.CancelEventHandler(this.ValidateEmptyTextBox);
            // 
            // tb_FirstName
            // 
            this.tb_FirstName.BackColor = System.Drawing.Color.White;
            this.tb_FirstName.Location = new System.Drawing.Point(169, 43);
            this.tb_FirstName.Multiline = true;
            this.tb_FirstName.Name = "tb_FirstName";
            this.tb_FirstName.Size = new System.Drawing.Size(174, 28);
            this.tb_FirstName.TabIndex = 1;
            this.tb_FirstName.Validating += new System.ComponentModel.CancelEventHandler(this.ValidateEmptyTextBox);
            // 
            // lb_Name
            // 
            this.lb_Name.AutoSize = true;
            this.lb_Name.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Name.Location = new System.Drawing.Point(35, 43);
            this.lb_Name.Name = "lb_Name";
            this.lb_Name.Size = new System.Drawing.Size(62, 21);
            this.lb_Name.TabIndex = 3;
            this.lb_Name.Text = "Name:";
            // 
            // lb_Gender
            // 
            this.lb_Gender.AutoSize = true;
            this.lb_Gender.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Gender.Location = new System.Drawing.Point(22, 219);
            this.lb_Gender.Name = "lb_Gender";
            this.lb_Gender.Size = new System.Drawing.Size(75, 21);
            this.lb_Gender.TabIndex = 5;
            this.lb_Gender.Text = "Gender:";
            // 
            // lb_Email
            // 
            this.lb_Email.AutoSize = true;
            this.lb_Email.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Email.Location = new System.Drawing.Point(38, 158);
            this.lb_Email.Name = "lb_Email";
            this.lb_Email.Size = new System.Drawing.Size(59, 21);
            this.lb_Email.TabIndex = 6;
            this.lb_Email.Text = "Email:";
            // 
            // lb_Address
            // 
            this.lb_Address.AutoSize = true;
            this.lb_Address.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Address.Location = new System.Drawing.Point(17, 287);
            this.lb_Address.Name = "lb_Address";
            this.lb_Address.Size = new System.Drawing.Size(80, 21);
            this.lb_Address.TabIndex = 7;
            this.lb_Address.Text = "Address:";
            // 
            // lb_PatientID
            // 
            this.lb_PatientID.AutoSize = true;
            this.lb_PatientID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PatientID.Location = new System.Drawing.Point(12, 64);
            this.lb_PatientID.Name = "lb_PatientID";
            this.lb_PatientID.Size = new System.Drawing.Size(104, 22);
            this.lb_PatientID.TabIndex = 5;
            this.lb_PatientID.Text = "Person ID:";
            // 
            // lb_AddEditPerson
            // 
            this.lb_AddEditPerson.AutoSize = true;
            this.lb_AddEditPerson.Font = new System.Drawing.Font("Arial Black", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AddEditPerson.ForeColor = System.Drawing.Color.Red;
            this.lb_AddEditPerson.Location = new System.Drawing.Point(258, -1);
            this.lb_AddEditPerson.Name = "lb_AddEditPerson";
            this.lb_AddEditPerson.Size = new System.Drawing.Size(269, 40);
            this.lb_AddEditPerson.TabIndex = 4;
            this.lb_AddEditPerson.Text = "Add New Person";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // AddEditPersonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 545);
            this.Controls.Add(this.lb_ND);
            this.Controls.Add(this.panel_PersonInfo);
            this.Controls.Add(this.lb_PatientID);
            this.Controls.Add(this.lb_AddEditPerson);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "AddEditPersonForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.AddEditPatientForm_Load);
            this.panel_PersonInfo.ResumeLayout(false);
            this.panel_PersonInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_ND;
        private System.Windows.Forms.Panel panel_PersonInfo;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Email;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.TextBox tb_Phone;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_Last;
        private System.Windows.Forms.Label lb_First;
        private System.Windows.Forms.TextBox tb_LastName;
        private System.Windows.Forms.TextBox tb_FirstName;
        private System.Windows.Forms.Label lb_Name;
        private System.Windows.Forms.Label lb_Gender;
        private System.Windows.Forms.Label lb_Email;
        private System.Windows.Forms.Label lb_Address;
        private System.Windows.Forms.Label lb_PatientID;
        private System.Windows.Forms.Label lb_AddEditPerson;
        private System.Windows.Forms.TextBox tb_Age;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}