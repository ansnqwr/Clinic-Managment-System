﻿using ClinicAppWindowsForms.Employees_Forms;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Patients_Forms.Controlls
{
    public partial class PersonInfoWithFilterCtrl : UserControl
    {
        public event Action<int> OnPatientSelected;
        protected virtual void PatientSelected(int PatientID)
        {
            Action<int> handler = OnPatientSelected;
            if (handler != null)
            {
                handler(PatientID); // Raise the event with the parameter
            }
        }

        public clsPatient SelectedPatient { get; set; } 
        public int PersonID { get { return _PersonID; } set { _PersonID = value; } }
        private int _PersonID = -1;
        public PersonInfoWithFilterCtrl()
        {
            InitializeComponent();
       
        }

        private bool _FilterEnabled = true;
        public bool FilterEnabled
        {
            get
            {
                return _FilterEnabled;
            }
            set
            {
                _FilterEnabled = value;
                gbFilters.Enabled = _FilterEnabled;
            }
        }
        public int FilterValue
        {
            get
            {
                return Convert.ToInt32( txtFilterValue.Text);
            }
            set
            {
                txtFilterValue.Text = value.ToString();
            }
        }
        public void LoadInfo(int PatientID)
        {
            cbFilterBy.SelectedIndex = 0;
            txtFilterValue.Text = PatientID.ToString();
            FindNow();

        }

        private void FindNow()
        {
            switch (cbFilterBy.Text)
            {
                case "Patient ID":

                    SelectedPatient = clsPatient.FindPatient(Convert.ToInt32( txtFilterValue.Text));
                    if(SelectedPatient == null)
                    {
                        MessageBox.Show($"This Patient ID is not Exist :{txtFilterValue.Text}","Not Exist",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        return;
                    }
                    PersonID = SelectedPatient.PersonID;
                    personInfoCtrl1._LoadPersonInfo(SelectedPatient);
                    break;

                case "Patient Name":
                    personInfoCtrl1._LoadPersonInfo(clsPerson.Find(txtFilterValue.Text.Trim()));
                    if (personInfoCtrl1.SelectedPerson == null)
                    {
                        MessageBox.Show($"This Patient Name is not Exist :{txtFilterValue.Text}", "Not Exist", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    PersonID = personInfoCtrl1.SelectedPerson.ID;
                    break;

            }

            if (OnPatientSelected != null && FilterEnabled)
                OnPatientSelected(SelectedPatient.PatientID);
        }

        private void txtFilterValue_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFilterValue.Text.Trim()))
            {
                errorProvider1.SetError(txtFilterValue, "This field is required!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(txtFilterValue, null);
            }
        }

        private void txtFilterValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cbFilterBy.Text == "Patient ID")
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren() || string.IsNullOrEmpty(txtFilterValue.Text))
            {
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }

            FindNow();
        }

        private void btnAddNewPerson_Click(object sender, EventArgs e)
        {
            AddEditPersonForm addEditPatientForm = new AddEditPersonForm();

            addEditPatientForm.DataBack += DataBackEvent;
            addEditPatientForm.Show();
        }

        private void DataBackEvent(clsPerson person, int PersonID)
        {

            personInfoCtrl1._LoadPersonInfo(person);

            if (OnPatientSelected != null && FilterEnabled)
                OnPatientSelected(SelectedPatient.PatientID);

        }
    }
}
