﻿namespace ClinicAppWindowsForms.Patients_Forms.Controlls
{
    partial class PersonInfoCtrl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lb_Phone2 = new System.Windows.Forms.Label();
            this.lb_DateOfBirth2 = new System.Windows.Forms.Label();
            this.lb_PersonID2 = new System.Windows.Forms.Label();
            this.lb_Name2 = new System.Windows.Forms.Label();
            this.lb_Gender2 = new System.Windows.Forms.Label();
            this.lb_Email2 = new System.Windows.Forms.Label();
            this.lb_Address2 = new System.Windows.Forms.Label();
            this.linkLabel_EditPerson = new System.Windows.Forms.LinkLabel();
            this.pb_ImagePerson = new System.Windows.Forms.PictureBox();
            this.lb_Phone = new System.Windows.Forms.Label();
            this.lb_DateOfBirth = new System.Windows.Forms.Label();
            this.lb_PersonID = new System.Windows.Forms.Label();
            this.lb_Name = new System.Windows.Forms.Label();
            this.lb_Gender = new System.Windows.Forms.Label();
            this.lb_Email = new System.Windows.Forms.Label();
            this.lb_Address = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ImagePerson)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lb_Phone2);
            this.groupBox1.Controls.Add(this.lb_DateOfBirth2);
            this.groupBox1.Controls.Add(this.lb_PersonID2);
            this.groupBox1.Controls.Add(this.lb_Name2);
            this.groupBox1.Controls.Add(this.lb_Gender2);
            this.groupBox1.Controls.Add(this.lb_Email2);
            this.groupBox1.Controls.Add(this.lb_Address2);
            this.groupBox1.Controls.Add(this.linkLabel_EditPerson);
            this.groupBox1.Controls.Add(this.pb_ImagePerson);
            this.groupBox1.Controls.Add(this.lb_Phone);
            this.groupBox1.Controls.Add(this.lb_DateOfBirth);
            this.groupBox1.Controls.Add(this.lb_PersonID);
            this.groupBox1.Controls.Add(this.lb_Name);
            this.groupBox1.Controls.Add(this.lb_Gender);
            this.groupBox1.Controls.Add(this.lb_Email);
            this.groupBox1.Controls.Add(this.lb_Address);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(847, 302);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Person Information";
            // 
            // lb_Phone2
            // 
            this.lb_Phone2.AutoSize = true;
            this.lb_Phone2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Phone2.ForeColor = System.Drawing.Color.Blue;
            this.lb_Phone2.Location = new System.Drawing.Point(457, 214);
            this.lb_Phone2.Name = "lb_Phone2";
            this.lb_Phone2.Size = new System.Drawing.Size(51, 20);
            this.lb_Phone2.TabIndex = 38;
            this.lb_Phone2.Text = "[???]";
            // 
            // lb_DateOfBirth2
            // 
            this.lb_DateOfBirth2.AutoSize = true;
            this.lb_DateOfBirth2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_DateOfBirth2.ForeColor = System.Drawing.Color.Blue;
            this.lb_DateOfBirth2.Location = new System.Drawing.Point(457, 264);
            this.lb_DateOfBirth2.Name = "lb_DateOfBirth2";
            this.lb_DateOfBirth2.Size = new System.Drawing.Size(51, 20);
            this.lb_DateOfBirth2.TabIndex = 37;
            this.lb_DateOfBirth2.Text = "[???]";
            // 
            // lb_PersonID2
            // 
            this.lb_PersonID2.AutoSize = true;
            this.lb_PersonID2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PersonID2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lb_PersonID2.Location = new System.Drawing.Point(137, 60);
            this.lb_PersonID2.Name = "lb_PersonID2";
            this.lb_PersonID2.Size = new System.Drawing.Size(51, 20);
            this.lb_PersonID2.TabIndex = 36;
            this.lb_PersonID2.Text = "[???]";
            // 
            // lb_Name2
            // 
            this.lb_Name2.AutoSize = true;
            this.lb_Name2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Name2.ForeColor = System.Drawing.Color.Red;
            this.lb_Name2.Location = new System.Drawing.Point(137, 110);
            this.lb_Name2.Name = "lb_Name2";
            this.lb_Name2.Size = new System.Drawing.Size(51, 20);
            this.lb_Name2.TabIndex = 31;
            this.lb_Name2.Text = "[???]";
            // 
            // lb_Gender2
            // 
            this.lb_Gender2.AutoSize = true;
            this.lb_Gender2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Gender2.ForeColor = System.Drawing.Color.Blue;
            this.lb_Gender2.Location = new System.Drawing.Point(137, 164);
            this.lb_Gender2.Name = "lb_Gender2";
            this.lb_Gender2.Size = new System.Drawing.Size(51, 20);
            this.lb_Gender2.TabIndex = 33;
            this.lb_Gender2.Text = "[???]";
            // 
            // lb_Email2
            // 
            this.lb_Email2.AutoSize = true;
            this.lb_Email2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Email2.ForeColor = System.Drawing.Color.Blue;
            this.lb_Email2.Location = new System.Drawing.Point(137, 214);
            this.lb_Email2.Name = "lb_Email2";
            this.lb_Email2.Size = new System.Drawing.Size(51, 20);
            this.lb_Email2.TabIndex = 34;
            this.lb_Email2.Text = "[???]";
            // 
            // lb_Address2
            // 
            this.lb_Address2.AutoSize = true;
            this.lb_Address2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Address2.ForeColor = System.Drawing.Color.Blue;
            this.lb_Address2.Location = new System.Drawing.Point(137, 264);
            this.lb_Address2.Name = "lb_Address2";
            this.lb_Address2.Size = new System.Drawing.Size(51, 20);
            this.lb_Address2.TabIndex = 35;
            this.lb_Address2.Text = "[???]";
            // 
            // linkLabel_EditPerson
            // 
            this.linkLabel_EditPerson.AutoSize = true;
            this.linkLabel_EditPerson.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel_EditPerson.Location = new System.Drawing.Point(672, 64);
            this.linkLabel_EditPerson.Name = "linkLabel_EditPerson";
            this.linkLabel_EditPerson.Size = new System.Drawing.Size(137, 22);
            this.linkLabel_EditPerson.TabIndex = 30;
            this.linkLabel_EditPerson.TabStop = true;
            this.linkLabel_EditPerson.Text = "Edit Person Info";
            this.linkLabel_EditPerson.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel_EditPerson_LinkClicked);
            // 
            // pb_ImagePerson
            // 
            this.pb_ImagePerson.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pb_ImagePerson.Image = global::ClinicAppWindowsForms.Properties.Resources.Male_512;
            this.pb_ImagePerson.Location = new System.Drawing.Point(644, 117);
            this.pb_ImagePerson.Name = "pb_ImagePerson";
            this.pb_ImagePerson.Size = new System.Drawing.Size(196, 167);
            this.pb_ImagePerson.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_ImagePerson.TabIndex = 29;
            this.pb_ImagePerson.TabStop = false;
            // 
            // lb_Phone
            // 
            this.lb_Phone.AutoSize = true;
            this.lb_Phone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Phone.Location = new System.Drawing.Point(377, 213);
            this.lb_Phone.Name = "lb_Phone";
            this.lb_Phone.Size = new System.Drawing.Size(67, 20);
            this.lb_Phone.TabIndex = 26;
            this.lb_Phone.Text = "Phone:";
            // 
            // lb_DateOfBirth
            // 
            this.lb_DateOfBirth.AutoSize = true;
            this.lb_DateOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_DateOfBirth.Location = new System.Drawing.Point(397, 264);
            this.lb_DateOfBirth.Name = "lb_DateOfBirth";
            this.lb_DateOfBirth.Size = new System.Drawing.Size(47, 20);
            this.lb_DateOfBirth.TabIndex = 25;
            this.lb_DateOfBirth.Text = "Age:";
            // 
            // lb_PersonID
            // 
            this.lb_PersonID.AutoSize = true;
            this.lb_PersonID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PersonID.Location = new System.Drawing.Point(21, 62);
            this.lb_PersonID.Name = "lb_PersonID";
            this.lb_PersonID.Size = new System.Drawing.Size(99, 20);
            this.lb_PersonID.TabIndex = 13;
            this.lb_PersonID.Text = "Person ID:";
            // 
            // lb_Name
            // 
            this.lb_Name.AutoSize = true;
            this.lb_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Name.Location = new System.Drawing.Point(21, 112);
            this.lb_Name.Name = "lb_Name";
            this.lb_Name.Size = new System.Drawing.Size(63, 20);
            this.lb_Name.TabIndex = 8;
            this.lb_Name.Text = "Name:";
            // 
            // lb_Gender
            // 
            this.lb_Gender.AutoSize = true;
            this.lb_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Gender.Location = new System.Drawing.Point(21, 164);
            this.lb_Gender.Name = "lb_Gender";
            this.lb_Gender.Size = new System.Drawing.Size(76, 20);
            this.lb_Gender.TabIndex = 10;
            this.lb_Gender.Text = "Gender:";
            // 
            // lb_Email
            // 
            this.lb_Email.AutoSize = true;
            this.lb_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Email.Location = new System.Drawing.Point(23, 214);
            this.lb_Email.Name = "lb_Email";
            this.lb_Email.Size = new System.Drawing.Size(62, 20);
            this.lb_Email.TabIndex = 11;
            this.lb_Email.Text = "Email:";
            // 
            // lb_Address
            // 
            this.lb_Address.AutoSize = true;
            this.lb_Address.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Address.Location = new System.Drawing.Point(23, 264);
            this.lb_Address.Name = "lb_Address";
            this.lb_Address.Size = new System.Drawing.Size(84, 20);
            this.lb_Address.TabIndex = 12;
            this.lb_Address.Text = "Address:";
            // 
            // PersonInfoCtrl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Name = "PersonInfoCtrl";
            this.Size = new System.Drawing.Size(856, 309);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_ImagePerson)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lb_Phone2;
        private System.Windows.Forms.Label lb_DateOfBirth2;
        private System.Windows.Forms.Label lb_PersonID2;
        private System.Windows.Forms.Label lb_Name2;
        private System.Windows.Forms.Label lb_Gender2;
        private System.Windows.Forms.Label lb_Email2;
        private System.Windows.Forms.Label lb_Address2;
        private System.Windows.Forms.LinkLabel linkLabel_EditPerson;
        private System.Windows.Forms.PictureBox pb_ImagePerson;
        private System.Windows.Forms.Label lb_Phone;
        private System.Windows.Forms.Label lb_DateOfBirth;
        private System.Windows.Forms.Label lb_PersonID;
        private System.Windows.Forms.Label lb_Name;
        private System.Windows.Forms.Label lb_Gender;
        private System.Windows.Forms.Label lb_Email;
        private System.Windows.Forms.Label lb_Address;
    }
}
