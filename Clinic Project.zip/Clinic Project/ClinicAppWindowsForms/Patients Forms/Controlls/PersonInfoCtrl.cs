﻿using ClinicAppWindowsForms.Properties;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Patients_Forms.Controlls
{
    public partial class PersonInfoCtrl : UserControl
    {
        public PersonInfoCtrl()
        {
            InitializeComponent();
        }
        clsPatient patient=new clsPatient();
        public clsPerson SelectedPerson { get; set; }   
        public void _LoadPersonInfo(clsPatient Patient)
        {
            SelectedPerson=Patient;
            patient = Patient;
            _FillPersonInfo();
        }
        public void _LoadPersonInfo(clsPerson Person)
        {
            SelectedPerson = Person;
            _FillPersonInfo();
        }
        public void _LoadPersonInfo(clsEmployee employee)
        {
            SelectedPerson = employee;
            // int PersonID = clsPatient.Find(PatientID).ID;
            // SelectedPerson=clsPerson.Find(PersonID);
            _FillPersonInfo();
        }
        private void _FillPersonInfo()
        {
            if (SelectedPerson == null) 
                return; 

            lb_PersonID2.Text=  SelectedPerson.ID.ToString();
            lb_Phone2.Text=SelectedPerson.PhoneNumber ;
               lb_Name2.Text= SelectedPerson.Name;
             lb_Email2.Text=SelectedPerson.Email ;
                  lb_Address2.Text=SelectedPerson.Address;
                      lb_DateOfBirth2.Text=SelectedPerson.Age;
           lb_Gender2.Text = (SelectedPerson.Gender == 0) ? "Male" : "Female";
            _LoadPersonImage();
        }

        private void _LoadPersonImage()
        {
            if (SelectedPerson.Gender == 0)
                pb_ImagePerson.Image = Resources.Male_512;
            else
                pb_ImagePerson.Image = Resources.Female_512;

        }

        private void linkLabel_EditPerson_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (this.patient.ID == -1) return;
                AddEditPersonForm addEditPatientForm = new AddEditPersonForm(this.patient.ID);
                addEditPatientForm.ShowDialog();
            _FillPersonInfo();
            
        }



            public void ResetPersonInfo()
            {
                lb_PersonID2.Text = "[????]";
           
                lb_Name2.Text = "[????]";
                pb_ImagePerson.Image = Resources.Male_512;
                lb_Gender2.Text = "[????]";
                lb_Email2.Text = "[????]";
                lb_Phone2.Text = "[????]";
                lb_DateOfBirth2.Text = "[????]";
                lb_Address2.Text = "[????]";

            }
        
    }
}
