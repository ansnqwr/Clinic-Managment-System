﻿using ClinicLogicLayer;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Patients_Forms
{
    public partial class AddEditPersonForm : Form
    {
        public delegate void DataBackEventHandler( clsPerson sender,int PersonID);

        public event DataBackEventHandler DataBack;
        enum enMode { AddNew, Update }
        enMode mode = enMode.AddNew;

        clsPerson person=new clsPerson();

        public int PersonID = 0;
        public AddEditPersonForm()
        {
            InitializeComponent();
            mode = enMode.AddNew;
        }
        public AddEditPersonForm(int PersonID)
        {
            InitializeComponent();
            mode = enMode.Update;
            person = clsPerson.Find(PersonID);
         
        }
   
        private void _LoadData()
        {
            if (mode == enMode.AddNew)
            {
               
                    person = new clsPerson();
                    lb_AddEditPerson.Text = "Add New Person";
       
                return;
            }

            lb_AddEditPerson.Text = "Update Person Info";

     

                string[] result = person.Name.Split(new string[] { " " }, StringSplitOptions.None);

              
                tb_FirstName.Text = result[0];
                try {
                    tb_LastName.Text = result[1];
                }
                catch { }
                tb_Email.Text = person.Email;
                tb_Address.Text = person.Address;
                tb_Phone.Text = person.PhoneNumber;
                tb_Age.Text = person.Age;
                lb_ND.Text = person.ID.ToString();
            if(person.Gender==0)rb_Male.Checked = true;
            else rb_Female.Checked = false;
            
        }

        private void AddEditPatientForm_Load(object sender, EventArgs e)
        {
            _LoadData();
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
              
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
       
            if (mode == enMode.AddNew)
            {
             
                person = new clsPerson();
            }
    
           person.Name = tb_FirstName.Text.Trim() + " " + tb_LastName.Text.Trim();
           person.Email = tb_Email.Text.Trim();
           person.PhoneNumber = tb_Phone.Text.Trim();
           person.Address = tb_Address.Text.Trim();
           person.Age = tb_Age.Text;

            if (rb_Male.Checked) person.Gender = 'M'; else person.Gender = 'F';

            if (person.Save())
            {
                lb_ND.Text = person.ID.ToString();
                mode = enMode.Update;
                lb_AddEditPerson.Text = "Update Person";

                MessageBox.Show("Data Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

                btn_Save.Enabled = false;   
                  DataBack?.Invoke(person,person.ID);
            }
            else
            {
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void ValidateEmptyTextBox(object sender, CancelEventArgs e)
        {

            TextBox Temp = ((TextBox)sender);
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                errorProvider1.SetError(Temp, "This field is required!");
            }
            else
            {
                errorProvider1.SetError(Temp, null);
            }

        }
    }

}
