﻿using ClinicAppWindowsForms.Patients_Forms;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Employees_Forms
{
    public partial class ListEmployeeForm : Form
    {
        DataTable dt = new DataTable();
        int PersonID = -1;
        clsEmployee employee = null;    
        public ListEmployeeForm()
        {
            InitializeComponent();
            _InitializeData();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

   private  void _InitializeData()
        {
            cbFilterBy.SelectedIndex = 0;
            dt = clsEmployee.GetAllEmployees();

            EmployeesGrid.DataSource = dt;
            if (EmployeesGrid.Rows.Count > 0)
            {
                EmployeesGrid.Columns[0].HeaderText = "Employee ID";

                EmployeesGrid.Columns[1].HeaderText = "Name";

                EmployeesGrid.Columns[2].HeaderText = "Age";

                EmployeesGrid.Columns[3].HeaderText = "Gender";

                EmployeesGrid.Columns[4].HeaderText = "Phone";

                EmployeesGrid.Columns[5].HeaderText = "Salary";

                EmployeesGrid.Columns[6].HeaderText = "Position";

                EmployeesGrid.Columns[7].HeaderText = "Hire Date";
           

            }



            lb_RecordsNumber.Text = "# Records:  " + EmployeesGrid.Rows.Count.ToString();



        }

        private void txtFilterValue_TextChanged(object sender, EventArgs e)
        {
            string FilterColumn = "";
            switch (cbFilterBy.Text)
            {
                case "Employee ID":
                    FilterColumn = "EmployeeID";
                    break;
                case "Name":
                    FilterColumn = "Name";
                    break;

                case "Age":
                    FilterColumn = "Age";
                    break;

                case "Gender":
                    FilterColumn = "Gender";
                    break;

                case "Phone":
                    FilterColumn = "Phone";
                    break;

                case "Position":
                    FilterColumn = "Position";
                    break;
                case "UserName":
                    FilterColumn = "UserName";
                    break;
                default:
                    FilterColumn = "None";
                    break;

            }

            if (txtFilterValue.Text.Trim() == "" || FilterColumn == "None")
            {
                dt.DefaultView.RowFilter = "";
                lb_RecordsNumber.Text = EmployeesGrid.Rows.Count.ToString();
                return;
            }

            if (FilterColumn == "EmployeeID" || FilterColumn == "Age")
                dt.DefaultView.RowFilter = string.Format("[{0}] = {1}", FilterColumn, txtFilterValue.Text.Trim());
            else
                dt.DefaultView.RowFilter = string.Format("[{0}] LIKE '{1}%'", FilterColumn, txtFilterValue.Text.Trim());



            lb_RecordsNumber.Text = EmployeesGrid.Rows.Count.ToString();
        }

        private void personDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int EmployeeID = (int)EmployeesGrid.SelectedRows[0].Cells[0].Value;

            EmployeeDetailsForm employeeDetails =new EmployeeDetailsForm(clsEmployee.FindEmployee(EmployeeID));
            employeeDetails.ShowDialog();
        }

        private void btn_AddNewEmployee_Click(object sender, EventArgs e)
        {
            AddEditEmployeeForm addEditPatientForm = new AddEditEmployeeForm();
            addEditPatientForm.ShowDialog();
            _InitializeData();
        }

        private void btn_Edit_Click(object sender, EventArgs e)
        {
            int EmployeeID = (int)EmployeesGrid.SelectedRows[0].Cells[0].Value;
            AddEditEmployeeForm addEditPatientForm = new AddEditEmployeeForm(EmployeeID);
            addEditPatientForm.ShowDialog();
            _InitializeData();
        }

        private void ListEmployeeForm_Load(object sender, EventArgs e)
        {

        }
    }
}
