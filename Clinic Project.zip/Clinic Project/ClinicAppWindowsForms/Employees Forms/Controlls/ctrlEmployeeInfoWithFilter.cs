﻿using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Employees_Forms.Controlls
{
    public partial class ctrlEmployeeInfoWithFilter : UserControl
    {
        public event Action<int> OnEmployeeSelected;
        protected virtual void EmployeeSelected(int EmployeeID)
        {
            Action<int> handler = OnEmployeeSelected;
            if (handler != null)
            {
                handler(EmployeeID); // Raise the event with the parameter
            }
        }
        public ctrlEmployeeInfoWithFilter()
        {
            InitializeComponent();
        }

        private bool _FilterEnabled = true;
        public bool FilterEnabled
        {
            get
            {
                return _FilterEnabled;
            }
            set
            {
                _FilterEnabled = value;
                gbFilters.Enabled = _FilterEnabled;
            }
        }

        public int EmployeeID
        {
            get { return ctrlEmployeeInfo1.SelectedEmployee.EmployeeID; }
        }

        public clsEmployee SelectedEmployeeInfo
        {
            get { return ctrlEmployeeInfo1.SelectedEmployee; }
        }

        public void LoadInfo(int EmployeeID)
        {

            cbFilterBy.SelectedIndex = 0;
            txtFilterValue.Text = EmployeeID.ToString();
            FindNow();

        }

        private void FindNow()
        {
            switch (cbFilterBy.Text)
            {
                case "Employee ID":
                    ctrlEmployeeInfo1.LoadInfo(Convert.ToInt32( txtFilterValue.Text));
                    break;


            }

            if (OnEmployeeSelected != null && FilterEnabled)
                OnEmployeeSelected(ctrlEmployeeInfo1.SelectedEmployee.EmployeeID);
        }

        private void btnFind_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }

            FindNow();
        }

        private void ctrlEmployeeInfoWithFilter_Load(object sender, EventArgs e)
        {
            cbFilterBy.SelectedIndex = 0;
            txtFilterValue.Focus();
        }

        private void txtFilterValue_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtFilterValue.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtFilterValue, "This field is required!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(txtFilterValue, null);
            }
        }

        private void txtFilterValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {

                btnFind.PerformClick();
            }

            if (cbFilterBy.Text == "Employee ID")
                e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);


        }

        private void DataBackEvent(clsEmployee Employee, int EmployeeID)
        {

            ctrlEmployeeInfo1.LoadInfo(Employee);

            if (OnEmployeeSelected != null && FilterEnabled)
                // Raise the event with a parameter
                OnEmployeeSelected(ctrlEmployeeInfo1.SelectedEmployee.EmployeeID);

        }

        private void btnAddNewPerson_Click(object sender, EventArgs e)
        {
            AddEditEmployeeForm addEditEmployeeForm = new AddEditEmployeeForm();

            addEditEmployeeForm.DataBack += DataBackEvent;
            addEditEmployeeForm.Show();
        }

        public void ResetData()
        {
            ctrlEmployeeInfo1.ResetEmployeeInfo();
        }
    }
}
