﻿using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Employees_Forms
{
    public partial class ctrlEmployeeInfo : UserControl
    {
       public ctrlEmployeeInfo()
        {
            InitializeComponent();
          
        }
     public clsEmployee SelectedEmployee { get; set; }  
        public void LoadInfo(clsEmployee employee)
        {
            personInfoCtrl1._LoadPersonInfo(employee);  
            SelectedEmployee = employee;
           
            _FillPersonInfo();
        }
        public void LoadInfo(int employeeId)
        {
            clsEmployee employee=clsEmployee.FindEmployee(employeeId);
            personInfoCtrl1._LoadPersonInfo(employee);
            SelectedEmployee = employee;

            _FillPersonInfo();
        }
        private void _FillPersonInfo()
        {
            lb_Salary.Text = SelectedEmployee.Salary.ToString();
            lb_Position.Text = SelectedEmployee.Position;
            lb_HireDate.Text = SelectedEmployee.Hire_Date.ToString();

        }

        public void ResetEmployeeInfo()
        {
            personInfoCtrl1.ResetPersonInfo();
            lb_Salary.Text = "[????]";
            lb_Position.Text = "[????]";
            lb_HireDate.Text = "[????]";

        }


    }
}
