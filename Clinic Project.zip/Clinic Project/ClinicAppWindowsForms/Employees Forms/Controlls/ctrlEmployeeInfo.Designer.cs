﻿namespace ClinicAppWindowsForms.Employees_Forms
{
   public partial class ctrlEmployeeInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Salary = new System.Windows.Forms.Label();
            this.lb_Position = new System.Windows.Forms.Label();
            this.lb_HireDate = new System.Windows.Forms.Label();
            this.lb = new System.Windows.Forms.Label();
            this.lb_P = new System.Windows.Forms.Label();
            this.lb_Add = new System.Windows.Forms.Label();
            this.personInfoCtrl1 = new ClinicAppWindowsForms.Patients_Forms.Controlls.PersonInfoCtrl();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_Salary
            // 
            this.lb_Salary.AutoSize = true;
            this.lb_Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Salary.ForeColor = System.Drawing.Color.Blue;
            this.lb_Salary.Location = new System.Drawing.Point(99, 30);
            this.lb_Salary.Name = "lb_Salary";
            this.lb_Salary.Size = new System.Drawing.Size(51, 20);
            this.lb_Salary.TabIndex = 39;
            this.lb_Salary.Text = "[???]";
            // 
            // lb_Position
            // 
            this.lb_Position.AutoSize = true;
            this.lb_Position.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Position.ForeColor = System.Drawing.Color.Blue;
            this.lb_Position.Location = new System.Drawing.Point(377, 30);
            this.lb_Position.Name = "lb_Position";
            this.lb_Position.Size = new System.Drawing.Size(51, 20);
            this.lb_Position.TabIndex = 40;
            this.lb_Position.Text = "[???]";
            // 
            // lb_HireDate
            // 
            this.lb_HireDate.AutoSize = true;
            this.lb_HireDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_HireDate.ForeColor = System.Drawing.Color.Blue;
            this.lb_HireDate.Location = new System.Drawing.Point(645, 30);
            this.lb_HireDate.Name = "lb_HireDate";
            this.lb_HireDate.Size = new System.Drawing.Size(51, 20);
            this.lb_HireDate.TabIndex = 41;
            this.lb_HireDate.Text = "[???]";
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb.Location = new System.Drawing.Point(25, 30);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(68, 20);
            this.lb.TabIndex = 36;
            this.lb.Text = "Salary:";
            // 
            // lb_P
            // 
            this.lb_P.AutoSize = true;
            this.lb_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_P.Location = new System.Drawing.Point(288, 30);
            this.lb_P.Name = "lb_P";
            this.lb_P.Size = new System.Drawing.Size(83, 20);
            this.lb_P.TabIndex = 37;
            this.lb_P.Text = "Position:";
            // 
            // lb_Add
            // 
            this.lb_Add.AutoSize = true;
            this.lb_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Add.Location = new System.Drawing.Point(542, 30);
            this.lb_Add.Name = "lb_Add";
            this.lb_Add.Size = new System.Drawing.Size(97, 20);
            this.lb_Add.TabIndex = 38;
            this.lb_Add.Text = "Hire Date:";
            // 
            // personInfoCtrl1
            // 
            this.personInfoCtrl1.Location = new System.Drawing.Point(3, 3);
            this.personInfoCtrl1.Name = "personInfoCtrl1";
            this.personInfoCtrl1.SelectedPerson = null;
            this.personInfoCtrl1.Size = new System.Drawing.Size(860, 309);
            this.personInfoCtrl1.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lb);
            this.groupBox1.Controls.Add(this.lb_Salary);
            this.groupBox1.Controls.Add(this.lb_HireDate);
            this.groupBox1.Controls.Add(this.lb_Position);
            this.groupBox1.Controls.Add(this.lb_Add);
            this.groupBox1.Controls.Add(this.lb_P);
            this.groupBox1.Location = new System.Drawing.Point(3, 318);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(848, 62);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            // 
            // ctrlEmployeeInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.personInfoCtrl1);
            this.Controls.Add(this.groupBox1);
            this.Name = "ctrlEmployeeInfo";
            this.Size = new System.Drawing.Size(947, 388);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Patients_Forms.Controlls.PersonInfoCtrl personInfoCtrl1;
        private System.Windows.Forms.Label lb_Salary;
        private System.Windows.Forms.Label lb_Position;
        private System.Windows.Forms.Label lb_HireDate;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.Label lb_P;
        private System.Windows.Forms.Label lb_Add;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}
