﻿using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Employees_Forms
{
    public partial class EmployeeDetailsForm : Form
    {
        public EmployeeDetailsForm(clsEmployee employee)
        {
            InitializeComponent();
            ctrlEmployeeInfo1.LoadInfo(employee); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
