﻿using ClinicAppWindowsForms.Patients_Forms;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

using System.Windows.Forms;

namespace ClinicAppWindowsForms.Employees_Forms
{
    public partial class AddEditEmployeeForm : Form
    {
        public delegate void DataBackEventHandler(clsEmployee sender, int EmployeeID);

        public event DataBackEventHandler DataBack;
        enum enMode { AddNew, Update }

        enMode mode = enMode.AddNew;
        clsEmployee employee;
        clsPerson Person;
        int PersonID = -1;
        clsDoctor doctor;
        public AddEditEmployeeForm()
        {
            InitializeComponent();
            mode = enMode.AddNew;
        }

        public AddEditEmployeeForm(int EmployeeID)
        {
            InitializeComponent();
            mode = enMode.Update;
            employee = clsEmployee.FindEmployee(EmployeeID);
            Person = employee;
            PersonID = Person.ID;
        }

        private void _LoadData()
        {
            if (mode == enMode.AddNew)
            {

                Person = new clsPerson();
                lb_AddEditPerson.Text = "Add New Employee";
                btn_AddNewEmployee.Text = "➕ Add Person Information";
                dtpHireDate.Value = DateTime.Now;
                return;
            }

            btn_AddNewEmployee.Text = "➕ Edit Person Information";
            lb_AddEditPerson.Text = "Update Employee Info";
            tb_Salary.Text = employee.Salary.ToString();
            cb_Position.SelectedIndex = _GetIndexPositionfromComboBox(employee.Position);
            cb_Position.Enabled = false;
            dtpHireDate.Value = employee.Hire_Date;
            //case was a Doctor..
            if (cb_Position.SelectedIndex == 1)
            {
                 doctor = clsDoctor.FindDoctorByEmployeeID(employee.EmployeeID);
                lb_Specialization.Enabled = true;
                tb_Specialization.Enabled = true;
                tb_Specialization.Text = doctor.Specialization;
            }



        }

        private byte _GetIndexPositionfromComboBox(string Position)
        {
            switch (Position)
            {
                case "Manager": return 0;
                case "Doctor": return 1;
                case "Secretary": return 2;
            }
            return 3;
        }
        private void btn_AddNewEmployee_Click(object sender, EventArgs e)
        {
            if (mode == enMode.AddNew)
            {
                AddEditPersonForm addEditPersonForm = new AddEditPersonForm();
                addEditPersonForm.DataBack += DataBackEvent;
                addEditPersonForm.ShowDialog();
            }
            else
            {
                AddEditPersonForm addEditPersonForm = new AddEditPersonForm(employee.ID);
                addEditPersonForm.DataBack += DataBackEvent;
                addEditPersonForm.ShowDialog();

            }

        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DataBackEvent(clsPerson Person, int personID)
        {

            this.Person = Person;
            PersonID = personID;

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (!this.ValidateChildren())
            {
                //Here we dont continue becuase the form is not valid
                MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;

            }
            if (PersonID == -1)
            {
                MessageBox.Show("Please Add New Person Information.", "Erorr", MessageBoxButtons.OK);
                return;
            }
            else if (mode == enMode.AddNew)
            {
                employee = new clsEmployee();
            }

            employee.ID = Person.ID;
            employee.Name = Person.Name;
            employee.Age = Person.Age;
            employee.Email = Person.Email;
            employee.Address = Person.Address;
            employee.PhoneNumber = Person.PhoneNumber;
            if (Person.Gender == 0) employee.Gender = 'M'; else employee.Gender = 'F';
            employee.Salary = Convert.ToInt32(tb_Salary.Text);
            employee.Position = cb_Position.Text;
            employee.Hire_Date = dtpHireDate.Value;

            if (employee.SaveEmployee())
            {
                _AddEditDoctorInfo((byte)cb_Position.SelectedIndex);

                MessageBox.Show($"{mode} Employee Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                btn_Save.Enabled = false;
                DataBack?.Invoke(employee, employee.EmployeeID);
            }
            else
            {
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ValidateEmptyTextBox(object sender, CancelEventArgs e)
        {

            TextBox Temp = ((TextBox)sender);
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                errorProvider1.SetError(Temp, "This field is required!");
            }
            else
            {
                errorProvider1.SetError(Temp, null);
            }

        }

        private void AddEditEmployeeForm_Load(object sender, EventArgs e)
        {
            lb_Specialization.Enabled = false;
            tb_Specialization.Enabled = false;
            cb_Position.SelectedIndex = 0;
            _LoadData();
        }

        private void tb_Specialization_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tb_Specialization.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tb_Specialization, "Specialization cannot be blank");
                return;
            }
            else
            {
                errorProvider1.SetError(tb_Specialization, null);
            };
        }

        private void cb_Position_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_Position.SelectedIndex == 1)
            {
                lb_Specialization.Enabled = true;
                tb_Specialization.Enabled = true;
            }
            else
            {
                lb_Specialization.Enabled = false;
                tb_Specialization.Enabled = false;
            }
        }

        private void _AddEditDoctorInfo(byte SelectedIndex)
        {
            if (SelectedIndex!=1)
            {
                return ;   
            }

            if (mode==enMode.AddNew)
            {
                doctor=new clsDoctor();
                doctor.Specialization = tb_Specialization.Text;
                doctor.employee = employee;
            }
            else
            {
                doctor.Specialization = tb_Specialization.Text;
            }
           
            if (doctor.SaveDoctor())
            {
                MessageBox.Show($"{mode} Doctor Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
              
            }
           
        }


            }
}
