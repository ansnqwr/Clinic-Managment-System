﻿namespace ClinicAppWindowsForms.Employees_Forms
{
    partial class EmployeeDetailsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlEmployeeInfo1 = new ClinicAppWindowsForms.Employees_Forms.ctrlEmployeeInfo();
            this.button1 = new System.Windows.Forms.Button();
            this.lb_PersonDetails = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ctrlEmployeeInfo1
            // 
            this.ctrlEmployeeInfo1.Location = new System.Drawing.Point(-6, 55);
            this.ctrlEmployeeInfo1.Name = "ctrlEmployeeInfo1";
            this.ctrlEmployeeInfo1.Size = new System.Drawing.Size(947, 389);
            this.ctrlEmployeeInfo1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::ClinicAppWindowsForms.Properties.Resources.Close_32;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.button1.Location = new System.Drawing.Point(405, 450);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 42);
            this.button1.TabIndex = 2;
            this.button1.Text = "Close";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lb_PersonDetails
            // 
            this.lb_PersonDetails.AutoSize = true;
            this.lb_PersonDetails.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_PersonDetails.ForeColor = System.Drawing.Color.Red;
            this.lb_PersonDetails.Location = new System.Drawing.Point(341, 9);
            this.lb_PersonDetails.Name = "lb_PersonDetails";
            this.lb_PersonDetails.Size = new System.Drawing.Size(257, 34);
            this.lb_PersonDetails.TabIndex = 3;
            this.lb_PersonDetails.Text = "Employee Details";
            // 
            // EmployeeDetailsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(953, 500);
            this.Controls.Add(this.lb_PersonDetails);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ctrlEmployeeInfo1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EmployeeDetailsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Details";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ctrlEmployeeInfo ctrlEmployeeInfo1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lb_PersonDetails;
    }
}