﻿namespace ClinicAppWindowsForms.Employees_Forms
{
    partial class AddEditEmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dtpHireDate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_Salary = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Email = new System.Windows.Forms.Label();
            this.btn_AddNewEmployee = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.lb_AddEditPerson = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tb_Specialization = new System.Windows.Forms.TextBox();
            this.lb_Specialization = new System.Windows.Forms.Label();
            this.cb_Position = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpHireDate
            // 
            this.dtpHireDate.CustomFormat = "dd/M/yyyy";
            this.dtpHireDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpHireDate.Location = new System.Drawing.Point(573, 111);
            this.dtpHireDate.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dtpHireDate.Name = "dtpHireDate";
            this.dtpHireDate.Size = new System.Drawing.Size(226, 22);
            this.dtpHireDate.TabIndex = 98;
            this.dtpHireDate.Value = new System.DateTime(2000, 12, 31, 0, 0, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(455, 114);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 19);
            this.label3.TabIndex = 101;
            this.label3.Text = "Hire Date :";
            // 
            // tb_Salary
            // 
            this.tb_Salary.BackColor = System.Drawing.Color.White;
            this.tb_Salary.Location = new System.Drawing.Point(137, 105);
            this.tb_Salary.Multiline = true;
            this.tb_Salary.Name = "tb_Salary";
            this.tb_Salary.Size = new System.Drawing.Size(208, 28);
            this.tb_Salary.TabIndex = 1;
            this.tb_Salary.Validating += new System.ComponentModel.CancelEventHandler(this.ValidateEmptyTextBox);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 21);
            this.label1.TabIndex = 108;
            this.label1.Text = "Salary:";
            // 
            // lb_Email
            // 
            this.lb_Email.AutoSize = true;
            this.lb_Email.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Email.Location = new System.Drawing.Point(469, 168);
            this.lb_Email.Name = "lb_Email";
            this.lb_Email.Size = new System.Drawing.Size(79, 21);
            this.lb_Email.TabIndex = 107;
            this.lb_Email.Text = "Position:";
            // 
            // btn_AddNewEmployee
            // 
            this.btn_AddNewEmployee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btn_AddNewEmployee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_AddNewEmployee.Location = new System.Drawing.Point(137, 290);
            this.btn_AddNewEmployee.Name = "btn_AddNewEmployee";
            this.btn_AddNewEmployee.Size = new System.Drawing.Size(231, 41);
            this.btn_AddNewEmployee.TabIndex = 4;
            this.btn_AddNewEmployee.Text = "➕ Add Person Information";
            this.btn_AddNewEmployee.UseVisualStyleBackColor = false;
            this.btn_AddNewEmployee.Click += new System.EventHandler(this.btn_AddNewEmployee_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.btn_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Save.Image = global::ClinicAppWindowsForms.Properties.Resources.Save_32;
            this.btn_Save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Save.Location = new System.Drawing.Point(654, 481);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(137, 42);
            this.btn_Save.TabIndex = 5;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.Red;
            this.btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_Close.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Close.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Close.Image = global::ClinicAppWindowsForms.Properties.Resources.Close_32;
            this.btn_Close.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_Close.Location = new System.Drawing.Point(491, 481);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(137, 42);
            this.btn_Close.TabIndex = 111;
            this.btn_Close.Text = "Close";
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // lb_AddEditPerson
            // 
            this.lb_AddEditPerson.AutoSize = true;
            this.lb_AddEditPerson.Font = new System.Drawing.Font("Arial Black", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_AddEditPerson.ForeColor = System.Drawing.Color.Red;
            this.lb_AddEditPerson.Location = new System.Drawing.Point(275, 9);
            this.lb_AddEditPerson.Name = "lb_AddEditPerson";
            this.lb_AddEditPerson.Size = new System.Drawing.Size(313, 40);
            this.lb_AddEditPerson.TabIndex = 112;
            this.lb_AddEditPerson.Text = "Add New Employee";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // tb_Specialization
            // 
            this.tb_Specialization.Location = new System.Drawing.Point(137, 162);
            this.tb_Specialization.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tb_Specialization.MaxLength = 50;
            this.tb_Specialization.Multiline = true;
            this.tb_Specialization.Name = "tb_Specialization";
            this.tb_Specialization.Size = new System.Drawing.Size(208, 27);
            this.tb_Specialization.TabIndex = 3;
            this.tb_Specialization.Validating += new System.ComponentModel.CancelEventHandler(this.tb_Specialization_Validating);
            // 
            // lb_Specialization
            // 
            this.lb_Specialization.AutoSize = true;
            this.lb_Specialization.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Specialization.Location = new System.Drawing.Point(4, 161);
            this.lb_Specialization.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_Specialization.Name = "lb_Specialization";
            this.lb_Specialization.Size = new System.Drawing.Size(125, 21);
            this.lb_Specialization.TabIndex = 139;
            this.lb_Specialization.Text = "Specialization:";
            // 
            // cb_Position
            // 
            this.cb_Position.FormattingEnabled = true;
            this.cb_Position.Items.AddRange(new object[] {
            "Manager",
            "Doctor",
            "Secretary",
            "Garbage Man"});
            this.cb_Position.Location = new System.Drawing.Point(573, 165);
            this.cb_Position.Name = "cb_Position";
            this.cb_Position.Size = new System.Drawing.Size(226, 24);
            this.cb_Position.TabIndex = 2;
            this.cb_Position.SelectedIndexChanged += new System.EventHandler(this.cb_Position_SelectedIndexChanged);
            // 
            // AddEditEmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 539);
            this.Controls.Add(this.cb_Position);
            this.Controls.Add(this.tb_Specialization);
            this.Controls.Add(this.lb_Specialization);
            this.Controls.Add(this.lb_AddEditPerson);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_AddNewEmployee);
            this.Controls.Add(this.tb_Salary);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_Email);
            this.Controls.Add(this.dtpHireDate);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AddEditEmployeeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.AddEditEmployeeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker dtpHireDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_Salary;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_Email;
        private System.Windows.Forms.Button btn_AddNewEmployee;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Label lb_AddEditPerson;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox tb_Specialization;
        private System.Windows.Forms.Label lb_Specialization;
        private System.Windows.Forms.ComboBox cb_Position;
    }
}