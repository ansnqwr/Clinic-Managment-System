﻿using ClinicAppWindowsForms.MedicalRecords_Forms;
using ClinicLogicLayer;
using System;
using System.Drawing;
using System.Windows.Forms;
namespace ClinicAppWindowsForms
{
    public partial class PrescriptionDesignForm : Form
    {
        clsSettings ClinicInfo=clsSettings.GetClinicInfo();   
       
        public PrescriptionDesignForm(MedicalRecordForm.stPrescriptionInfo prescription)
        {
            InitializeComponent();
            this.prescription = prescription;
            InitializeDesignForm();
        }

        public PrescriptionDesignForm()
        {
            InitializeComponent();


        }



        private MedicalRecordForm.stPrescriptionInfo prescription;
        private ComboBox fontCombo, sizeCombo, layoutCombo;
        private ColorDialog colorDialog;
        private Button headerColorBtn, textColorBtn, saveDesignBtn;
        private CheckBox showLogoCheck, showBorderCheck, showFooterCheck;
        private PictureBox previewPicture;

       

        private void InitializeDesignForm()
        {
            this.Text = "Design Medical Prescription";
            this.Size = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;

            CreateDesignControls();
            CreatePreviewPanel();
            LoadCurrentSettings();
        }

        private void CreateDesignControls()
        {
            Panel controlsPanel = new Panel();
            controlsPanel.Dock = DockStyle.Left;
            controlsPanel.Width = 300;
            controlsPanel.BackColor = Color.FromArgb(240, 244, 247);
            controlsPanel.Padding = new Padding(15);

            Label designLabel = new Label();
            designLabel.Text = "Design Settings";
            designLabel.Font = new Font("Arial", 12, FontStyle.Bold);
            designLabel.Location = new Point(20, 20);
            designLabel.AutoSize = true;

            // خط الطباعة
            Label fontLabel = new Label();
            fontLabel.Text = "Font type";
            fontLabel.Location = new Point(20, 60);
            fontLabel.AutoSize = true;

            fontCombo = new ComboBox();
            fontCombo.Size = new Size(200, 25);
            fontCombo.Location = new Point(20, 85);
            fontCombo.Items.AddRange(new string[] { "Arial", "Times New Roman", "Tahoma", "Microsoft Sans Serif" });
            fontCombo.SelectedIndex = 0;

            // حجم الخط
            Label sizeLabel = new Label();
            sizeLabel.Text = "Font size:";
            sizeLabel.Location = new Point(20, 125);
            sizeLabel.AutoSize = true;

            sizeCombo = new ComboBox();
            sizeCombo.Size = new Size(200, 25);
            sizeCombo.Location = new Point(20, 150);
            sizeCombo.Items.AddRange(new string[] { "10", "11", "12", "14", "16", "18" });
            sizeCombo.SelectedIndex = 2;

            // تخطيط الصفحة
            Label layoutLabel = new Label();
            layoutLabel.Text = "Page layout:";
            layoutLabel.Location = new Point(20, 190);
            layoutLabel.AutoSize = true;

            layoutCombo = new ComboBox();
            layoutCombo.Size = new Size(200, 25);
            layoutCombo.Location = new Point(20, 215);
            layoutCombo.Items.AddRange(new string[] { "vertical", "horizontal" });
            layoutCombo.SelectedIndex = 0;

            // ألوان
            Label colorLabel = new Label();
            colorLabel.Text = "Colors:";
            colorLabel.Location = new Point(20, 255);
            colorLabel.AutoSize = true;

            headerColorBtn = new Button();
            headerColorBtn.Text = "Title color";
            headerColorBtn.Size = new Size(95, 30);
            headerColorBtn.Location = new Point(20, 280);
            headerColorBtn.BackColor = Color.Black;
            headerColorBtn.ForeColor = Color.White;
            headerColorBtn.Click += HeaderColorBtn_Click;

            textColorBtn = new Button();
            textColorBtn.Text = "Text color";
            textColorBtn.Size = new Size(95, 30);
            textColorBtn.Location = new Point(125, 280);
            textColorBtn.BackColor = Color.Black;
            textColorBtn.ForeColor = Color.White;
            textColorBtn.Click += TextColorBtn_Click;

            // خيارات إضافية
            showLogoCheck = new CheckBox();
            showLogoCheck.Text = "Show logo clinic";
            showLogoCheck.Location = new Point(20, 330);
            showLogoCheck.AutoSize = true;
            showLogoCheck.Checked = true;

            showBorderCheck = new CheckBox();
            showBorderCheck.Text = "Show borders";
            showBorderCheck.Location = new Point(20, 360);
            showBorderCheck.AutoSize = true;
            showBorderCheck.Checked = true;

            showFooterCheck = new CheckBox();
            showFooterCheck.Text = "Show Footer";
            showFooterCheck.Location = new Point(20, 390);
            showFooterCheck.AutoSize = true;
            showFooterCheck.Checked = true;

            // زر الحفظ
            saveDesignBtn = new Button();
            saveDesignBtn.Text = "💾 Save";
            saveDesignBtn.Size = new Size(200, 40);
            saveDesignBtn.Location = new Point(20, 440);
            saveDesignBtn.BackColor = Color.FromArgb(39, 174, 96);
            saveDesignBtn.ForeColor = Color.White;
            saveDesignBtn.Font = new Font("Arial", 10, FontStyle.Bold);
            saveDesignBtn.Click += SaveDesignBtn_Click;

            controlsPanel.Controls.AddRange(new Control[] {
                designLabel, fontLabel, fontCombo, sizeLabel, sizeCombo,
                layoutLabel, layoutCombo, colorLabel, headerColorBtn, textColorBtn,
                showLogoCheck, showBorderCheck, showFooterCheck, saveDesignBtn
            });

            this.Controls.Add(controlsPanel);

            colorDialog = new ColorDialog();
        }

        private void CreatePreviewPanel()
        {
            Panel previewPanel = new Panel();
            previewPanel.Dock = DockStyle.Fill;
            previewPanel.BackColor = Color.White;
            previewPanel.Padding = new Padding(10);

            Label previewLabel = new Label();
            previewLabel.Text = "Preview Design:";
            previewLabel.Font = new Font("Arial", 12, FontStyle.Bold);
            previewLabel.Dock = DockStyle.Top;
            previewLabel.Height = 30;

            previewPicture = new PictureBox();
            previewPicture.Dock = DockStyle.Fill;
            previewPicture.BorderStyle = BorderStyle.FixedSingle;
            previewPicture.SizeMode = PictureBoxSizeMode.Zoom;

            previewPanel.Controls.Add(previewPicture);
            previewPanel.Controls.Add(previewLabel);

            this.Controls.Add(previewPanel);
        }

        private void LoadCurrentSettings()
        {
            // تحميل الإعدادات الحالية
            fontCombo.SelectedItem = "Arial";
            sizeCombo.SelectedItem = "12";
            layoutCombo.SelectedItem = "vertical";

            UpdatePreview();
        }

        private void HeaderColorBtn_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                headerColorBtn.BackColor = colorDialog.Color;
                UpdatePreview();
            }
        }

        private void TextColorBtn_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                textColorBtn.BackColor = colorDialog.Color;
                UpdatePreview();
            }
        }

        private void UpdatePreview()
        {
            // إنشاء صورة معاينة
            Bitmap previewBitmap = new Bitmap(400, 600);
            using (Graphics graphics = Graphics.FromImage(previewBitmap))
            {
                graphics.Clear(Color.White);
                DrawPreviewPrescription(graphics);
            }

            previewPicture.Image = previewBitmap;
        }

        private void DrawPreviewPrescription(Graphics graphics)
        {
            Font titleFont = new Font(fontCombo.Text, float.Parse(sizeCombo.Text) + 4, FontStyle.Bold);
            Font headerFont = new Font(fontCombo.Text, float.Parse(sizeCombo.Text) + 2, FontStyle.Bold);
            Font normalFont = new Font(fontCombo.Text, float.Parse(sizeCombo.Text), FontStyle.Regular);

            Brush headerBrush = new SolidBrush(headerColorBtn.BackColor);
            Brush textBrush = new SolidBrush(textColorBtn.BackColor);

            float yPos = 20;
            float margin = 20;

            // العنوان
            graphics.DrawString("The Medical Prescription", titleFont, headerBrush, margin, yPos);
            yPos += graphics.MeasureString("The Medical Prescription", titleFont).Height + 10;

            graphics.DrawString(ClinicInfo.ClinicName, headerFont, headerBrush, margin, yPos);
            yPos += graphics.MeasureString(ClinicInfo.ClinicName, headerFont).Height + 5;

            // خط فاصل
            if (showBorderCheck.Checked)
            {
                graphics.DrawLine(Pens.Gray, margin, yPos, 380, yPos);
                yPos += 15;
            }

            graphics.DrawString($"Patient Name: {prescription.person.Name}", normalFont, textBrush, margin, yPos);
            yPos += graphics.MeasureString(prescription.person.Name, normalFont).Height + 5;

            // تذييل
            if (showFooterCheck.Checked)
            {
                yPos = 550;
                graphics.DrawString(".Wishing you with speedy recovery.", normalFont, headerBrush, margin, yPos);
            }
        }

        private void SaveDesignBtn_Click(object sender, EventArgs e)
        {
            try
            {
                var designSettings = new
                {
                    FontFamily = fontCombo.Text,
                    FontSize = sizeCombo.Text,
                    Layout = layoutCombo.Text,
                    HeaderColor = headerColorBtn.BackColor,
                    TextColor = textColorBtn.BackColor,
                    ShowLogo = showLogoCheck.Checked,
                    ShowBorder = showBorderCheck.Checked,
                    ShowFooter = showFooterCheck.Checked
                };

                MessageBox.Show("Done save Design settings .", "Done",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error in Design save: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    
}
}
