﻿using ClinicAppWindowsForms;
using ClinicAppWindowsForms.MedicalRecords_Forms;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using static ClinicAppWindowsForms.MedicalRecords_Forms.MedicalRecordForm;

namespace ClinicAppWindowsForms
{
    public partial class PrintForm : Form
    {
        enum enMode {PrintMedicalRecord,PrintPrescription }
        enMode mode;

        private MedicalRecordForm.stPrescriptionInfo prescriptionInfo;
        clsMedicalRecord medicalRecord;
        private clsSettings clinicInfo;

         
        public PrintForm(MedicalRecordForm.stPrescriptionInfo prescription)
        {
            InitializeComponent();

            this.prescriptionInfo = prescription;
            this.clinicInfo = clsSettings.GetClinicInfo();
            mode= enMode.PrintPrescription;
            _FillStaticData();
            InitializePrintDocument();


        }
        public PrintForm(clsMedicalRecord medicalRecord)
        {
            InitializeComponent();

            this.medicalRecord = medicalRecord;
            this.clinicInfo = clsSettings.GetClinicInfo();
            mode = enMode.PrintMedicalRecord;
             _FillStaticData();
            InitializePrintDocument();  
        }

        private void _FillStaticData()
        {
            if (mode == enMode.PrintPrescription) {
                lb_Title.Text = "🖨️ Print Prescription";
                richTextBox1.Text = GeneratePrescriptionText();


                return;
            }
        }

        private void InitializePrintDocument()
        {
            printDocument1 = new PrintDocument();
            printDocument1.PrintPage += PrintDocument_PrintPage;
            printDocument1.DefaultPageSettings.Landscape = false;
            printDocument1.DefaultPageSettings.Margins = new Margins(50, 50, 50, 50);

            printPreviewDialog1 = new PrintPreviewDialog();
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.WindowState = FormWindowState.Maximized;
            printPreviewDialog1.PrintPreviewControl.Zoom = 1.0;


        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Graphics graphics = e.Graphics;
            Font titleFont = new Font("Arial", 16, FontStyle.Bold);
            Font headerFont = new Font("Arial", 12, FontStyle.Bold);
            Font normalFont = new Font("Arial", 10, FontStyle.Regular);
            Font smallFont = new Font("Arial", 9, FontStyle.Regular);

            float yPos = 0;
            float leftMargin = e.MarginBounds.Left;
            float topMargin = e.MarginBounds.Top;
            float width = e.MarginBounds.Width;

            string title = "The Medical Prescription";
            SizeF titleSize = graphics.MeasureString(title, titleFont);
            graphics.DrawString(title, titleFont, Brushes.Black,
                leftMargin + (width - titleSize.Width) / 2, topMargin + yPos);
            yPos += titleSize.Height + 30;

            DrawClinicInfo(graphics, ref yPos, leftMargin, headerFont, normalFont);

            yPos += 10;
            graphics.DrawLine(Pens.Black, leftMargin, yPos, leftMargin + width, yPos);
            yPos += 20;

            // معلومات المريض
            DrawPatientInfo(graphics, ref yPos, leftMargin, headerFont, normalFont);

            // خط فاصل
            yPos += 10;
            graphics.DrawLine(Pens.Black, leftMargin, yPos, leftMargin + width, yPos);
            yPos += 20;

            // الأدوية
            DrawMedications(graphics, ref yPos, leftMargin, width, headerFont, normalFont);

            // خط فاصل
            yPos += 10;
            graphics.DrawLine(Pens.Black, leftMargin, yPos, leftMargin + width, yPos);
            yPos += 20;

            // التعليمات العامة والتوقيع
            DrawFooter(graphics, ref yPos, leftMargin, width, headerFont, normalFont);

            // تذييل الصفحة
            DrawFooterNote(graphics, ref yPos, leftMargin, width, smallFont);
        }

        private void DrawClinicInfo(Graphics graphics, ref float yPos, float leftMargin, Font headerFont, Font normalFont)
        {
            graphics.DrawString(clinicInfo.ClinicName, headerFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(clinicInfo.ClinicName, headerFont).Height + 5;

            graphics.DrawString($"Phone: {clinicInfo.ClinicPhone}", normalFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(clinicInfo.ClinicPhone, normalFont).Height + 3;

            graphics.DrawString(clinicInfo.ClinicTitle, normalFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(clinicInfo.ClinicTitle, normalFont).Height + 10;
        }

        private void DrawPatientInfo(Graphics graphics, ref float yPos, float leftMargin, Font headerFont, Font normalFont)
        {
            graphics.DrawString("Patient Information:", headerFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString("Patient Information:", headerFont).Height + 10;

            graphics.DrawString($"Name: {prescriptionInfo.person.Name}", normalFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(prescriptionInfo.person.Name, normalFont).Height + 5;

            graphics.DrawString($"Age: {prescriptionInfo.person.Age} year", normalFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(prescriptionInfo.person.Age, normalFont).Height + 5;

            graphics.DrawString($"Date: {DateTime.Now:yyyy/MM/dd}", normalFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(DateTime.Now.ToString("yyyy/MM/dd"), normalFont).Height + 5;
        }

        private void DrawMedications(Graphics graphics, ref float yPos, float leftMargin, float width, Font headerFont, Font normalFont)
        {
            graphics.DrawString("Prescribed Medications:", headerFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString("Prescribed Medications:", headerFont).Height + 10;

            //  foreach (var medication in prescriptionInfo.prescription)
            //  {
            var medication = prescriptionInfo.prescription;
                // اسم الدواء
                graphics.DrawString($"• {medication.MedicationName}", headerFont, Brushes.Black, leftMargin, yPos);
                yPos += graphics.MeasureString(medication.MedicationName, headerFont).Height + 5;

                // الجرعة
                graphics.DrawString($"  Dosage: {medication.Dosage}", normalFont, Brushes.Black, leftMargin + 20, yPos);
                yPos += graphics.MeasureString(medication.Dosage, normalFont).Height + 3;

                // التكرار
                graphics.DrawString($"  Frequency: {medication.Frequency}", normalFont, Brushes.Black, leftMargin + 20, yPos);
                yPos += graphics.MeasureString(medication.Frequency, normalFont).Height + 3;

                // التعليمات
                if (!string.IsNullOrEmpty(medication.SpecialInstruction))
                {
                    graphics.DrawString($"  Instrutions: {medication.SpecialInstruction}", normalFont, Brushes.Black, leftMargin + 20, yPos);
                    yPos += graphics.MeasureString(medication.SpecialInstruction, normalFont).Height + 3;
                }

                yPos += 5; // مسافة بين الأدوية
           // }
        }

        private void DrawFooter(Graphics graphics, ref float yPos, float leftMargin, float width, Font headerFont, Font normalFont)
        {
            // التعليمات العامة
            if (!string.IsNullOrEmpty(prescriptionInfo.prescription.SpecialInstruction))
            {
                graphics.DrawString("Instrutions:", headerFont, Brushes.Black, leftMargin, yPos);
                yPos += graphics.MeasureString("Instrutions:", headerFont).Height + 5;

                graphics.DrawString(prescriptionInfo.prescription.SpecialInstruction, normalFont, Brushes.Black, leftMargin, yPos);
                yPos += graphics.MeasureString(prescriptionInfo.prescription.SpecialInstruction, normalFont).Height + 15;
            }

            // التوقيع
            graphics.DrawString($"Doctor Name: Dr.. {prescriptionInfo.Doctor.employee.Name}", headerFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString(prescriptionInfo.Doctor.employee.Name, headerFont).Height + 10;

            graphics.DrawString("Signature: ____________", normalFont, Brushes.Black, leftMargin, yPos);
            yPos += graphics.MeasureString("Signature: ____________", normalFont).Height + 20;
        }

        private void DrawFooterNote(Graphics graphics, ref float yPos, float leftMargin, float width, Font smallFont)
        {
            string footerNote = "Wishing You a Speedy Recovery";
            SizeF footerSize = graphics.MeasureString(footerNote, smallFont);
            graphics.DrawString(footerNote, smallFont, Brushes.Black,
                leftMargin + (width - footerSize.Width) / 2, yPos);
        }

        private string GeneratePrescriptionText()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("╔════════════════════════════════════════════════╗");
            sb.AppendLine("║           The Medical Prescription             ║");
            sb.AppendLine("╚════════════════════════════════════════════════╝");
            sb.AppendLine();
            sb.AppendLine($".Doctor Name:        Dr.{prescriptionInfo.Doctor.employee.Name}");
            sb.AppendLine($".Specialization:     {prescriptionInfo.Doctor.Specialization}");
            sb.AppendLine();
            sb.AppendLine("──────────────────────────────────────────");
            sb.AppendLine($"Patient Name: {prescriptionInfo.person.Name}");
            sb.AppendLine($"Age: {prescriptionInfo.person.Age} year");
            sb.AppendLine($"Date: {DateTime.Now:yyyy/MM/dd}");
            sb.AppendLine("──────────────────────────────────────────");
            sb.AppendLine();
            sb.AppendLine("Prescription :");
            sb.AppendLine("──────────────");
            var medication = prescriptionInfo.prescription;
            sb.AppendLine($"• {prescriptionInfo.person.Name}");
            sb.AppendLine($"  Dosage: {medication.Dosage}");
            sb.AppendLine($"  Frequency: {medication.Frequency}");
             if (!string.IsNullOrEmpty(medication.SpecialInstruction))
            sb.AppendLine($"  Instructions: {medication.SpecialInstruction}");
            sb.AppendLine();
            sb.AppendLine("──────────────────────────────────────────");
            sb.AppendLine();
            sb.AppendLine($"Clinic: {clinicInfo.ClinicName}\tPhone: {clinicInfo.ClinicPhone}\tTitle: {clinicInfo.ClinicTitle}");
            sb.AppendLine();
            sb.AppendLine($"Signature Doctor: ______________");
            sb.AppendLine();
            sb.AppendLine("╔════════════════════════════════════════════════╗");
            sb.AppendLine("║        Wishing You a Speedy Recovery           ║");
            sb.AppendLine("╚════════════════════════════════════════════════╝");

            return sb.ToString();
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            try
            {
                PrintDialog printDialog = new PrintDialog();
                printDialog.Document = printDocument1;

                if (printDialog.ShowDialog() == DialogResult.OK)
                {
                    printDocument1.Print();
                    MessageBox.Show("Done Print.", "Successfully",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error in print: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Preview_Click(object sender, EventArgs e)
        {
            try
            {
                printPreviewDialog1.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error in preview: {ex.Message}", "Error",
                   MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Design_Click(object sender, EventArgs e)
        {
            PrescriptionDesignForm designForm = new PrescriptionDesignForm(prescriptionInfo);
            designForm.ShowDialog();
        }
  
    
    
    
    }
}
