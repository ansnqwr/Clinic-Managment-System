﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Features_Forms
{
    public partial class TasksForm : Form  //  غير مربوطة مع ال Database
    {
        private ListBox tasksList;
        private Button addTaskBtn;
        private Timer taskTimer;
        public TasksForm()
        {
            InitializeComponent();
            InitializeTaskSystem();
            LoadTasks();
        }
        private void InitializeTaskSystem()
        {
            this.Size = new Size(350, 300);
            this.BackColor = Color.White;
            //   this.BorderStyle = BorderStyle.FixedSingle;
            this.Padding = new Padding(10);

            Label titleLabel = new Label();
            titleLabel.Text = "📋 Tasks";
            titleLabel.Font = new Font("Arial", 12, FontStyle.Bold);
            titleLabel.Dock = DockStyle.Top;
            titleLabel.Height = 30;

            tasksList = new ListBox();
            tasksList.Dock = DockStyle.Fill;
            tasksList.Font = new Font("Arial", 10);
            tasksList.DrawMode = DrawMode.OwnerDrawVariable;
            tasksList.DrawItem += TasksList_DrawItem;
            tasksList.DoubleClick += TasksList_DoubleClick;

            addTaskBtn = new Button();
            addTaskBtn.Text = "➕ Add Task";
            addTaskBtn.Dock = DockStyle.Bottom;
            addTaskBtn.Height = 35;
            addTaskBtn.BackColor = Color.FromArgb(39, 174, 96);
            addTaskBtn.ForeColor = Color.White;
            addTaskBtn.Click += AddTaskBtn_Click;

            this.Controls.AddRange(new Control[] { tasksList, addTaskBtn, titleLabel });

            // مؤقت للتحقق من المهام
            taskTimer = new Timer();
            taskTimer.Interval = 60000; // كل دقيقة
            taskTimer.Tick += TaskTimer_Tick;
            taskTimer.Start();
        }

        private void TasksList_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;

            e.DrawBackground();

            string taskText = tasksList.Items[e.Index].ToString();
            bool isCompleted = taskText.StartsWith("✅");
            bool isUrgent = taskText.Contains("🔴");

            Color textColor = isCompleted ? Color.Gray : Color.Black;
            Font font = isCompleted ? new Font(tasksList.Font, FontStyle.Strikeout) : tasksList.Font;

            using (Brush brush = new SolidBrush(textColor))
            {
                e.Graphics.DrawString(taskText, font, brush, e.Bounds);
            }

            e.DrawFocusRectangle();
        }

        private void TasksList_DoubleClick(object sender, EventArgs e)
        {
            if (tasksList.SelectedItem != null)
            {
                string task = tasksList.SelectedItem.ToString();
                if (!task.StartsWith("✅"))
                {
                    tasksList.Items[tasksList.SelectedIndex] = "✅ " + task;
                }
            }
        }

        private void AddTaskBtn_Click(object sender, EventArgs e)
        {
            using (TaskInputForm inputForm = new TaskInputForm())
            {
                if (inputForm.ShowDialog() == DialogResult.OK)
                {
                    tasksList.Items.Add(inputForm.TaskText);
                    SaveTasks();
                }
            }
        }

        private void TaskTimer_Tick(object sender, EventArgs e)
        {
            CheckTaskReminders();
        }

        private void CheckTaskReminders()
        {
            // التحقق من المهام المستحقة
            for (int i = 0; i < tasksList.Items.Count; i++)
            {
                string task = tasksList.Items[i].ToString();
                if (task.Contains("⏰") && !task.StartsWith("✅"))
                {
                    // إشعار للمهام المستحقة
                    //  NotificationManager.ShowNotification("تذكير مهمة", task,
                    //  NotificationManager.NotificationType.Warning);
                }
            }
        }

        private void LoadTasks()
        {
            // تحميل المهام من قاعدة البيانات أو ملف
            tasksList.Items.AddRange(new object[] {
            "🔴 مراجعة تقارير المختبر - ⏰ 10:00",
            "📞 الاتصال بمريض - أحمد محمد",
            "📦 مراجعة المخزون - الأدوية",
            "⏰ اجتماع فريق العمل - 14:00",
            "📋 إعداد التقارير الشهرية"
        });
        }

        private void SaveTasks()
        {
        }
    }


    public partial class TaskInputForm : Form
    {
        public string TaskText { get; private set; }

        private TextBox taskTextBox;
        private ComboBox priorityCombo;
        private DateTimePicker reminderTime;

        public TaskInputForm()
        {
            //  InitializeComponent();
            InitializeTaskForm();
        }

        private void InitializeTaskForm()
        {
            this.Text = "Add New Task";
            this.Size = new Size(400, 250);
            this.StartPosition = FormStartPosition.CenterParent;

            // عناصر النموذج
            Label taskLabel = new Label() { Text = "Task:", Location = new Point(20, 20) };
            taskTextBox = new TextBox() { Size = new Size(300, 25), Location = new Point(20, 45) };

            Label priorityLabel = new Label() { Text = "Prority:", Location = new Point(20, 80) };
            priorityCombo = new ComboBox()
            {
                Size = new Size(150, 25),
                Location = new Point(20, 105),
                Items = { "Normal", "Important" }
            };
            priorityCombo.SelectedIndex = 0;

            Label timeLabel = new Label() { Text = "Remember me", Location = new Point(200, 80) };
            reminderTime = new DateTimePicker()
            {
                Size = new Size(120, 25),
                Location = new Point(200, 105),
                Format = DateTimePickerFormat.Time,
                ShowUpDown = true
            };

            Button saveBtn = new Button()
            {
                Text = "💾 Save",
                Size = new Size(100, 35),
                Location = new Point(150, 160),
                BackColor = Color.FromArgb(39, 174, 96),
                ForeColor = Color.White
            };
            saveBtn.Click += SaveBtn_Click;

            this.Controls.AddRange(new Control[] {
            taskLabel, taskTextBox, priorityLabel, priorityCombo,
            timeLabel, reminderTime, saveBtn
        });
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(taskTextBox.Text))
            {
                MessageBox.Show("Please Enter Text of task!!");
                return;
            }

            string priorityIcon;


            switch (priorityCombo.SelectedIndex)
            {
                case 1:
                    priorityIcon = "🔵";
                    break;
                case 2:
                    priorityIcon = "🔵";
                    break;
                default:
                    priorityIcon = "🟢";
                    break;
            }


            TaskText = $"{priorityIcon} {taskTextBox.Text} - ⏰ {reminderTime.Value:HH:mm}";
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }

}
