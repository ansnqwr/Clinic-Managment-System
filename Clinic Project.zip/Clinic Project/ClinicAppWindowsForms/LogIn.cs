﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using Microsoft.Win32;
using System.Windows.Forms;
using ClinicAppWindowsForms.Global_Classes;
using ClinicLogicLayer;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Drawing.Drawing2D;

namespace ClinicAppWindowsForms
{
    public partial class LogIn : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);
        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int lParam);

        private Color[] gradientColors = {
            Color.FromArgb(41, 128, 185),    // أزرق
            Color.FromArgb(52, 152, 219),    // أزرق فاتح
            Color.FromArgb(93, 173, 226)     // أزرق أفتح
        };
        //  private static string FileString = "Login_Info.txt";
        string keyPath = @"HKEY_CURRENT_USER\SOFTWARE\Clinic_Login";

        private string UserName;
        private string Password;
        private bool isPasswordVisible = false;

        clsUser user = new clsUser();


        public bool SaveLoginData(string UserName, string Password)
        {


            string userName = "YourUserName";
            string UserNameData = UserName;
            string password = "YourPassword";
            string PasswordData = Password;

            try
            {
                // Write the value to the Registry
                Registry.SetValue(keyPath, userName, UserNameData, RegistryValueKind.String);
                Registry.SetValue(keyPath, password, PasswordData, RegistryValueKind.String);


                Console.WriteLine($"Value {userName} successfully written to the Registry.");
                Console.WriteLine($"Value {password} successfully written to the Registry.");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }


            return false;

        }

        bool _ReadLoginData(ref string UserNameData, ref string PasswordData)
        {


            string userName = "YourUserName";
            string password = "YourPassword";
            try
            {
                // Read the value from the Registry
                UserNameData = Registry.GetValue(keyPath, userName, null) as string;
                PasswordData = Registry.GetValue(keyPath, password, null) as string;


                if (UserNameData != "" && PasswordData != "") // اذا ما لقاها بحط null
                {
                    Console.WriteLine($"The value of {userName} is: {UserNameData}");
                    Console.WriteLine($"The value of {password} is: {PasswordData}");

                    return true;
                }
                else
                {
                    Console.WriteLine($"Value {userName} or {password} not found in the Registry.");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            return false;

        }

        public LogIn()
        {
            InitializeComponent();
          
        }

        private void LogIn_Load(object sender, EventArgs e)
        {
            lb_LogIn.BackColor = Color.Transparent;
            // جعل الزوايا مدورة
            this.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));

            // تمكين سحب النافذة
            this.MouseDown += LogIn_MouseDown;

            panel3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, panel3.Width, panel3.Height, 15, 15));
            togglePasswordBtn.Image = CreateIcon("🗨", togglePasswordBtn.Size);
            tb_Password.UseSystemPasswordChar = true;

            CreateImageProfile();

            if (_ReadLoginData(ref UserName, ref Password))
            {
                if (UserName != "")
                {
                    tb_UserName.Text = UserName;
                    tb_Password.Text = Password;
                    chkRememberMe.Checked = true;
                }


            }


        }

        private void CreateImageProfile()
        {
            Bitmap profileImage = new Bitmap(100, 100);
            using (Graphics g = Graphics.FromImage(profileImage))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (Brush brush = new LinearGradientBrush(
                    new Rectangle(0, 0, 100, 100),
                    Color.FromArgb(52, 152, 219),
                    Color.FromArgb(40, 120, 180),
                    LinearGradientMode.Vertical))
                {
                    g.FillEllipse(brush, 0, 0, 100, 100);
                }
                g.DrawString("⚕", new Font("Segoe UI Emoji", 25), Brushes.WhiteSmoke, 30, 30);

            }
            pictureBox1.Image = profileImage;
        }
        private void chkRememberMe_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkRememberMe.Checked)
            {
                SaveLoginData("", "");
                return;
            }

            string EncryptionPassword = clsUtil.ComputeHash(tb_Password.Text);

            user = clsUser.FindUserByUserNameAndPassword(tb_UserName.Text, EncryptionPassword);
            if (user != null)
            {
                if (!_ReadLoginData(ref UserName, ref Password))
                {
                    UserName = tb_UserName.Text;
                    Password = tb_Password.Text;
                    SaveLoginData(UserName, Password);
                }

            }

        }

        private void btn_LogIn_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                return;
            }
            clsUser user = clsUser.FindUserByUserNameAndPassword(tb_UserName.Text.Trim(), tb_Password.Text.Trim());

            if (user != null)
            {

                if (chkRememberMe.Checked)
                {
                    //store username and password
                    SaveLoginData(tb_UserName.Text.Trim(), tb_Password.Text.Trim());

                }
                else
                {
                    //store empty username and password
                    SaveLoginData("", "");

                }

                //incase the user is not active
                if (user.AccountStatus == 0)
                {

                    tb_UserName.Focus();
                    MessageBox.Show("Your accound is not Active, Contact Admin.", "In Active Account", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                clsGlobal.CurrentUser = user;
                this.Hide();
                MainDashboard frm = new MainDashboard(this);
                frm.ShowDialog();
                //   Application.Exit(); 

            }
            else
            {
                tb_UserName.Focus();
                MessageBox.Show("Invalid Username/Password.", "Wrong Credintials", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ValidateEmptyTextBox(object sender, CancelEventArgs e)
        {

            // First: set AutoValidate property of your Form to EnableAllowFocusChange in designer 
            TextBox Temp = ((TextBox)sender);


        }

        private void tb_UserName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tb_UserName.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tb_UserName, "This field is required!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tb_UserName, null);
            }
        }

        private void tb_Password_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(tb_Password.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(tb_Password, "This field is required!");
            }
            else
            {
                //e.Cancel = false;
                errorProvider1.SetError(tb_Password, null);
            }
        }

        private void LogIn_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            panel1.Paint += (S, et) =>
            {
                Rectangle rect = panel1.ClientRectangle;
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    rect, gradientColors[0], gradientColors[2], LinearGradientMode.Vertical))
                {
                    ColorBlend colorBlend = new ColorBlend(3);
                    colorBlend.Colors = gradientColors;
                    colorBlend.Positions = new float[] { 0.0f, 0.5f, 1.0f };
                    brush.InterpolationColors = colorBlend;
                    //   e.Graphics.FillRectangle(brush, rect);
                }
            };
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }


        private void HighlightTextBox(TextBox textBox)
        {
            textBox.BorderStyle = BorderStyle.FixedSingle;
            textBox.BackColor = Color.FromArgb(236, 240, 241);
            // textBox.BorderColor = Color.FromArgb(41, 128, 185);
        }

        private void UnhighlightTextBox(TextBox textBox)
        {
            textBox.BorderStyle = BorderStyle.FixedSingle;
            textBox.BackColor = Color.FromArgb(245, 246, 250);
            // textBox.BorderColor = Color.FromArgb(189, 195, 199);
        }


        private Bitmap CreateIcon(string emoji, Size size)
        {
            Bitmap icon = new Bitmap(size.Width, size.Height);
            using (Graphics g = Graphics.FromImage(icon))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

                using (Font font = new Font("Segoe UI Emoji", size.Height * 0.7f, FontStyle.Regular))
                using (Brush brush = new SolidBrush(Color.FromArgb(149, 165, 166)))
                {
                    SizeF textSize = g.MeasureString(emoji, font);
                    PointF location = new PointF(
                        (size.Width - textSize.Width) / 2,
                        (size.Height - textSize.Height) / 2
                    );
                    g.DrawString(emoji, font, brush, location);
                }
            }
            return icon;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please connect with Admin for Put new password", "Forgot Password",
                       MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_LogIn_MouseEnter(object sender, EventArgs e)
        {
            btn_LogIn.BackColor = Color.FromArgb(52, 152, 219);
            btn_LogIn.Size = new Size(170, 50);
            //  btn_LogIn.Location = new Point(28, 408);
        }

        private void btn_LogIn_MouseLeave(object sender, EventArgs e)
        {
            btn_LogIn.BackColor = Color.FromArgb(41, 128, 185);
            btn_LogIn.Size = new Size(150, 45);
            //  btn_LogIn.Location = new Point(190, 516);
        }

        private void togglePasswordBtn_Click(object sender, EventArgs e)
        {
            isPasswordVisible = !isPasswordVisible;
            tb_Password.UseSystemPasswordChar = isPasswordVisible;
            togglePasswordBtn.Image = CreateIcon(isPasswordVisible ? "🗨" : "👁", togglePasswordBtn.Size);
        }


     
        public void _ResetLogInInfo()
        {

            tb_Password.Text = "";
            tb_UserName.Text = "";
            chkRememberMe.Checked = false;
        }

    }
}
