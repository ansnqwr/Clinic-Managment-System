﻿namespace ClinicAppWindowsForms.Settings_Forms
{
    partial class SettingsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tb_ClinicTitle = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_ClinicPhone = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_ClinicName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_RestoreBackUp = new System.Windows.Forms.Button();
            this.btn_CreateBackUp = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.rtb_Confirm_Password = new System.Windows.Forms.RichTextBox();
            this.rtb_NewPassword = new System.Windows.Forms.RichTextBox();
            this.rtb_CurrentPassword = new System.Windows.Forms.RichTextBox();
            this.lb_CurrentPassword = new System.Windows.Forms.Label();
            this.lb_NewPassword = new System.Windows.Forms.Label();
            this.lb_ConfirmPassword = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(873, 636);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.rtb_Confirm_Password);
            this.tabPage1.Controls.Add(this.rtb_NewPassword);
            this.tabPage1.Controls.Add(this.rtb_CurrentPassword);
            this.tabPage1.Controls.Add(this.lb_CurrentPassword);
            this.tabPage1.Controls.Add(this.lb_NewPassword);
            this.tabPage1.Controls.Add(this.lb_ConfirmPassword);
            this.tabPage1.Controls.Add(this.tb_ClinicTitle);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.tb_ClinicPhone);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.tb_ClinicName);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(20);
            this.tabPage1.Size = new System.Drawing.Size(865, 604);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "General Settings";
            // 
            // tb_ClinicTitle
            // 
            this.tb_ClinicTitle.Location = new System.Drawing.Point(146, 166);
            this.tb_ClinicTitle.Multiline = true;
            this.tb_ClinicTitle.Name = "tb_ClinicTitle";
            this.tb_ClinicTitle.Size = new System.Drawing.Size(300, 30);
            this.tb_ClinicTitle.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "Clinic Title :";
            // 
            // tb_ClinicPhone
            // 
            this.tb_ClinicPhone.Location = new System.Drawing.Point(146, 101);
            this.tb_ClinicPhone.Multiline = true;
            this.tb_ClinicPhone.Name = "tb_ClinicPhone";
            this.tb_ClinicPhone.Size = new System.Drawing.Size(300, 30);
            this.tb_ClinicPhone.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Clinic Phone :";
            // 
            // tb_ClinicName
            // 
            this.tb_ClinicName.Location = new System.Drawing.Point(146, 36);
            this.tb_ClinicName.Multiline = true;
            this.tb_ClinicName.Name = "tb_ClinicName";
            this.tb_ClinicName.Size = new System.Drawing.Size(300, 30);
            this.tb_ClinicName.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Clinic Name :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.button1.Location = new System.Drawing.Point(658, 541);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 40);
            this.button1.TabIndex = 2;
            this.button1.Text = "💾 Save";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 232);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(351, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "______________________________________";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.btn_RestoreBackUp);
            this.tabPage2.Controls.Add(this.btn_CreateBackUp);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(20);
            this.tabPage2.Size = new System.Drawing.Size(865, 604);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Back Up";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 24);
            this.label6.TabIndex = 7;
            this.label6.Text = "Auto Back up:";
            // 
            // btn_RestoreBackUp
            // 
            this.btn_RestoreBackUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.btn_RestoreBackUp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_RestoreBackUp.Location = new System.Drawing.Point(240, 80);
            this.btn_RestoreBackUp.Name = "btn_RestoreBackUp";
            this.btn_RestoreBackUp.Size = new System.Drawing.Size(200, 40);
            this.btn_RestoreBackUp.TabIndex = 6;
            this.btn_RestoreBackUp.Text = "💾 Restore Back Up";
            this.btn_RestoreBackUp.UseVisualStyleBackColor = false;
            // 
            // btn_CreateBackUp
            // 
            this.btn_CreateBackUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(156)))), ((int)(((byte)(18)))));
            this.btn_CreateBackUp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_CreateBackUp.Location = new System.Drawing.Point(20, 80);
            this.btn_CreateBackUp.Name = "btn_CreateBackUp";
            this.btn_CreateBackUp.Size = new System.Drawing.Size(200, 40);
            this.btn_CreateBackUp.TabIndex = 5;
            this.btn_CreateBackUp.Text = "💾 Create Back Up";
            this.btn_CreateBackUp.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Back up Data:";
            // 
            // rtb_Confirm_Password
            // 
            this.rtb_Confirm_Password.Location = new System.Drawing.Point(249, 494);
            this.rtb_Confirm_Password.Name = "rtb_Confirm_Password";
            this.rtb_Confirm_Password.Size = new System.Drawing.Size(211, 29);
            this.rtb_Confirm_Password.TabIndex = 19;
            this.rtb_Confirm_Password.Text = "";
            this.rtb_Confirm_Password.Validating += new System.ComponentModel.CancelEventHandler(this.rtb_Confirm_Password_Validating);
            // 
            // rtb_NewPassword
            // 
            this.rtb_NewPassword.Location = new System.Drawing.Point(249, 433);
            this.rtb_NewPassword.Name = "rtb_NewPassword";
            this.rtb_NewPassword.Size = new System.Drawing.Size(211, 29);
            this.rtb_NewPassword.TabIndex = 18;
            this.rtb_NewPassword.Text = "";
            this.rtb_NewPassword.Validating += new System.ComponentModel.CancelEventHandler(this.rtb_NewPassword_Validating);
            // 
            // rtb_CurrentPassword
            // 
            this.rtb_CurrentPassword.Location = new System.Drawing.Point(249, 370);
            this.rtb_CurrentPassword.Name = "rtb_CurrentPassword";
            this.rtb_CurrentPassword.Size = new System.Drawing.Size(211, 29);
            this.rtb_CurrentPassword.TabIndex = 17;
            this.rtb_CurrentPassword.Text = "";
            this.rtb_CurrentPassword.TextChanged += new System.EventHandler(this.rtb_CurrentPassword_TextChanged);
            this.rtb_CurrentPassword.Validating += new System.ComponentModel.CancelEventHandler(this.rtb_CurrentPassword_Validating);
            // 
            // lb_CurrentPassword
            // 
            this.lb_CurrentPassword.AutoSize = true;
            this.lb_CurrentPassword.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_CurrentPassword.Location = new System.Drawing.Point(49, 370);
            this.lb_CurrentPassword.Name = "lb_CurrentPassword";
            this.lb_CurrentPassword.Size = new System.Drawing.Size(145, 19);
            this.lb_CurrentPassword.TabIndex = 20;
            this.lb_CurrentPassword.Text = "Current Password:";
            // 
            // lb_NewPassword
            // 
            this.lb_NewPassword.AutoSize = true;
            this.lb_NewPassword.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_NewPassword.Location = new System.Drawing.Point(77, 431);
            this.lb_NewPassword.Name = "lb_NewPassword";
            this.lb_NewPassword.Size = new System.Drawing.Size(121, 19);
            this.lb_NewPassword.TabIndex = 21;
            this.lb_NewPassword.Text = "New Password:";
            // 
            // lb_ConfirmPassword
            // 
            this.lb_ConfirmPassword.AutoSize = true;
            this.lb_ConfirmPassword.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ConfirmPassword.Location = new System.Drawing.Point(47, 494);
            this.lb_ConfirmPassword.Name = "lb_ConfirmPassword";
            this.lb_ConfirmPassword.Size = new System.Drawing.Size(148, 19);
            this.lb_ConfirmPassword.TabIndex = 22;
            this.lb_ConfirmPassword.Text = "Confirm Password:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 285);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 19);
            this.label7.TabIndex = 23;
            this.label7.Text = "Change Password:";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ClinicAppWindowsForms.Properties.Resources.images1;
            this.pictureBox1.Location = new System.Drawing.Point(613, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(195, 185);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 24;
            this.pictureBox1.TabStop = false;
            // 
            // SettingsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(873, 636);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Settings";
            this.Load += new System.EventHandler(this.SettingsForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_ClinicName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_ClinicPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_ClinicTitle;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_CreateBackUp;
        private System.Windows.Forms.Button btn_RestoreBackUp;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox rtb_Confirm_Password;
        private System.Windows.Forms.RichTextBox rtb_NewPassword;
        private System.Windows.Forms.RichTextBox rtb_CurrentPassword;
        private System.Windows.Forms.Label lb_CurrentPassword;
        private System.Windows.Forms.Label lb_NewPassword;
        private System.Windows.Forms.Label lb_ConfirmPassword;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}