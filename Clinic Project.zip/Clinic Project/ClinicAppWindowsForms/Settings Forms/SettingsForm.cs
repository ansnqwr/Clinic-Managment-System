﻿using ClinicAppWindowsForms.Global_Classes;
using ClinicLogicLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClinicAppWindowsForms.Settings_Forms
{
    public partial class SettingsForm : Form

    {
        bool IsPasswordChange = false;

        clsSettings Settings=new clsSettings(); 
        public SettingsForm()
        {
            InitializeComponent();
        }
        private void SettingsForm_Load(object sender, EventArgs e)
        {
                _LoadClinicInfo();
        }

        private void _LoadClinicInfo()
        {
            clsSettings Settings =clsSettings.GetClinicInfo();   

            tb_ClinicName.Text = Settings.ClinicName;   
            tb_ClinicPhone.Text = Settings.ClinicPhone; 
            tb_ClinicTitle.Text = Settings.ClinicTitle; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Settings.ClinicName=tb_ClinicName.Text; 
            Settings.ClinicPhone=tb_ClinicPhone.Text;
            Settings.ClinicTitle=tb_ClinicTitle.Text;
            if (Settings.UpdateClinicInfo())
            {
                MessageBox.Show("Update Clinic Information is Successfully..","Edit",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }


            if (IsPasswordChange)
            {

                if (!this.ValidateChildren())
                {
                    MessageBox.Show("Some fileds are not valide!, put the mouse over the red icon(s) to see the erro",
                        "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                clsUser user = clsGlobal.CurrentUser;

                user.Password = rtb_NewPassword.Text.Trim();
                if (user.SaveUser())
                {

                    MessageBox.Show("change password is successfully..", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("change password is faild", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }

        

        }

        private void rtb_CurrentPassword_TextChanged(object sender, EventArgs e)
        {
            IsPasswordChange = true;
        }

        private void rtb_CurrentPassword_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(rtb_CurrentPassword.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(rtb_CurrentPassword, "Username cannot be blank");
                return;
            }
            else
            {
                errorProvider1.SetError(rtb_CurrentPassword, null);
            }
            ;

            if (clsGlobal.CurrentUser.Password != rtb_CurrentPassword.Text.Trim())
            {
                e.Cancel = true;
                errorProvider1.SetError(rtb_CurrentPassword, "Current password is wrong!");
                return;
            }
            else
            {
                errorProvider1.SetError(rtb_CurrentPassword, null);
            }
            ;
        }

        private void rtb_NewPassword_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(rtb_NewPassword.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(rtb_NewPassword, "New Password cannot be blank");
            }
            else
            {
                errorProvider1.SetError(rtb_NewPassword, null);
            }
            ;
        }

        private void rtb_Confirm_Password_Validating(object sender, CancelEventArgs e)
        {
            if (rtb_Confirm_Password.Text.Trim() != rtb_NewPassword.Text.Trim())
            {
                e.Cancel = true;
                errorProvider1.SetError(rtb_Confirm_Password, "Password Confirmation does not match New Password!");
            }
            else
            {
                errorProvider1.SetError(rtb_Confirm_Password, null);
            }
            ;
        }
    }
}
